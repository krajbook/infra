<?php if (!defined('BASEPATH')) exit('No direct script access allowed');



class nlp_model extends CI_Model

{ 

	function __construct()

	{

		 parent::__construct();

	}

	
	function insert($table,$data) #INSERT

	{

	if($this->db->insert($table,$data))

	return true;

	else

	return false;

	}

	
	function select($table,$cond='',$cond1='',$in='',$infield='') #SELECT

	{

	$this->db->select('*');

	$this->db->from($table);

	if($cond!='')

	{

	$this->db->where($cond);

	}
	
	if($cond1!='')

	{

	$this->db->where($cond1);

	}

	if($in!=''&&$infield!='')

	{

	$this->db->where_in($infield,$in);

	}

	$query = $this->db->get();

	return $query;	

	}

		

	function select_order($table,$cond='',$order_id='',$order_order='',$in='',$infield='') #SELECT
	{

		$this->db->select('*');

		$this->db->from($table);

		if($cond!='')

		{

		$this->db->where($cond);

		}

		if($order_id !='' && $order_order !='')

		{

			$this->db->order_by($order_id,$order_order);

		}

	

		if($in!=''&&$infield!='')

		{

		$this->db->where_in($infield,$in);

		}

		$query = $this->db->get();

		return $query;	

	}
	function get_data_order($select,$table,$cond='',$order_id='',$order_order='',$like='',$in='',$infield='') #SELECT
	{

		$this->db->select($select);

		$this->db->from($table);

		if($cond!='')

		{

		$this->db->where($cond);

		}
		if($like !='')
		{
			$this->db->like($like);
		}

		if($order_id !='' && $order_order !='')

		{

			$this->db->order_by($order_id,$order_order);

		}

	

		if($in!=''&&$infield!='')

		{

		$this->db->where_in($infield,$in);

		}

		$query = $this->db->get();

		return $query;	

	}



	function delete($table,$cond) #DELETE

	{

	if($this->db->delete($table,$cond))

	return true;

	else

	return false;

	}

	

	function update($table,$data,$cond) #UPDATE

	{

	if($this->db->update($table,$data,$cond))

	return true;

	else

	return false;

	}

	function join_tasks_projects($table_1,$table_2,$cond='')
	{

		$this->db->select('*');
    	$this->db->from($table_1);
    	$this->db->join($table_2, $table_1.'.project_id ='.$table_2.'.project_id');
 

		if($cond !='')
		{
			$this->db->where($cond);
		} 

		$query = $this->db->get();

	return $query;	

	}


	function join_tale($table_1,$table_2)

	{

	$this->db->select('*');



	$this->db->from($table_1.' as a');

	$this->db->join($table_2.' as b','a.user_id=b.user_id','left');

	//$this->db->group_by('a.user_id'); 

	//$this->db->join(BILLING_ADDRESS.' as c','a.order_id=c.order_id','inner');

	//$this->db->where($cond);

	$query = $this->db->get();

	return $query;	

	}

	

	

	

	function question($cond)

	{

	$this->db->select('*');

	$this->db->from('questions as a');

	$this->db->join('qoption as b','a.qid=b.qid','inner');

	$this->db->where($cond);

	$query = $this->db->get();

	return $query;	

	}

	

	

	

	function view_order($cond)

	{

	$this->db->select('*');

	$this->db->from(ORDERS.' as a');

	$this->db->join(USERS.' as b','a.order_user_id=b.user_id','inner');

	$this->db->join(BILLING_ADDRESS.' as c','a.order_id=c.order_id','inner');

	$this->db->where($cond);

	$query = $this->db->get();

	return $query;	

	}

	

	function chef_and_food($in) #SELECT_TABLE IN VIEW ORDERS ORDER DETAIL

	{

	$this->db->select('a.user_fname,a.user_lname,b.item_id,b.item_name,b.item_price');

	$this->db->from(USERS .' as a');

	$this->db->join(FOOD_ITEMS .' as b','a.user_id=b.chef_id','inner');

	$this->db->where_in('item_id',$in); 

	$query = $this->db->get();

	return $query;	

	}

	 

	function email($emailid,$subject,$message)

	{

			  $this->load->library('email');

			  $this->email->set_mailtype("html");

			  $this->email->set_newline("\r\n");

			  $this->email->from(''); 

			  $this->email->to($emailid);

			  //$this->email->cc(''); 

			  //$this->email->bcc(''); 

			  $this->email->subject($subject);

			  $this->email->message($message );

			  $query = $this->email->send();

			  return $query;

		}

		

		

	function clearSession()



	 {



	 	$array_items = array ('user_id' => '','user_name'=>'','user_role'=>'','user_login_email'=>'');



	    $this->session->unset_userdata($array_items);



		if($this->session->userdata('last_page') != '') {

		$last_page = array ('last_page' => '');



	    $this->session->unset_userdata($last_page);

		}

		}

	



	function manage_food_table($cond='')

	{

		$this->db->select('a.item_id,a.item_name,a.item_type,a.item_price,a.item_status,b.cat_name,c.user_fname,c.user_lname,d.time_name');

		$this->db->from(FOOD_ITEMS .' as a');

		$this->db->join(FOOD_CATEGORY  .' as b','a.cat_id=b.cat_id','inner');

		$this->db->join(USERS  .' as c','c.user_id=a.chef_id','inner');

		$this->db->join(ITEM_TIMING  .' as d','d.time_id=a.time_id','inner');

		if($cond!='')

		{

		$this->db->where($cond);

		}

		$query = $this->db->get();

		return $query; 

	

	}

	

	function order_products($cond)

	{

		$this->db->select('a.item_id,a.item_name,b.order_id,b.total,b.cooking_start,b.cooking_finish,b.cooking_dispatch,c.user_fname,c.user_lname,a.item_price');

		$this->db->from(FOOD_ITEMS .' as a');

		$this->db->join(ORDER_PRODUCTS  .' as b','b.order_food_id=a.item_id','inner');

		$this->db->join(USERS  .' as c','c.user_id=a.chef_id','inner');

		if($cond!='')

		{

		$this->db->where($cond);

		}

		$query = $this->db->get();

		return $query; 

	}
	
	
	
	function emp_project($cond)

	{

		$this->db->select('project_name,a.project_id');

		$this->db->from('projects as a');

		$this->db->join('tasks as b','b.project_id=a.project_id','inner');

		$this->db->join('task_tickets as c','b.task_id=c.task_id','inner');
		
		$this->db->group_by('a.project_id');

		if($cond!='')

		{

		$this->db->where($cond);

		}

		$query = $this->db->get();

		return $query; 

	}
	
	
	
	function emp_task($cond) 
	{

		$this->db->select('*,c.status as tstatus,a.created_at as ca,a.task_status as ts');

		$this->db->from('tasks as a'); 

		$this->db->join('task_tickets as c','a.task_id=c.task_id','inner'); 
		 
		if($cond!='')
		{
		$this->db->where($cond);
		}
		$this->db->order_by('c.created_at','desc');
		$this->db->order_by('a.task_status','desc');
		$query = $this->db->get();

		return $query; 

	}
	
	
	function tododash($cond) 
	{ 
		$this->db->select('*');

		$this->db->from('todo as a'); 

		$this->db->join('users as b','a.todo_assign_to=b.user_id','left'); 
		 
		if($cond!='')
		{
		$this->db->where($cond);
		} 
		$this->db->order_by('a.todo_date','desc');
		$this->db->limit(7);
		$query = $this->db->get();

		return $query; 

	}	
	
	
	function project_prgrs($cond)

	{

		$this->db->select('a.project_name,a.project_id,b.*');

		$this->db->from('projects as a');

		$this->db->join('tasks as b','b.project_id=a.project_id','inner'); 
		
		 

		if($cond!='')

		{

		$this->db->where($cond);

		}
		$this->db->order_by('a.project_id','desc');
		$this->db->limit(7);
		$query = $this->db->get();

		return $query; 

	}


	function ajax_select($table,$cond='') #SELECT

	{

	$this->db->select('*');

	$this->db->from($table);

	if($cond!='')

	{

	$this->db->where($cond);

	}

	$query = $this->db->get();
   
	return $query->row();	

	}
	

}