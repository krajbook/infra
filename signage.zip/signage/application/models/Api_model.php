<?php
    defined('BASEPATH') OR exit('No direct script access allowed');
    /**
    *
    */
    class Api_model extends CI_Model
    {
         
       
	
	function select($table,$cond='',$cond1='',$in='',$infield='') #SELECT

	{

	$this->db->select('*');

	$this->db->from($table);

	if($cond!='')

	{

	$this->db->where($cond);

	}
	
	if($cond1!='')

	{

	$this->db->where($cond1);

	}

	if($in!=''&&$infield!='')

	{

	$this->db->where_in($infield,$in);

	}

	$query = $this->db->get();

	return $query->result_array();	

	}

	function select_mob_status($table,$cond='',$cond1='',$in='',$infield='') #SELECT

	{

	$this->db->select('*');

	$this->db->from($table);

	if($cond!='')

	{

	$this->db->where($cond);

	}
	
	if($cond1!='')

	{

	$this->db->where($cond1);

	}

	if($in!=''&&$infield!='')

	{

	$this->db->where_in($infield,$in);

	}

	$query = $this->db->get();

	return $query;	

	}

	

	function update($table,$data,$cond) #UPDATE

	{

	if($this->db->update($table,$data,$cond))

	return true;

	else

	return false;

	}
       
	
}