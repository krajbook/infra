<?php


defined('BASEPATH') OR exit('No direct script access allowed');

require(APPPATH.'/libraries/REST_Controller.php');
use Restserver\Libraries\REST_Controller;

    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Content-Type: multipart/form-data; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers,  X-Requested-With");
    

class Api extends REST_Controller
{

       public function __construct() {
               parent::__construct();
               $this->load->model('nlp_model');
               $this->load->model('api_model');
       }    

       public function users_get()
       {
           $r = $this->api_model->select('users');
           $this->response($r); 
       }


       
       public function assets_get()
       {
         $r = $this->api_model->select('assets_apps');
         $this->response($r);
       }
       
       public function mobregcode_put()
       {
             $obj  = file_get_contents('php://input');
             $json = json_decode($obj);

             $uri  = $json->mob_reg_code;
             $uri_status = $json->mob_reg_code_status;

             if($uri)
             {
             
             $r = $this->api_model->select_mob_status('users',array('mob_reg_code'=>$uri))->row_array();
        
                  if($r->num_rows>0)
                  {
                   $u = $this->api_model->update('users',array('mob_reg_code_status'=>$uri_status),array('mob_reg_code'=>$uri));
                    $this->response([
                        'status' => TRUE,
                        'message' => 'The user Registration updated successfully.'
                    ], REST_Controller::HTTP_OK);
                  }else{
                    $this->response([
                        'status' => FALSE,
                        'message' => 'User Not exists.'
                    ], REST_Controller::HTTP_BAD_REQUEST);
                  }
             }else{
                $this->response([
                        'status' => FALSE,
                        'message' => 'Invalid request.'
                    ], REST_Controller::HTTP_BAD_REQUEST);
             }
       }

       public function schedules_get()
       {
             $uri = $this->uri->segment(3);
             if($uri)
             {
             
             $r = $this->api_model->select('assets_schedule',array('user_id'=>$uri));
             $this->response($r);
             }else{
                $this->response([
                        'status' => FALSE,
                        'message' => 'Provide user ID.'
                    ], REST_Controller::HTTP_BAD_REQUEST);
             }
       }

     public function placeorder_post()
	   {
	        $boarding = file_get_contents('php://input');
          $onshop = json_decode($boarding);
     }

	
    public function user_put() 
    {
        $obj = file_get_contents('php://input');
        $json = json_decode($obj);
        
        $forget_otp = strip_tags($json->otp);
        $password = $json->password;
        
        // Validate the post data
        if(!empty($forget_otp) || !empty($password) )
        {
            $userId = $this->user_model->select_user('users',array('forget_otp'=>$forget_otp));
          
            if($userId->num_rows()>0)
            {
          
                $userData = array();
                if(!empty($password))
                {
                    $userData['password'] = $this->password_hash($password);
                }
                $update = $this->user_model->edit($userData, $forget_otp);
                if($update)
                {
                    // Set the response and exit
                    $this->response([
                        'status' => TRUE,
                        'message' => 'The user info has been updated successfully.'
                    ], REST_Controller::HTTP_OK);
                }else{
                    // Set the response and exit
                    $this->response("Some problems occurred, please try again.", REST_Controller::HTTP_BAD_REQUEST);
                }
            }else{
                $this->response([
                    'status' => FALSE,
                    'message' => 'Invalid Request Email'
                ], REST_Controller::HTTP_BAD_REQUEST);
            }
        }else{
            // Set the response and exit
            $this->response([
                        'status' => FALSE,
                        'message' => 'Provide at least one user info to update.'
                    ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }

    public function webscreen_post()
    {
       
        $obj = file_get_contents('php://input');
        $json = json_decode($obj);

        if($json->template != '')
        {

            $array['json'] = array($json);
            
            if($json->template == 'temp_1')
            {
              $this->load->view('temp_1',$array);
            }

            if($json->template == 'temp_2')
            {
              
              $this->load->view('temp_2',$array);
            }

            if($json->template == 'temp_3')
            {

              $this->load->view('temp_3',$array);
            }

            if($json->template == 'temp_4')
            {

              $this->load->view('temp_4',$array);
            }

            if($json->template == 'temp_5')
            {

              $this->load->view('temp_5',$array);
            }
        }else{
            $this->response([
                            'status' => FALSE,
                            'message' => 'Provide Correct template details.'
                        ], REST_Controller::HTTP_BAD_REQUEST);
      }

    }
       

}