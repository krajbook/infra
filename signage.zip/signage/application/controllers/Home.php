<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller 
{

	public function __construct()
	{
		parent::__construct();

		$this->load->library('email'); 

		$this->contact_mail = $this->config->item('contact_mail'); 

		$this->from_mail = $this->config->item('from_mail'); 

	}



	public function index()
	{


		$this->load->view('home');

	}
	
	
	public function ajax_add_employees_attendance()
	{
		$get_id            = $this->input->post('get_id');

		$get_user_id       = $this->input->post('get_user_id');

		$get_submit_status = $this->input->post('get_submit_status');

		$current_date      = date('Y-m-d H:i:s');

		//print_r($_POST); exit;

		$attendance        = $this->nlp_model->select_order('time_in_out',array(

							'status'=>'1',

							'user_id'=>$this->session->userdata('user_id'),

							"DATE(created_at)"=>date('Y-m-d')

						    //"MONTH(created_at)"=>date('m'),

						   // "YEAR(created_at)"=>date('Y')

						    ),'created_at','DESC'

	                         );

		if($get_submit_status =='time_in')
		{

		
			if($attendance->num_rows()>0)
			{

				echo "2";
			 	
			}
			 else
			 {
			 	
			 	$insert = array(

								'user_id'        => $this->session->userdata('user_id'),

								//'time'           => $current_date,

								'in_time'        => $current_date,

								'time_status'    => 'time_in',

							    'in_ip_address'  => $this->input->ip_address(),

							    'status'      => '1',

							    'created_at'  => $current_date

						    );

			    $insert = $this->nlp_model->insert('time_in_out',$insert);

			    $insert_id = $this->db->insert_id();

			    
			    if($insert)
		        {
			
					$value = array(
								'error'=>'1',

								'change_punch_status'=>'Punch Out',

								'time_in'=>date('D,jS M Y h.i A',strtotime($current_date)),

								'last_id'=>$insert_id,

								'employee'=>'employee',

								'firstname'=>$this->session->userdata('user_name'),

								'lastname'=>'',

								'time'=>date('H:i:s',strtotime($current_date))

							);

			         echo json_encode($value);
		        }
		        else
		        {
		        	$value = array(
								'error'=>'2',

								'employee'=>'employee',

								'firstname'=>$this->session->userdata('user_name'),

								'lastname'=>'',

								'time'=>date('H:i:s',strtotime($current_date))

							);

			         echo json_encode($value);

		        }
		       
			 }

			

		}

		if($get_submit_status =='time_out')
		{

		
			if($attendance->num_rows()>0)
			{
				$update = array(

								//'id'        => $get_id,

								//'time'           => $current_date,

								'out_time'        => $current_date,

								'time_status'    => 'time_out',

							    'out_ip_address'  => $this->input->ip_address(),

							    'status'      => '1',

							    'updated_at'  => $current_date

						);

				//print_r($update); exit;

			     $insert = $this->nlp_model->update('time_in_out',$update,array('id'=>$get_id));
                
                if($insert)
		       {
			
					
					$value = array(
								'error'=>'1_1',

								'change_punch_status'=>'Punch Out',

								'time_out'=>date('D,jS M Y h.i A',strtotime($current_date)),

								'employee'=>'employee',

								'firstname'=>$this->session->userdata('user_name'),

								'lastname'=>'',

								'time'=>date('H:i:s',strtotime($current_date))

							);

			         echo json_encode($value);
		        }
		    	else
		    	{
				echo  "2";
		    	}
			 	
			}
			 else
			 {
			 	
			 	
			 }

			

		}







	}
	public function td()
	{
		$this->load->view('delete_1');
	}

	public function json_leaves_employee()
	{

		$user_ids = $this->session->userdata('user_id');

		$this->load->database();

				$dbDetails = array(
		    'host' => $this->db->hostname,
		    'user' => $this->db->username,
		    'pass' => $this->db->password,
		    'db'   => $this->db->database
		);

		// DB table to use
		$table = 'leaves_employees';

		// Table's primary key
		$primaryKey = 'id';

		// Array of database columns which should be read and sent back to DataTables.
		// The `db` parameter represents the column name in the database. 
		// The `dt` parameter represents the DataTables column identifier.
		$columns = array(
		    array( 'db' => 'leave_type', 'dt' => 0 ),

		    array(
		        'db'        => 'leave_from',
		        'dt'        => 1,
		        'formatter' => function( $d, $row ) {
		            return date( 'jS M Y', strtotime($d));
		        }
		    ),

		     array(
		        'db'        => 'leave_to',
		        'dt'        => 2,
		        'formatter' => function( $d, $row ) {
		            return date( 'jS M Y', strtotime($d));
		        }
		    ),

		     array(
		        'db'        => 'leave_to',
		        'dt'        => 3,
		        'formatter' => function( $d, $row ) {
		            return date( 'jS M Y', strtotime($d));
		        }
		    ),

		    array( 'db' => 'leave_reason', 'dt' => 4 ),
		    array(
		        'db'        => 'leave_status',
		        'dt'        => 5,
		        'formatter' => function( $d, $row ) {
		            if($d =='New')
		            {

		            	$return ='<div class="action-label">
		                    <a class="btn btn-white btn-sm btn-rounded" href="javascript:void(0);">
		                        <i class="fa fa-dot-circle-o text-purple"></i>'.$d.' </a></div>';
		           }
		           else if($d=='Pending')
		           {

		           	$return ='<div class="action-label">
															<a class="btn btn-white btn-sm btn-rounded" href="javascript:void(0);">
																<i class="fa fa-dot-circle-o text-info"></i> Pending
															</a>
														</div>';
		           }
		            else if($d=='Approved')
		           {

		           	$return ='<div class="action-label">
															<a class="btn btn-white btn-sm btn-rounded" href="javascript:void(0);">
																<i class="fa fa-dot-circle-o text-success"></i> Approved
															</a>
														</div>';
		           }
		           else if($d=='Declined')
		           {
		           	 $return ='<div class="action-label">
															<a class="btn btn-white btn-sm btn-rounded" href="javascript:void(0);">
																<i class="fa fa-dot-circle-o text-danger"></i> Declined
															</a>
														</div>';
		           }
		           else
		           {
		           	$return ='';
		           }
		           return $return;

		}

		    ),

		      array(
		        'db'        => 'leave_approved_by',
		        'dt'        => 6,
		        'formatter' => function( $d, $row ) 
		        {


		        	if($d !='')
		        	{

		        		$get_name = $this->nlp_model->select_order('users',array(

									'status'=>'1',

									'user_id'=>$d));

		        		if($get_name->num_rows()>0)
		        		{
		        			$get_name = $get_name->row();

		        			$user_fname = $get_name->user_fname;

		        			$user_lname = $get_name->user_lname;

		        			return '<h2 class="table-avatar">
		                        <a href="'.site_url().'home/profile/'.$get_name->user_id.'" class="avatar avatar-xs">
		                        <img src="'.base_url().'assets\img\profiles\avatar-09.jpg" alt=""></a>
								<a href="#">'.$user_fname." ".$user_lname.'</a> </h2>';


		        		}
		        		else
		        		{
		        			return '';
		        		}
		        	}
		        	else
		        	{
		        		return '<h2 class="table-avatar">
		                        <a href="'.site_url().'home/profile/" class="avatar avatar-xs">
		                        <img src="'.base_url().'assets\img\profiles\avatar-09.jpg" alt=""></a>
								<a href="#">Waiting</a> </h2>';
		        	}



		        	
		            
		        }
		    ),

		     array(
		        'db'        => 'id',
		        'dt'        => 7,
		        'formatter' => function( $d, $row ) {

		        	$get_leave_details = $this->nlp_model->select_order('leaves_employees',array('status'=>'1','id'=>$d));

		        		if($get_leave_details->num_rows()>0)
		        		{
		        			$get_leave_details = $get_leave_details->row();

		        			return '<div class="dropdown dropdown-action">
								<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
								<i class="material-icons">more_vert</i>
								</a>
								<div class="dropdown-menu dropdown-menu-right">
									
									<a 

									data-id="'.$get_leave_details->id.'"

									data-user_id="'.$get_leave_details->user_id.'"

									data-leave_type="'.$get_leave_details->leave_type.'"

									data-leave_from="'.date( 'd/m/Y', strtotime($get_leave_details->leave_from)).'"

									data-leave_to="'.date( 'd/m/Y', strtotime($get_leave_details->leave_to)).'"

									data-leave_no_of_days="'.$get_leave_details->leave_no_of_days.'"

									data-remaining_reaves="'.$get_leave_details->remaining_reaves.'"

									data-return_date="'.date( 'd/m/Y', strtotime($get_leave_details->return_date)).'"

									data-leave_reason="'.$get_leave_details->leave_reason.'"

									data-leave_status="'.$get_leave_details->leave_status.'"

									data-leave_approved_by="'.$get_leave_details->leave_approved_by.'"

									data-status="'.$get_leave_details->status.'"

									class="dropdown-item edit_leaves_model" href="javascript::void(0);" data-toggle="modal" data-target="#edit_leave">

									<i class="fa fa-pencil m-r-5"></i> Edit</a>
									
									<a 

									data-id="'.$get_leave_details->id.'"
									
									data-user_id="'.$get_leave_details->user_id.'"

									class="delete_leave dropdown-item" href="javascript::void(0);" data-toggle="modal" data-target="#delete_approve"><i class="fa fa-trash-o m-r-5"></i> Delete</a>
															</div>
														</div>';
		        		}
		           
		        }
		    ),
		      array(
		        'db'        => 'created_at',
		        'dt'        => 8,
		        'formatter' => function( $d, $row ) {
		            return date( 'jS M Y', strtotime($d));
		        }
		    )
		   /* array(
		        'db'        => 'status',
		        'dt'        => 7,
		        'formatter' => function( $d, $row ) {
		            return ($d == 1)?'Active':'Inactive';
		        }
		    )*/
		);

		// Include SQL query processing class
		//require( 'ssp.class.php');
		$this->load->library('Data_table');

		$where = "status ='1' AND user_id = $user_ids";



		// Output data as json format


		echo json_encode(
		    Data_table::complex( $_GET, $dbDetails, $table, $primaryKey, $columns,null,$where)
		);
	}


	public function json_leave()
	{
		
		$user_id   = $this->session->userdata('user_id');

		$data = array();

		$attendance= $this->nlp_model->select_order('leaves_employees',array(

							'status'=>'1',

							'user_id'=>$user_id,

						    ),'created_at','DESC'

	                         );

		if($attendance->num_rows()>0)
		{

			$result = $attendance->result();
		    $i =1;
					foreach ($result as $value) 
					{
						
						$i = $i+1;
						$data[] = array(
											$i,
											'Satou',
											'Accountant',
											'Tokyo',
											'28th',
											'162',
											'162',
											'700'
										);

					}

				}


			  $array = array(

			  					'draw'            =>($attendance->num_rows()>0) ? 1 :0,
								
								'recordsTotal'    =>($attendance->num_rows()>0) ? $attendance->num_rows() :0,
								
								'recordsFiltered' =>($attendance->num_rows()>0) ? 10 :0,
								
								'data'            =>$data


							);

			  echo json_encode($array);
	}
	public function ajax_add_employee_leave()
	{
		//print_r($_POST);

		$current_date = date('Y-m-d H:i:s');

		$user_id      = $this->session->userdata('user_id');

		$leave_type   = $this->input->post('leave_type');

		$leave_from   = $this->input->post('leave_from');

		$leave_from   = str_replace('/', '-', $leave_from);

		$leave_from   = date('Y-m-d', strtotime($leave_from));

		$leave_to     = $this->input->post('leave_to');

		$leave_to     = str_replace('/', '-', $leave_to);

		$leave_to     = date('Y-m-d', strtotime($leave_to));

		$return_date  = $this->input->post('return_date');

		$return_date  = str_replace('/', '-', $return_date);

		$return_date  = date('Y-m-d', strtotime($return_date));

		$leave_reason = $this->input->post('leave_reason');


		$insert = array(

								'user_id'        => $user_id,

								'leave_type'        => $leave_type,

								'leave_from'    => $leave_from,

							    'leave_to'  =>   $leave_to,


							    'return_date'  => $return_date,

							    'leave_reason'  => $leave_reason,

							    'leave_status'  => 'New',

							    'status'      => '1',

							    'created_at'  => $current_date

						);

		//print_r($insert);

	    $insert = $this->nlp_model->insert('leaves_employees',$insert);

	    echo ($insert==true)? "1":"2";
	}

	public function ajax_edit_leave()
	{
		$current_date = date('Y-m-d H:i:s');

		$id           = $this->input->post('edit_id');

		$leave_type   = $this->input->post('edit_leave_type');

		$leave_from   = $this->input->post('edit_leave_from');

		$leave_from   = str_replace('/', '-', $leave_from);

		$leave_from   = date('Y-m-d', strtotime($leave_from));

		$leave_to     = $this->input->post('edit_leave_to');

		$leave_to     = str_replace('/', '-', $leave_to);

		$leave_to     = date('Y-m-d', strtotime($leave_to));

		$return_date  = $this->input->post('edit_return_date');

		$return_date  = str_replace('/', '-', $return_date);

		$return_date  = date('Y-m-d', strtotime($return_date));

		$leave_reason = $this->input->post('edit_leave_reason');


		$update = array(

								'leave_type'   => $leave_type,

								'leave_from'   => $leave_from,

							    'leave_to'     =>   $leave_to,

							    'return_date'  => $return_date,

							    'leave_reason' => $leave_reason,

							    'leave_status' => 'New',

							    'status'       => '1',

							    'updated_at'   => $current_date

						);

		//print_r($id);

		//exit;

	    $update = $this->nlp_model->update('leaves_employees',$update,array('id'=>$id));


	    echo ($update==true)? "1":"2";
	}

	public function ajax_delete_leave()
	{
		$id = $this->input->post('id');

		$update = $this->nlp_model->update('leaves_employees',array('status'=>'3'),array('id'=>$id));

		echo ($update==true) ? '1':'2';

	}

	public function attendance_dashboard()
	{


		$attendance= $this->nlp_model->select_order('time_in_out',array(

							'status'=>'1',
							'user_id'=>$this->session->userdata('user_id'),

						    "MONTH(created_at)"=>date('m'),

						    "YEAR(created_at)"=>date('Y')

						    ),'created_at','DESC'

	                         );

	    if($attendance->num_rows()>0)
		 {  

		 	$data['attendance'] = $attendance->result();


		 }
		 else
		 {

		 	$data['attendance'] = array();
		 }


		/*echo "<pre>"; print_r($data); 

		 exit;*/
		$this->load->view('attendance_dashboard',$data);
	}

	public function activities()
	{

		
		$this->load->view('activities');

	}

	public function assets()
	{

		
		$this->load->view('assets');

	}

	public function attendance_employee()
	{

		
		$this->load->view('attendance_employee');

	}

	public function attendance()
	{

		
		$this->load->view('attendance');

	}

	public function blank_page()
	{

		
		$this->load->view('blank_page');

	}

	public function change_password()
	{

		
		$this->load->view('change_password');

	}

	public function chat()
	{

		
		$this->load->view('chat');

	}

	public function client_profile()
	{

		
		$this->load->view('client_profile');

	}

	public function clients_list()
	{

		
		$this->load->view('clients_list');

	}

	public function clients()
	{

		
		$this->load->view('clients');

	}

	public function follows_list()
	{
		$clients_list = $this->nlp_model->select_order('clients',array('status !='=>'3'),'created_at','DESC');

	    if($clients_list->num_rows()>0)
		 {  

		 	$data['clients_list'] = $clients_list->result();


		 }
		 else
		 {
		 	$data['clients_list'] = array();

		 }

		 $employees_list = $this->nlp_model->select_order('users',array(

							'status !='=>'3'),'created_at','DESC'

	                         );

	    if($employees_list->num_rows()>0)
		 {  

		 	$data['employees_list'] = $employees_list->result();


		 }
		 else
		 {

		 	$data['employees_list'] = array();
		 }


		$this->load->view('follows_list',$data);
	}

	public function todo_inbox($id=false)
	{

		$data['employee']     = '';
		
		$data['users_status'] = 'no';

		if($id!=false && $id !='users' && $id !='today' && $id !='tommorrow' && $id !='this_week' && $id !='yesterday')
		{

			$data['users_status']='yes';

			$employee = $this->nlp_model->select_order('users',array(

							'status !='=>'3','user_id'=>$id),'created_at','DESC'

	                         );

	    	if($employee->num_rows()>0)
		 	{  

		 		$data['employee'] = $employee->row();


		 	}
		 	else
		 	{

		 		$data['employee'] = '';
		 	}

		 	$todo_list  = $this->nlp_model->select_order('todo',
												array(

													'status !='=>'3',

													'todo_parent_id'=>'0',

													'todo_assign_to' =>$id,

													'todo_date >='     =>date('Y-m-d')

												),'todo_date','ASC');

			 if($todo_list->num_rows()>0)
		 	{  

		 		$data['todo_list'] = $todo_list->result();


		 	}
		 	else
		 	{
		 		$data['todo_list'] = array();

		 	}

		}
		else
		{


			if($id=='users' || $id=='')
			{

				$where = array(

									'status !='=>'3',

									'todo_parent_id'=>'0',

									'todo_date >='     =>date('Y-m-d')

								);

			}
			if($id=='today')
			{

				$where = array(

									'status !='=>'3',

									'todo_parent_id'=>'0',

									'DATE(todo_date)'=>date('Y-m-d')

								);

			}

			if($id=='tommorrow' || $id=='yesterday')
			{

				$days_calc =($id=='tommorrow') ? '+1 day':'-1 day';

				$where = array(

									'status !='=>'3',

									'todo_parent_id'=>'0',

									'DATE(todo_date)'=>date("Y-m-d", strtotime($days_calc))

								);

			}


			if($id=='this_week')
			{

				$this_week = $this->this_week_range(date("Y-m-d"));

				$where = array(

									'status !='=>'3',

									'todo_parent_id'=>'0',

									'DATE(todo_date)>='=>$this_week[0],
									
									'DATE(todo_date)<='=>$this_week[1]

								);


				
			}

			$todo_list  = $this->nlp_model->select_order('todo',$where,'todo_date','ASC');

			 if($todo_list->num_rows()>0)
		 	{  

		 		$data['todo_list'] = $todo_list->result();


		 	}
		 	else
		 	{
		 		$data['todo_list'] = array();

		 	}

		 	
		}


		$clients_list = $this->nlp_model->select_order('clients',array('status !='=>'3'),'created_at','DESC');

	    if($clients_list->num_rows()>0)
		 {  

		 	$data['clients_list'] = $clients_list->result();


		 }
		 else
		 {
		 	$data['clients_list'] = array();

		 }

		 $employees_list = $this->nlp_model->select_order('users',array(

							'status !='=>'3'),'created_at','DESC'

	                         );

	    if($employees_list->num_rows()>0)
		 {  

		 	$data['employees_list'] = $employees_list->result();


		 }
		 else
		 {

		 	$data['employees_list'] = array();
		 }



		$this->load->view('todo_inbox',$data);
	}

	public function remainter_notification()
	{

			$remainter_list  = $this->nlp_model->select_order('todo',
												array(

													'status !='=>'3',

													'task_remainter !='=>' ',

													'todo_assign_to !=' =>' ',

													'DATE(task_remainter)' =>date('Y-m-d')

												),'task_remainter','ASC');

			 if($remainter_list->num_rows()>0)
		 	{  

		 		$remainter_list =  $remainter_list->result();

		 		foreach ($remainter_list as $remainter_values) 
		 		{

		 			$get_user = $this->nlp_model->select_order('users',array(
		 			 				'user_id'=>$remainter_values->todo_assign_to));

		 			if($get_user->num_rows()>0)
		 			{
		 			 	
		 			 	$to_email    = $get_user->row()->user_login_email;
         
        				$from_email  = $this->from_mail;

        				$config      = array(
        					
        										'mailtype'  => 'html', 
    							
    											'charset'   => 'iso-8859-1',
    							
    											'wordwrap'  => TRUE
							
											);

		
						$this->email->initialize($config);
		
						$insert = array(
											'todo_name'    => $remainter_values->todo_name,

											'todo_date'   =>  date('d M Y h:i A', strtotime($remainter_values->todo_date))

										);
        
        				$data['ins_email'] = $insert;

						$contact_message   = $this->load->view('email_template/email',$data,true);


         				$this->email->from($from_email, 'Remainter Email'); 
         
         				$this->email->to($to_email);

         				$this->email->message($contact_message); 

        				if($this->email->send())
        				{

         					echo "1";

        				} 
        				else
        				{

           				    echo "2";

        				}


		 			 }

		 			
		 			
		 		}

		 		


		 	}
		 	else
		 	{
		 		

		 	}

	}
	

	public function components()
	{

		
		$this->load->view('components');

	}

	public function compose()
	{

		
		$this->load->view('compose');

	}

	public function contacts()
	{

		
		$this->load->view('contacts');

	}

	public function create_estimate()
	{

		
		$this->load->view('create_estimate');

	}

	public function create_invoice()
	{

		
		$this->load->view('create_invoice');

	}

	public function data_tables()
	{

		
		$this->load->view('data_tables');

	}

	public function departments()
	{

		
		$this->load->view('departments');

	}

	public function designations()
	{

		
		$this->load->view('designations');

	}

	public function edit_estimate()
	{

		
		$this->load->view('edit_estimate');

	}

	public function edit_invoice()
	{

		
		$this->load->view('edit_invoice');

	}

	public function email_settings()
	{

		
		$this->load->view('email_settings');

	}

	public function employee_dashboard()
	{

		
		$this->load->view('employee_dashboard');

	}

	public function employees_list()
	{

		
		$this->load->view('employees_list');

	}

	public function employees()
	{

		
		$this->load->view('employees');

	}

	public function error_404()
	{

		
		$this->load->view('error_404');

	}

	public function error_500()
	{

		
		$this->load->view('error_500');

	}

	public function estimate_view()
	{

		
		$this->load->view('estimate_view');

	}

	public function estimates()
	{

		
		$this->load->view('estimates');

	}

	public function events()
	{

		
		$this->load->view('events');

	}

	public function expense_reports()
	{

		
		$this->load->view('expense_reports');

	}

	public function expenses()
	{

		
		$this->load->view('expenses');

	}

	public function faq()
	{

		
		$this->load->view('faq');

	}

	public function file_manager()
	{

		
		$this->load->view('file_manager');

	}

	public function forgot_password()
	{

		
		$this->load->view('forgot_password');

	}

	public function form_basic_inputs()
	{

		
		$this->load->view('form_basic_inputs');

	}

	public function form_horizontal()
	{

		
		$this->load->view('form_horizontal');

	}

	public function form_input_groups()
	{

		
		$this->load->view('form_input_groups');

	}

	public function form_mask()
	{

		
		$this->load->view('form_mask');

	}


	public function form_validation()
	{

		
		$this->load->view('form_validation');

	}

	public function form_vertical()
	{

		
		$this->load->view('form_vertical');

	}

	public function goal_tracking()
	{

		
		$this->load->view('goal_tracking');

	}

	public function goal_type()
	{

		
		$this->load->view('goal_type');

	}

	public function holidays()
	{

		
		$this->load->view('holidays');

	}

	public function inbox()
	{

		
		$this->load->view('inbox');

	}

	public function incoming_call()
	{

		
		$this->load->view('incoming_call');

	}

	public function invoice_reports()
	{

		
		$this->load->view('invoice_reports');

	}

	public function invoice_settings()
	{

		
		$this->load->view('invoice_settings');

	}

	public function invoice_view()
	{

		
		$this->load->view('invoice_view');

	}

	public function invoices()
	{

		
		$this->load->view('invoices');

	}

	public function job_applicants()
	{

		
		$this->load->view('job_applicants');

	}

	public function job_details()
	{

		
		$this->load->view('job_details');

	}

	public function job_list()
	{

		
		$this->load->view('job_list');

	}

	public function job_view()
	{

		
		$this->load->view('job_view');

	}

	public function jobs()
	{

		
		$this->load->view('jobs');

	}

	public function knowledgebase_view()
	{

		
		$this->load->view('knowledgebase_view');

	}

	public function knowledgebase()
	{

		
		$this->load->view('knowledgebase');

	}

	public function leads()
	{

		
		$this->load->view('leads');

	}

	public function leave_settings()
	{

		
		$this->load->view('leave_settings');

	}

	public function leave_type()
	{

		
		$this->load->view('leave_type');

	}

	public function leaves_employee()
	{

		
		$this->load->view('leaves_employee');

	}

	public function leaves()
	{

		
		$this->load->view('leaves');

	}

	public function localization()
	{

		
		$this->load->view('localization');

	}

	public function lock_screen()
	{

		
		$this->load->view('lock_screen');

	}

	public function login()
	{

		
		$this->load->view('login');

	}

	public function notifications_settings()
	{

		
		$this->load->view('notifications_settings');

	}

	public function otp()
	{

		
		$this->load->view('otp');

	}

	public function outgoing_call()
	{

		
		$this->load->view('outgoing_call');

	}

	public function overtime()
	{

		
		$this->load->view('overtime');

	}

	public function payments()
	{

		
		$this->load->view('payments');

	}

	public function payroll_items()
	{

		
		$this->load->view('payroll_items');

	}

	public function performance_appraisal()
	{

		
		$this->load->view('performance_appraisal');

	}

	public function performance_indicator()
	{

		
		$this->load->view('performance_indicator');

	}

	public function performance()
	{

		
		$this->load->view('performance');

	}

	public function policies()
	{

		
		$this->load->view('policies');

	}

	public function privacy_policy()
	{

		
		$this->load->view('privacy_policy');

	}

	public function profile()
	{

		
		$this->load->view('profile');

	}

	public function project_list()
	{

		
		$this->load->view('project_list');

	}

	public function project_view()
	{

		
		$this->load->view('project_view');

	}

	public function projects()
	{

		
		$this->load->view('projects');

	}

	public function promotion()
	{

		
		$this->load->view('promotion');

	}

	public function provident_fund()
	{

		
		$this->load->view('provident_fund');

	}

	public function register()
	{

		
		$this->load->view('register');

	}

	public function resignation()
	{

		
		$this->load->view('resignation');

	}

	public function roles_permissions()
	{

		
		$this->load->view('roles_permissions');

	}

	public function salary_settings()
	{

		
		$this->load->view('salary_settings');

	}

	public function salary_view()
	{

		
		$this->load->view('salary_view');

	}

	public function salary()
	{

		
		$this->load->view('salary');

	}

	public function search()
	{

		
		$this->load->view('search');

	}

	public function settings()
	{

		
		$this->load->view('settings');

	}

	public function subscribed_companies()
	{

		
		$this->load->view('subscribed_companies');

	}

	public function subscriptions_company()
	{

		
		$this->load->view('subscriptions_company');

	}

	public function subscriptions()
	{

		
		$this->load->view('subscriptions');

	}

	public function tables_basic()
	{

		
		$this->load->view('tables_basic');

	}

	public function task_board()
	{

		
		$this->load->view('task_board');

	}

	public function tasks()
	{

		
		$this->load->view('tasks');

	}

	public function taxes()
	{

		
		$this->load->view('taxes');

	}

	public function termination()
	{

		
		$this->load->view('termination');

	}

	public function terms()
	{

		
		$this->load->view('terms');

	}

	public function theme_settings()
	{

		
		$this->load->view('theme_settings');

	}

	public function ticket_view()
	{

		
		$this->load->view('ticket_view');

	}

	public function tickets()
	{

		
		$this->load->view('tickets');

	}

	public function timesheet()
	{

		
		$this->load->view('timesheet');

	}

	public function trainers()
	{

		
		$this->load->view('trainers');

	}

	public function training_type()
	{

		
		$this->load->view('training_type');

	}

	public function training()
	{

		
		$this->load->view('training');

	}

	public function users()
	{

		
		$this->load->view('users');

	}
	public function video_call()
	{

		
		$this->load->view('video_call');

	}

	public function voice_call()
	{

		
		$this->load->view('voice_call');

	}

	public function this_week_range($date) 
	{
    	$ts = strtotime($date);
    	
    	$start = (date('w', $ts) == 0) ? $ts : strtotime('last monday', $ts);
    	
    	return array(date('Y-m-d', $start),
                 date('Y-m-d', strtotime('next sunday', $start)));
	}

}
