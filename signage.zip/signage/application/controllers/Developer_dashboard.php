<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Developer_dashboard extends CI_Controller 
{

	public function __construct()
	{
		parent::__construct();

		if($this->session->userdata('user_id') =='' ||  ($this->session->userdata('user_role') !='2'))
		{

		    redirect(site_url());
		    


		}

		$this->load->library('email'); 

		$this->contact_mail = $this->config->item('contact_mail'); 

	}



	public function index()
	{
        $data['todo'] = $this->nlp_model->tododash(array('a.status'=>1));
		$data['progress'] = $this->nlp_model->project_prgrs(array('a.status'=>1));

		$this->load->view('home',$data);

	}
	public function clock_in_out()
	{
		$this->load->view('clock_in_out');
	}

	public function activities()
	{

		
		$this->load->view('activities');

	}

	public function assets()
	{

		
		$this->load->view('assets');

	}

	public function attendance_employee()
	{

		$this->load->view('attendance_employee');

	}

	public function attendance()
	{

		
		$this->load->view('attendance');

	}

	public function blank_page()
	{

		
		$this->load->view('blank_page');

	}

	public function change_password()
	{

		
		$this->load->view('change_password');

	}

	public function chat()
	{

		
		$this->load->view('chat');

	}

	public function client_profile()
	{

		
		$this->load->view('client_profile');

	}

	public function clients_list()
	{

		
		$this->load->view('clients_list');

	}

	public function clients()
	{

		
		$this->load->view('clients');

	}

	public function components()
	{

		
		$this->load->view('components');

	}

	public function compose()
	{

		
		$this->load->view('compose');

	}

	public function contacts()
	{

		
		$this->load->view('contacts');

	}

	public function create_estimate()
	{

		
		$this->load->view('create_estimate');

	}

	public function create_invoice()
	{

		
		$this->load->view('create_invoice');

	}

	public function data_tables()
	{

		
		$this->load->view('data_tables');

	}

	public function departments()
	{

		
		$this->load->view('departments');

	}

	public function designations()
	{

		
		$this->load->view('designations');

	}

	public function edit_estimate()
	{

		
		$this->load->view('edit_estimate');

	}

	public function edit_invoice()
	{

		
		$this->load->view('edit_invoice');

	}

	public function email_settings()
	{

		
		$this->load->view('email_settings');

	}

	public function employee_dashboard()
	{

		
		$this->load->view('employee_dashboard');

	}

	public function employees_list()
	{

		
		$this->load->view('employees_list');

	}

	public function employees()
	{

		
		$this->load->view('employees');

	}

	public function error_404()
	{

		
		$this->load->view('error_404');

	}

	public function error_500()
	{

		
		$this->load->view('error_500');

	}

	public function estimate_view()
	{

		
		$this->load->view('estimate_view');

	}

	public function estimates()
	{

		
		$this->load->view('estimates');

	}

	public function events()
	{

		
		$this->load->view('events');

	}

	public function expense_reports()
	{

		
		$this->load->view('expense_reports');

	}

	public function expenses()
	{

		
		$this->load->view('expenses');

	}

	public function faq()
	{

		
		$this->load->view('faq');

	}

	public function file_manager()
	{

		
		$this->load->view('file_manager');

	}

	public function forgot_password()
	{

		
		$this->load->view('forgot_password');

	}

	public function form_basic_inputs()
	{

		
		$this->load->view('form_basic_inputs');

	}

	public function form_horizontal()
	{

		
		$this->load->view('form_horizontal');

	}

	public function form_input_groups()
	{

		
		$this->load->view('form_input_groups');

	}

	public function form_mask()
	{

		
		$this->load->view('form_mask');

	}


	public function form_validation()
	{

		
		$this->load->view('form_validation');

	}

	public function form_vertical()
	{

		
		$this->load->view('form_vertical');

	}

	public function goal_tracking()
	{

		
		$this->load->view('goal_tracking');

	}

	public function goal_type()
	{

		
		$this->load->view('goal_type');

	}

	public function holidays()
	{

		
		$this->load->view('holidays');

	}

	public function inbox()
	{

		
		$this->load->view('inbox');

	}

	public function incoming_call()
	{

		
		$this->load->view('incoming_call');

	}

	public function invoice_reports()
	{

		
		$this->load->view('invoice_reports');

	}

	public function invoice_settings()
	{

		
		$this->load->view('invoice_settings');

	}

	public function invoice_view()
	{

		
		$this->load->view('invoice_view');

	}

	public function invoices()
	{

		
		$this->load->view('invoices');

	}

	public function job_applicants()
	{

		
		$this->load->view('job_applicants');

	}

	public function job_details()
	{

		
		$this->load->view('job_details');

	}

	public function job_list()
	{

		
		$this->load->view('job_list');

	}

	public function job_view()
	{

		
		$this->load->view('job_view');

	}

	public function jobs()
	{

		
		$this->load->view('jobs');

	}

	public function knowledgebase_view()
	{

		
		$this->load->view('knowledgebase_view');

	}

	public function knowledgebase()
	{

		
		$this->load->view('knowledgebase');

	}

	public function leads()
	{

		
		$this->load->view('leads');

	}

	public function leave_settings()
	{

		
		$this->load->view('leave_settings');

	}

	public function leave_type()
	{

		
		$this->load->view('leave_type');

	}

	public function leaves_employee()
	{

		
		$this->load->view('leaves_employee');

	}

	public function leaves()
	{

		
		$this->load->view('leaves');

	}

	public function localization()
	{

		
		$this->load->view('localization');

	}

	public function lock_screen()
	{

		
		$this->load->view('lock_screen');

	}

	public function login()
	{

		
		$this->load->view('login');

	}

	public function notifications_settings()
	{

		
		$this->load->view('notifications_settings');

	}

	public function otp()
	{

		
		$this->load->view('otp');

	}

	public function outgoing_call()
	{

		
		$this->load->view('outgoing_call');

	}

	public function overtime()
	{

		
		$this->load->view('overtime');

	}

	public function payments()
	{

		
		$this->load->view('payments');

	}

	public function payroll_items()
	{

		
		$this->load->view('payroll_items');

	}

	public function performance_appraisal()
	{

		
		$this->load->view('performance_appraisal');

	}

	public function performance_indicator()
	{

		
		$this->load->view('performance_indicator');

	}

	public function performance()
	{

		
		$this->load->view('performance');

	}

	public function policies()
	{

		
		$this->load->view('policies');

	}

	public function privacy_policy()
	{

		
		$this->load->view('privacy_policy');

	}

	public function profile()
	{

		
		$this->load->view('profile');

	}

	public function project_list()
	{

		
		$this->load->view('project_list');

	}

	public function project_view()
	{

		
		$this->load->view('project_view');

	}

	public function projects()
	{

		
		$this->load->view('projects');

	}

	public function promotion()
	{

		
		$this->load->view('promotion');

	}

	public function provident_fund()
	{

		
		$this->load->view('provident_fund');

	}

	public function register()
	{

		
		$this->load->view('register');

	}

	public function resignation()
	{

		
		$this->load->view('resignation');

	}

	public function roles_permissions()
	{

		
		$this->load->view('roles_permissions');

	}

	public function salary_settings()
	{

		
		$this->load->view('salary_settings');

	}

	public function salary_view()
	{

		
		$this->load->view('salary_view');

	}

	public function salary()
	{

		
		$this->load->view('salary');

	}

	public function search()
	{

		
		$this->load->view('search');

	}

	public function settings()
	{

		
		$this->load->view('settings');

	}

	public function subscribed_companies()
	{

		
		$this->load->view('subscribed_companies');

	}

	public function subscriptions_company()
	{

		
		$this->load->view('subscriptions_company');

	}

	public function subscriptions()
	{

		
		$this->load->view('subscriptions');

	}

	public function tables_basic()
	{

		
		$this->load->view('tables_basic');

	}

	public function task_board()
	{

		
		$this->load->view('task_board');

	}

		public function tasks($id=false)
	{
		if($id!=false)
		{

			$employees_list = $this->nlp_model->select_order('users',array(

							'status'=>'1'),'created_at','DESC'

	                         );

		    $data['employees_list'] = ($employees_list->num_rows()>0) ? $employees_list->result() :array();

		    $clients_list           = $this->nlp_model->select_order('clients',array('status !='=>'3'),'created_at','DESC');

		    $data['clients_list']   = ($clients_list->num_rows()>0) ? $clients_list->result() :array();

			$project                = $this->nlp_model->select_order('projects',array('project_id'=>$id),'created_at','DESC');

			$projects_list          = $this->nlp_model->select_order('projects',array('status !='=>'3'),'created_at','DESC');

			$tasks     = $this->nlp_model->emp_task(
												array('a.status !='=>'3','a.project_id'=>$id));

			$data['tasks']          = ($tasks->num_rows()>0) ? $tasks->result() :array();

			$data['project']        = ($project->num_rows()>0) ? $project->row() :'';

			$data['projects_list']  = ($projects_list->num_rows()>0) ? $projects_list->result() :array();

			$this->load->view('tasks',$data);

		}
		else
		{
			

		}

		

		
		

	}
	
	

	public function taxes()
	{

		
		$this->load->view('taxes');

	}

	public function termination()
	{

		
		$this->load->view('termination');

	}

	public function terms()
	{

		
		$this->load->view('terms');

	}

	public function theme_settings()
	{

		
		$this->load->view('theme_settings');

	}

	public function ticket_view()
	{

		
		$this->load->view('ticket_view');

	}

	public function tickets()
	{

		
		$this->load->view('tickets');

	}

	public function timesheet()
	{

		
		$this->load->view('timesheet');

	}

	public function trainers()
	{

		
		$this->load->view('trainers');

	}

	public function training_type()
	{

		
		$this->load->view('training_type');

	}

	public function training()
	{

		
		$this->load->view('training');

	}

	public function users()
	{

		
		$this->load->view('users');

	}
	public function video_call()
	{

		
		$this->load->view('video_call');

	}

	public function voice_call()
	{

		
		$this->load->view('voice_call');

	}
public function ajax_get_leaders_followers()
    {
    	$id            = $this->input->post('project_id');

    	$project = $this->nlp_model->select_order('projects',array('project_id'=>$id),'created_at','DESC');

    	$get_followers = '';

    	$get_leaders = '';

    	if($project->num_rows()>0)
		{

			if($project->row()->project_members !='')
			{


				foreach (json_decode($project->row()->project_members,true) as $members_values) 
				{


					$employees = $this->nlp_model->select_order('users',array(

							'status'=>'1','user_id'=>$members_values),'created_at','DESC'

	                         );

					$employees_name = ($employees->num_rows()>0) ? $employees->row()->user_fname." ".$employees->row()->user_lname:'';

					$employees_pic  = ($employees->num_rows()>0) ? $employees->row()->profile_picture:'';

					$employees_id  = ($employees->num_rows()>0) ? $employees->row()->user_id:'';

					$employees_pic  = ($employees_pic !='') ? $employees_pic:'avatar.jpg';

					$employees_pic  = base_url().'images/profiles/thumb/'.$employees_pic;


					$get_followers .= '<a class="avatar" href="'.base_url().'admin_dashboard/profile/'.$employees_id.'" data-toggle="tooltip" title="Jeffery Lalor">
											<img alt="" src="'.$employees_pic.'">
										</a>';


					
					
				}
				foreach (json_decode($project->row()->project_leaders,true) as $leader_values) 
				{


					$employees = $this->nlp_model->select_order('users',array(

							'status'=>'1','user_id'=>$members_values),'created_at','DESC'

	                         );

					$employees_name = ($employees->num_rows()>0) ? $employees->row()->user_fname." ".$employees->row()->user_lname:'';

					$employees_pic  = ($employees->num_rows()>0) ? $employees->row()->profile_picture:'';

					$employees_id  = ($employees->num_rows()>0) ? $employees->row()->user_id:'';

					$employees_pic  = ($employees_pic !='') ? $employees_pic:'avatar.jpg';

					$employees_pic  = base_url().'images/profiles/thumb/'.$employees_pic;


					$get_leaders .= '<a class="avatar" href="'.base_url().'admin_dashboard/profile/'.$employees_id.'" data-toggle="tooltip" title="Jeffery Lalor">
											<img alt="" src="'.$employees_pic.'">
										</a>';


					
					
				}


			}


		}

		$project_files = $this->nlp_model->select_order('project_files',array('project_id'=>$id),'created_at','ASC');

		$msg ='';

		if($project_files->num_rows()>0)
		{
			foreach ($project_files->result() as $files_value) 
			{ 

				$employees = $this->nlp_model->select_order('users',array(

							'status'=>'1','user_id'=>$files_value->employee_id),'created_at','DESC'

	                         );

				$employees_name = ($employees->num_rows()>0) ? $employees->row()->user_fname." ".$employees->row()->user_lname:'';

				$employees_pic  = ($employees->num_rows()>0) ? $employees->row()->profile_picture:'';

				$employees_id  = ($employees->num_rows()>0) ? $employees->row()->user_id:'';

				$employees_pic  = ($employees_pic !='') ? $employees_pic:'avatar.jpg';

				$employees_pic  = base_url().'images/profiles/thumb/'.$employees_pic;



				$attached = $files_value->files !='' ? json_decode($files_value->files):array();
				$attached_details ='';



				if(count($attached)>0)
				{
					$li='';
					foreach ($attached as $attached_value) 
					{
						$explode=explode('.', $attached_value);
						if(count($explode)>1)
						{
							$li_down = base_url().'images/projects/'.$attached_value;

							if($explode[1]=='jpg')
							{
								$li_img = base_url().'images/projects/thumb/'.$attached_value;


								$li .= '<li class="img-file">
										<div class="attach-img-download">
										<a href="'.$li_down.'" download>avatar-1.jpg</a></div>
										<div class="task-attach-img">
										<img src="'.$li_img.'" alt="">
										</div>
										</li>';

							}
							else
							{
								$li .= '<li>
									<i class="fa fa-file"></i> 
									
									<a href="'.$li_down.'" download>'.$attached_value.'</a>

								</li>';

							}

						}
						
					}

					$attached_details = ' <span class="file-attached">attached '.count($attached).' files <i class="fa fa-paperclip"></i></span> 
								 <span class="chat-time">'.date('M d, Y', strtotime($files_value->created_at)).' at '.date('h:i a ', strtotime($files_value->created_at)).'</span>
									<ul class="attach-list">
										'.$li.'
									
									</ul>';


				}



				$msg .= '<div class="chat chat-left">
					<div class="chat-avatar">
						<a href="'.base_url().'home/profile/'.$employees_id.'" class="avatar">
							<img alt="" src="'.$employees_pic.'">
						</a>
					</div>
					<div class="chat-body">
						
						<div class="chat-bubble">
							<div class="chat-content">
								<span class="task-chat-user">'.$employees_name.'</span>

								'.$attached_details.'

									<p>'.$files_value->project_message.'</p>
							</div>
						</div>
					
					</div>
				</div> 
				<hr class="task-line">'; 
		    }   
		}
 
		$sarr = array('status'=>'1','get_followers'=>$get_followers,'get_leaders'=>$get_leaders,'chat_msg'=>$msg);
				
		echo json_encode($sarr);

    }

}
