<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login extends CI_Controller 
{

    //public $data;
	
	function __construct()
	{
		parent::__construct();
	}
	
	 
	public function index()
	{
		
		if($this->input->post('email'))
		{

			$check = array(
							'user_login_email'=>$this->input->post('email'),
							'user_password'=>$this->input->post('password')

							//'user_password'=>md5($this->input->post('password'))
							);
			$login = $this->nlp_model->select('users',$check,array('status' => 1));

			if($login->num_rows()>0)
		    {  
				
				
				$row = $login->row();
				
				$values = array (
									'user_id'=>$row->user_id,
									
									'user_name'=>$row->user_login_name,

									'user_role'=>$row->user_role,

									'user_email'=>$row->user_login_email,

									'mob_reg_code_status'=>$row->mob_reg_code_status

								); 

				$data_update = array('ip_address'=>$this->input->ip_address());

				$data_update_where = array('user_id'=>$row->user_id);

				$this->nlp_model->update('users',$data_update,$data_update_where);

				$this->session->set_userdata($values);
				
				$this->session->set_flashdata('flash_message', $this->message_model->flash_message('success','Successfully Logged in'));
				if($row->user_role==1)
				{
					redirect(site_url().'admin_dashboard');
					
				//redirect(ADMIN);
				}
				if($row->user_role==2)
				{
				     redirect(site_url().'admin_dashboard');
				}
		    }
		    else
		    {

				$this->session->set_flashdata('flash_message', $this->message_model->flash_message('error','Your Username / Password is Wrong. (or) Contact Admin to activate your account Try Again.'));
				redirect('login');
			}

		}
		else
		{


			

			if($this->session->userdata('user_id') !='')
			{

				$user_role = $this->session->userdata('user_role');
				
				if($user_role==1)
				{
					redirect(site_url().'admin_dashboard');
				//redirect(ADMIN);
				}
				if($user_role==2)
				{
				     redirect(site_url().'admin_dashboard');
				}

			}
			else
			{
				$this->load->view('login_thynkk');

			}

			

		}

	}

	public function logout()
	{
		$this->session->sess_destroy();

		redirect('login');
	}
	

    public function register_user()
    {


      if($this->input->post('email'))
		{

            $mob_reg_code  = $this->random_strings(8);
			$insert = array(
							'user_login_name'=>$this->input->post('user_fname'),
							'phone_no'=>$this->input->post('phone_no'),
							'user_login_email'=>$this->input->post('email'),
							'user_password'=>$this->input->post('password'),
							'mob_reg_code'=>$mob_reg_code,
							"user_role"=>2,
							'status'=>2
							);
			
			$login = $this->nlp_model->insert('users',$insert);
			// echo $this->db->last_query();exit;
			 if($login)
			 {
               redirect('login');
			 }else{
			 	redirect('register_user');
			 }

		}
      $this->load->view('register');
    }

    public function random_strings($length_of_string) 
	{ 
	    $str_result = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'; 
	  
	    return substr(str_shuffle($str_result),  
	                       0, $length_of_string); 
	} 
	   
 
    
    
    public function forget_password()
    {
        if($this->input->post('email'))
		{

			$check = array(
							'user_login_email'=>$this->input->post('email')
							);
			$login = $this->nlp_model->select('users',$check);
			
			if($login->num_rows()>0)
		    {  
				
				$row = $login->row();
				
			    $password = $row->user_password;
			      
                        $to = $row->user_login_email; // You can change here your Email
                        $subject = "From Signage"; // This is your subject
                         
                        // HTML Message Starts here
                        $message ="
                        <html>
                            <body>
                                <table style='width:600px;'>
                                    <tbody>
                                        <tr>
                                            <td style='width:150px'><strong>Your account password</strong></td>
                                        </tr>
                                        <tr>
                                            <td style='width:400px'>$password</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </body>
                        </html>
                        ";
                        $headers = "MIME-Version: 1.0" . "\r\n";
                        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
                 
                        // More headers
                        $headers .= 'From: Signage <chillkrt@gmail.com>' . "\r\n"; 
                        
                        if(mail($to,$subject,$message,$headers)){
                           $this->session->set_flashdata('flash_message', $this->message_model->flash_message('success','Please Check Your Email.'));
                           redirect('login');
                        }
                    
		    }
		    else
		    {

				$this->session->set_flashdata('flash_message', $this->message_model->flash_message('error','Your Email is Wrong. Try Again.'));
				redirect('login');
			}

		}
		else
		{

			$this->load->view('forget_password');

		}

    }
	
	
}	 
 