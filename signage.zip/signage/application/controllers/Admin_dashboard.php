<?php
defined('BASEPATH') OR exit('No direct script access allowed');



class Admin_dashboard extends CI_Controller 
{

	public function __construct()
	{
		parent::__construct();

	}


	public function index()
	{

		
		$this->load->view('admin/home');

	}

	public function assets()
	{
		
		$this->load->view('admin/assets');
	}


	public function ajax_assets()
	{   
		$id = $this->input->post('id');
		
		$select = $this->nlp_model->ajax_select('assets_apps',array('id'=>$id));
         // echo $this->db->last_query();
		list($width, $height ,$bits) = getimagesize($select->app_url);

	    
		$datas= "";
		if($select->path_type == 'Image'){
			$datas.= " <img width='420' height='315' class='embed-responsive-item' src='".$select->app_url."' onclick='alert(1);' id='src'>
                    
                    <div class='card mb-0'>
						<div class='card-body'>
							<div class='row'>
								<div class='col-md-12'>
									<div class='profile-view'> 
										<div class=''> 
												<div class='row'>  
												<div class='col-md-12'>

													<ul class='personal-info' >
														<li>
															<span class='title'>Name:</span>
															<span class='text'>".$select->path_type."</span>
														</li>
														<li>
															<span class='title'>Size:</span>
															<span class='text'>".$select->app_size."</a></span>
														</li>
														<li>
															<span class='title'>Dimension:</span>
															<span class='text'>".$width."*".$height."</span>
														</li>
														<li>
															<span class='title'>Date:</span>
															<span class='text'>".$select->created_at."</span>
														</li>
														
													</ul>
												</div>
												
											</div>
											
										</div>
									</div>
								</div>
							</div>
						</div> 
 				    </div>
               ";
           }else{  
           	$datas.= " <iframe width='420' height='315' class='embed-responsive-item' src='".$select->app_url."' ></iframe>
                    
                    <div class='card mb-0'>
						<div class='card-body'>
							<div class='row'>
								<div class='col-md-12'>
									<div class='profile-view'> 
										<div class=''> 
												<div class='row'>  
												<div class='col-md-12'>

													<ul class='personal-info' >
														<li>
															<span class='title'>Name:</span>
															<span class='text'>".$select->path_type."</span>
														</li>
														<li>
															<span class='title'>Size:</span>
															<span class='text'>".$select->app_size."</a></span>
														</li>
														<li>
															<span class='title'>Dimension:</span>
															<span class='text'>".$width."*".$height."</span>
														</li>
														<li>
															<span class='title'>Date:</span>
															<span class='text'>".$select->created_at."</span>
														</li>
														<li>
															<span class='title'>Duration:</span>
															<span class='text'>".$bits."</span>
														</li>
													</ul>
												</div>
												
											</div>
											
										</div>
									</div>
								</div>
							</div>
						</div> 
 				    </div>
               ";
           }
        
		
   		echo  $datas;
        
	}


	public function asset_tag()
	{

		$asset_id          = $this->input->post('asset_id');

		$asset_key         = $this->input->post('asset_key');

		$asset_value       = $this->input->post('asset_value');
        
        $user_id           = $this->session->userdata('user_id');

		$insert            = array(

			                   'user_id'    => $user_id,

			                   'asset_id'   => $asset_id,

			                   'asset_key'  => $asset_key,

			                   'asset_value'=> $asset_value

							 );

		$tag = $this->nlp_model->insert('assets_tags',$insert);
		// echo $this->db->last_query();
		        if($tag == 1)
				{
					$this->load->view('admin/assets',$tag);
				}
				else
				{
					$this->load->view('admin/assets',$tag);
				}

	}



	public function ajax_delete_lead()
    {
    	$client_id = $this->input->post('client_id');

		$update_status = $this->nlp_model->delete('assets_apps',array('id'=>$client_id));
	
		if($update_status)
		{
			echo "1";
		}
		else
		{
			echo "2";
		}
    }

	public function composition()
	{
		$this->load->view('admin/composition');
	}

	public function create_composition()
	{
		$this->load->view('admin/create_composition');
	}
    
    public function composition_ajax()
	{   
		$id = $this->input->post('id');
		
		$select = $this->nlp_model->ajax_select('assets_apps',array('id'=>$id,'path_type'=>'Video'));
         // echo $this->db->last_query();
		$composition_ajax= "";
		if($select->path_type == 'Image'){
          $composition_ajax.= "<div id='home1' class='tab-pane fade in active'>
	     <img width='420' height='315' class='embed-responsive-item' src='".$select->app_url."'>
		
		 <div class='card mb-0'>
						<div class='card-body'>
							<div class='row'>
								<div class='col-md-12'>
									<div class='profile-view'> 
										<div class=''> 
												<div class='row'>  
												<div class='col-md-12'>
													<h4 style='padding-top: 10px'>Composition</h4>
													<ul class='personal-info'>
														<li>
										                    <span class='title'>Name:</span>
															<span class='text'>&nbsp;".'c-'.date('Y-d-F h:i A', strtotime($select->created_at))."</span>
														</li>
														<li>
														     
															<span class='title'>Version:</span>
															<span class='text'>&nbsp;1</span>
														</li>
														
															<li>
															<span class='title'>Duration:</span>
															<span class='text'>&nbsp;10 Seconds</span>
														</li>
														 
														<li>
															<span class='title'>Aspect Ratio:</span>
															<span class='text'>&nbsp;Horizontal</span>
														</li> 
													</ul>  
												</div>
												
											</div>
											
										</div>
									</div>
								</div>
							</div>
						</div> 
 				</div>

 				<div class='card mb-0'>
						<div class='card-body'>
							<div class='row'>
								<div class='col-md-12'>
									<div class='profile-view'> 
										<div class=''> 
												<div class='row'>  
												<div class='col-md-12'>
													<h4 style='padding-top: 10px'>Associated Schedules</h4>
													<p>Currently, no play now associated.</p>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>



					<div class='card mb-0'>
						<div class='card-body'>
							<div class='row'>
								<div class='col-md-12'>
									<div class='profile-view'> 
										<div class=''> 
												<div class='row'>  
												<div class='col-md-12'>
													<h4 style='padding-top: 10px'>Associated Quick Plays</h4>
													<p>Currently, no play now associated.</p>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
 	
    </div>";
		}else{
      $composition_ajax.= "<div id='home1' class='tab-pane fade in active'>
	     <iframe width='420' height='315' class='embed-responsive-item' src='".$select->app_url."' frameborder='0' allow='accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture' allowfullscreen>
                    
                   </iframe>
              
		
		 <div class='card mb-0'>
						<div class='card-body'>
							<div class='row'>
								<div class='col-md-12'>
									<div class='profile-view'> 
										<div class=''> 
												<div class='row'>  
												<div class='col-md-12'>
													<h4 style='padding-top: 10px'>Composition</h4>
													<ul class='personal-info'>
														<li>
										                    <span class='title'>Name:</span>
															<span class='text'>&nbsp;".'c-'.date('Y-d-F h:i A', strtotime($select->created_at))."</span>
														</li>
														<li>
														     
															<span class='title'>Version:</span>
															<span class='text'>&nbsp;1</span>
														</li>
														
															<li>
															<span class='title'>Duration:</span>
															<span class='text'>&nbsp;10 Seconds</span>
														</li>
														 
														<li>
															<span class='title'>Aspect Ratio:</span>
															<span class='text'>&nbsp;Horizontal</span>
														</li> 
													</ul>  
												</div>
												
											</div>
											
										</div>
									</div>
								</div>
							</div>
						</div> 
 				</div>

 				<div class='card mb-0'>
						<div class='card-body'>
							<div class='row'>
								<div class='col-md-12'>
									<div class='profile-view'> 
										<div class=''> 
												<div class='row'>  
												<div class='col-md-12'>
													<h4 style='padding-top: 10px'>Associated Schedules</h4>
													<p>Currently, no play now associated.</p>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>



					<div class='card mb-0'>
						<div class='card-body'>
							<div class='row'>
								<div class='col-md-12'>
									<div class='profile-view'> 
										<div class=''> 
												<div class='row'>  
												<div class='col-md-12'>
													<h4 style='padding-top: 10px'>Associated Quick Plays</h4>
													<p>Currently, no play now associated.</p>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
 	
    </div>";
		}
        
      echo  $composition_ajax;
        
	}


	public function ajax_upload()  //clent insert
	{
      

	    $user_id       = $this->session->userdata('user_id');

	    $file_from     = $this->input->post('file_from');
      

        if(!empty($_FILES['profile_picture']['name']))
        { 
            
        	$this->load->library('image_lib');

            $_FILES['file']['name']     = $_FILES['profile_picture']['name'];
            
            $_FILES['file']['type']     = $_FILES['profile_picture']['type'];
           
            $_FILES['file']['tmp_name'] = $_FILES['profile_picture']['tmp_name'];
            
            $_FILES['file']['error']    = $_FILES['profile_picture']['error'];
            
            $_FILES['file']['size']     = $_FILES['profile_picture']['size'];
                

            $uploadPath = 'images/profiles/';
            
            $config['upload_path'] = $uploadPath;
            
            $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4';
		    
		    $config['overwrite'] = FALSE;
            
            
			$fileName = $_FILES['file']['name'];

			$fileSize = $_FILES['file']['size'];
			
			$config['file_name'] = $fileName; 
				
                // Load and initialize upload library
            $this->load->library('upload', $config);   
            
            $this->upload->initialize($config);
               
             // Upload file to server
            if($this->upload->do_upload('file'))
            { 
                // Uploaded file data
                 $fileData = $this->upload->data(); 
                 
                 $profile_picture =  $fileData['file_name']; 
             // echo 333;
            } 
            			
			$ext = pathinfo($fileName, PATHINFO_EXTENSION);
            // echo 'durat'.$slide_duration;exit;

			if($ext == 'png'){
				$app_img = 'img-icon.png';
				$type = 'Image';
			}
			if($ext == 'jpg'){
				$app_img = 'img-icon.png';
				$type = 'Image';
			}
			if($ext == 'jpeg'){
				$app_img = 'img-icon.png';
				$type = 'Image';
			}
			if($ext == 'mp4')
			{
				$app_img = 'video.jpg';
				$type = 'Video';
			}

			$insert          = array(
					                   
					                   'path_type'    => $type,

					                   'app_img'      => $app_img,

					                   'app_url'      => 'https://sirisigns.xyz/signage/'.$config['upload_path'].$profile_picture,

					                   'user_id'      => $user_id,

					                   'app_size'     => $fileSize,

					                   // 'no_of_post'   => $no_of_post,
					                   
					                   'file_from'    => $file_from,

									 );
			
				$data = $this->nlp_model->insert('assets_apps',$insert);
		        // echo $this->db->last_query();exit;
		        if($data == 1)
				{
					$this->load->view('admin/assets',$data);
				}
				else
				{
					$this->load->view('admin/assets',$data);
				}
		        
		        
		}

	}
	

	public function schedule()
	{
		$this->load->view('admin/schedule');
	}

	public function socialapplication()
	{
        $this->load->view('admin/socialapplication');
	}


	public function ajax_add_client()  //clent insert
	{
      
		$app_name      = $this->input->post('app_name');

		$app_url       = $this->input->post('app_url');
        
        $user_id       = $this->session->userdata('user_id');

		$insert          = array(
			                   'user_id'    => $user_id,

			                   'app_id'     => 1,

			                   'path_type'  => 'App',

			                   'file_from'  => 'Assets',

			                   'app_img'    => 'youtube.png',

			                   'app_name'   => $app_name,

			                   'app_url'    => $app_url

							 );

		$insert = $this->nlp_model->insert('assets_apps',$insert);

		if($insert)
		{
			echo "1";
		}
		else
		{
			echo  "2";
		}


	}
    
    
    public function ajax_add_facebook()  //clent insert
	{
      
		$app_name      = $this->input->post('app_name');
        
        $no_of_post    = $this->input->post('no_of_post');

        $slide_duration= $this->input->post('slide_duration');

        $user_id       = $this->session->userdata('user_id');

		$insert          = array(
			                   'user_id'    => $user_id,
			                   
			                   'app_id'     => 2,

			                   'path_type'  => 'App',

			                   'file_from'  => 'assets',

			                   'app_img'    => 'facebook.jpg',

			                   'app_name'   => $app_name,

			                   'no_of_post' => $no_of_post,

			                   'slide_duration'=> $slide_duration

							 );

		$insert = $this->nlp_model->insert('assets_apps',$insert);

		if($insert)
		{
			echo "1";
		}
		else
		{
			echo  "2";
		}


	}


	 public function ajax_add_instagram()  //clent insert
	{
      
		$app_name      = $this->input->post('app_name');
        
        $no_of_post    = $this->input->post('no_of_post');

        $slide_duration= $this->input->post('slide_duration');

        $user_id       = $this->session->userdata('user_id');

		$insert          = array(
			                   'user_id'    => $user_id,
			                   
			                   'app_id'     => 3,

			                   'app_name'   => $app_name,

			                   'path_type'  => 'App',

			                   'file_from'  => 'assets',

			                   'app_img'    => 'insta.png',

			                   'no_of_post' => $no_of_post,

			                   'slide_duration'=> $slide_duration

							 );

		$insert = $this->nlp_model->insert('assets_apps',$insert);

		if($insert)
		{
			echo "1";
		}
		else
		{
			echo  "2";
		}


	}


	public function ajax_add_twitter()  //clent insert
	{
      
		$app_name      = $this->input->post('app_name');

		$user_id       = $this->session->userdata('user_id');
        

		$insert          = array(
			                   'user_id'    => $user_id,
			                   
			                   'app_id'     => 4,

			                   'path_type'  => 'App',

			                   'file_from'  => 'assets',

			                   'app_img'    => 'twitter.jpg',
			                   
			                   'app_name'   => $app_name

							 );

		$insert = $this->nlp_model->insert('assets_apps',$insert);

		if($insert)
		{
			echo "1";
		}
		else
		{
			echo  "2";
		}


	}


	 public function ajax_add_html()  //clent insert
	{
      
		$app_name      = $this->input->post('app_name');
        
        $app_url       = $this->input->post('app_url');

        $app_cache     = $this->input->post('cache');

        $user_id       = $this->session->userdata('user_id');

		$insert          = array(
			                   'user_id'    => $user_id,
			                   
			                   'app_id'     => 5,

			                   'path_type'  => 'App',

			                   'file_from'  => 'assets',

			                   'app_img'    => 'html5-3.png',
			                   
			                   'app_name'   => $app_name,

			                   'app_url'    => $app_url,

			                   'cache'      => $app_cache

							 );

		$insert = $this->nlp_model->insert('assets_apps',$insert);
      
		if($insert)
		{
			echo "1";
		}
		else
		{
			echo  "2";
		}


	}

	

    public function assets_profile($id=false)
    {

       $data['clients_profile'] = $this->nlp_model->select('assets_apps',array('id'=>$this->uri->segment(3)));
      
      	$this->load->view('admin/assets');
 
	}
    

	public function my_plan()
	{
		$this->load->view('admin/my_plan');
	}
    

    public function my_report()
	{
		$this->load->view('admin/invoice_reports');
	}

	public function my_invoice()
	{
		$this->load->view('admin/invoice_view');
	}

	public function employees_list()
	{

		
		$this->load->view('admin/employees_list');

	}

	public function employees()
	{  

		$employees_list = $this->nlp_model->select_order('users');

	    if($employees_list->num_rows()>0)
		 {  

		 	$data['employees_list'] = $employees_list->result();


		 }
		 else
		 {

		 	$data['employees_list'] = array();
		 }

		
		$this->load->view('admin/employees',$data);

	}
    	
    public function exportCSV()
    { 
      $file_name = 'users_details_on_'.date('Ymd').'.csv'; 
     header("Content-Description: File Transfer"); 
     header("Content-Disposition: attachment; filename=$file_name"); 
     header("Content-Type: application/csv;");
   
     // get data 
     $student_data = $this->nlp_model->select_order('users');

     // file creation 
     $file = fopen('php://output', 'w');
 
    //  $header = array("Student Name","Student Phone"); 
     fputcsv($file);
     foreach ($student_data->result_array() as $key => $value)
     { 
       fputcsv($file, $value); 
     }
     fclose($file); 
     exit;
       
    }

	public function ajax_add_employee()
	{


		$user_name     = $this->input->post('user_name');

		$email         = $this->input->post('email');

		$password      = $this->input->post('password');

		$employee_id   = $this->input->post('employee_id');

		$phone_no      = $this->input->post('phone_no');

		$mob_reg_code  = $this->random_strings(8);
        

		$insert = array(
                        	'mob_reg_code'=> $mob_reg_code,

                        	'user_login_name'=> $user_name,
                        	
                        	'user_login_email'=> $email,

                        	'employee_id'=> $employee_id,
                        	
                        	'user_password'=> $password,
                        	
                        	'phone_no'=> $phone_no,

                        	'user_role'=> '2',

                        	'status' =>'2',

                        	'created_at' =>date('Y-m-d H:i:s')

                        );
        
		$insert = $this->nlp_model->insert('users',$insert);

		if($insert)
		{
			echo "1";
		}
		else
		{
			echo  "2";
		}



		//print_r($insert);
	}

	public function random_strings($length_of_string) 
	{ 
	    $str_result = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'; 
	  
	    return substr(str_shuffle($str_result),  
	                       0, $length_of_string); 
	} 
	   

	public function ajax_edit_employee()
	{

		$user_id       = $this->input->post('edit_user_id');

		$user_name     = $this->input->post('edit_user_name');
		
		$employee_id   = $this->input->post('edit_employee_id');

		$email         = $this->input->post('edit_email');

		$password      = $this->input->post('edit_password');

		$phone_no      = $this->input->post('edit_phone');

		$update = array(
                        	'user_login_name'=> $user_name,

                        	'employee_id'=> $employee_id,
                        	
                        	'user_login_email'=> $email,
                        	
                        	'user_password'=> $password,
                        	
                        	'phone_no'=> $phone_no,

                        	'created_at' =>date('Y-m-d H:i:s')

                        );
        // echo "<pre>";
        // print_r($update);exit;
		$update_status = $this->nlp_model->update('users',$update,array('user_id'=>$user_id));
        // echo $this->db->last_query();exit;
		if($update_status)
		{
			echo "1";
		}
		else
		{
			echo "2";
		}

		
	} 
	
	public function ajax_employee_status()
	{
	  $user_status = $this->input->post('user_status');
	 
	  $user_id     = $this->input->post('status_user_id');
	  
	  $update      = array(
	                      'status' => $user_status
	      ); 
	  
	  $update_status = $this->nlp_model->update('users',$update,array('user_id'=>$user_id));
        // echo $this->db->last_query();exit;
		if($update_status)
		{
			echo "1";
		}
		else
		{
			echo "2";
		}    
	  
	}
	
	public function ajax_delete_employee()
	{
		$user_id = $this->input->post('user_id');

// 		$update = array('status'=>'3');

		$update_status = $this->nlp_model->delete('users',array('user_id'=>$user_id));
		if($update_status)
		{
			echo "1";
		}
		else
		{
			echo "2";
		}
	}

	public function update_mob_reg_code()
	{

		$user_id       = $this->session->userdata('user_id');

		$mob_reg_code  = $this->input->post('registration_code');
		
		$update = array(
                        	'mob_reg_code_status'=> 1,
      
                        	'created_at' =>date('Y-m-d H:i:s')

                        );
        // echo "<pre>";
        // print_r($update);exit;
		$update_status = $this->nlp_model->update('users',$update,array('mob_reg_code'=>$mob_reg_code,'user_id'=>$user_id));
        // echo $this->db->last_query();exit;
		if($update_status)
		{
			echo "1";
		}
		else
		{
			echo "2";
		}

		
	} 
    
    public function composition_temp()
    {
    	$template     = $this->uri->segment(3);

        $user_id       = $this->session->userdata('user_id');

	    $file_from     = $this->input->post('file_from');
      

        if(!empty($_FILES['profile_picture']['name']))
        { 
            
        	$this->load->library('image_lib');

            $_FILES['file']['name']     = $_FILES['profile_picture']['name'];
            
            $_FILES['file']['type']     = $_FILES['profile_picture']['type'];
           
            $_FILES['file']['tmp_name'] = $_FILES['profile_picture']['tmp_name'];
            
            $_FILES['file']['error']    = $_FILES['profile_picture']['error'];
            
            $_FILES['file']['size']     = $_FILES['profile_picture']['size'];
                

            $uploadPath = 'images/profiles/';
            
            $config['upload_path'] = $uploadPath;
            
            $config['allowed_types'] = 'jpg|jpeg|png|gif|mp4';
		    
		    $config['overwrite'] = FALSE;
            
            
			$fileName = $_FILES['file']['name'];

			$fileSize = $_FILES['file']['size'];
			
			$config['file_name'] = $fileName; 
				
                // Load and initialize upload library
            $this->load->library('upload', $config);   
            
            $this->upload->initialize($config);
               
             // Upload file to server
            if($this->upload->do_upload('file'))
            { 
                // Uploaded file data
                 $fileData = $this->upload->data(); 
                 
                 $profile_picture =  $fileData['file_name']; 
             // echo 333;
            } 
            			
			$ext = pathinfo($fileName, PATHINFO_EXTENSION);
            // echo 'durat'.$slide_duration;exit;

			if($ext == 'png'){
				$app_img = 'img-icon.png';
				$type = 'Image';
			}
			if($ext == 'jpg'){
				$app_img = 'img-icon.png';
				$type = 'Image';
			}
			if($ext == 'jpeg'){
				$app_img = 'img-icon.png';
				$type = 'Image';
			}
			if($ext == 'mp4')
			{
				$app_img = 'video.jpg';
				$type = 'Video';
			}

			$insert          = array(
					                   
					                   'path_type'    => $type,

					                   'app_img'      => $app_img,

					                   'app_url'      => 'https://sirisigns.xyz/signage/'.$config['upload_path'].$profile_picture,

					                   'user_id'      => $user_id,

					                   'app_size'     => $fileSize,

					                   'template'     => $template,
					                   
					                   'file_from'    => $file_from,

									 );
			
				$data = $this->nlp_model->insert('assets_apps',$insert);
		        // echo $this->db->last_query();exit;
		        if($data == 1)
				{
					$this->load->view('admin/composition_temp',$data);
				}
				else
				{
					$this->load->view('admin/composition_temp',$data);
				}
		        
		}
		$this->temp['id'] = $this->uri->segment(3);
        $this->session->set_userdata(array('template' => $this->uri->segment(3)));
    	$this->load->view('admin/composition_temp',$this->temp);        
    }
    

     public function asset_schedule()
	{  
        if($this->session->userdata('user_role') == 1)
        {
                            
		$schedule_list = $this->nlp_model->select_order('assets_schedule',array('schedule_status'=>1));
        }else{
        $schedule_list = $this->nlp_model->select_order('assets_schedule',array('user_id'=>$this->session->userdata('user_id'),'schedule_status'=>1));	
        }
	    if($schedule_list->num_rows()>0)
		 {  

		 	$data['schedule_list'] = $schedule_list->result();


		 }
		 else
		 {

		 	$data['schedule_list'] = array();
		 }

		
		$this->load->view('admin/schedule',$data);

	}
    
    public function template_table()
    {

    	$id = $this->input->post('id');
        // print_r($id);exit;
        // $this->data['comp_id'] = $id; 
        // print_r($this->data);exit;
        if($this->session->userdata('template') == 'temp_1')
        {
        	$temp = 1;

        }elseif($this->session->userdata('template') == 'temp_2')
        {
        	$temp = 2;
        }elseif($this->session->userdata('template') == 'temp_3')
        {
        	$temp = 3;
        }elseif($this->session->userdata('template') == 'temp_4')
        {
        	$temp = 2;
        }else{
            $temp = 1;
        }

        $array_val = json_encode($id);
        
        $comp_count = count($id);

		$html = '';

        $html.= '<div class="submit-section">
                 <button type="button" id="display_button" data-toggle="modal"  class="btn add-btn" data-target="#preview_template_multiple" onclick="display_temp()">Preview Display</button>
                 <form id="formcomposition" method="post">
                 <input type="hidden" value="'.$comp_count.'" id="display_count">
                 <input type="hidden" value="'.$temp.'" id="display_id">
                 <input type="hidden" value="'.$id.'" id="temp_id">
                 <input type="hidden" value="'.$array_val.'"  name="comp_id">
				 <input type="submit" class="btn add-btn">
				 </form>
				 </div><div class="table-responsive"><table class="table table-striped table-nowrap custom-table mb-0 datatable">
									<thead>
										<tr>
										    <th>Composition</th>
											<th>Content Name</th>
										</tr>
									</thead>
									<tbody>';

                             foreach($id as $val)
                             {
                             	// echo $val;
                             $row = $this->nlp_model->select_order('assets_apps',array('id'=>$val))->row();
                                
                                   $html.='<tr>';
                                   if($row->path_type!='Video'){
                                   	$html.='<td><img src="'.$row->app_url.'" width="100" height="60"></td>';
                                   }else{
                                   	$html.='<td><iframe width="150px" height="100px;" src="'.$row->app_url.'"></iframe></td>';
                                   }
						 	    	$html.='<td>'.date('Y-d-F h:i A', strtotime($row->created_at)).'</td>
                                    
                                    </tr>';
                            }
									$html.='</tbody>
                    </table></div>';
        echo $html;

    }
    
    public function preview_composition()
    {
    	$get_id = $this->input->post('id');
        
        $tmp = $this->session->userdata('template');


        $cou = count($get_id);
        
        $modal = '';
        
        $modal.='<div class="row">';
        
        if($cou == 1 && $tmp == 'temp_1')
        {
	        foreach($get_id as $row=>$value)
	        {
	             
	    	  $select = $this->nlp_model->select('assets_apps',array('id'=>$value))->row();
	         
	    	  $modal.='<div class="col">';
							if($select->path_type != 'Video')
							{ 
	                          $modal.='<img src="'.$select->app_url.'" width="800" height="400">';
							}else{
							  $modal.='<iframe type="text/html" width="800" height="400" src="http://www.youtube.com/embed/M7lc1UVf-VE?autoplay=1&origin="'.$select->app_url.'"></iframe>';
							}
										
			  $modal.='</div>';
	        }
        }elseif($cou == 2 && $tmp == 'temp_2')
        {
        	foreach($get_id as $row=>$value)
	        {
	             
	    	  $select = $this->nlp_model->select('assets_apps',array('id'=>$value))->row();
	         
	    	  $modal.='<div class="col-md-6">';
							if($select->path_type != 'Video')
							{ 
	                          $modal.='<img src="'.$select->app_url.'" width="400" height="400">';
							}else{
							  $modal.='<iframe type="text/html" width="400" height="400" src="http://www.youtube.com/embed/M7lc1UVf-VE?autoplay=1&origin="'.$select->app_url.'"></iframe>';
							}
										
			  $modal.='</div>';
	        }
        }elseif($cou == 3 && $tmp == 'temp_3')
        {
        	foreach($get_id as $row=>$value)
	        {
	             
	    	  $select = $this->nlp_model->select('assets_apps',array('id'=>$value))->row();
	         
	    	  $modal.='<div class="col-md-6">';
							if($select->path_type != 'Video')
							{ 
	                          $modal.='<img src="'.$select->app_url.'" width="400" height="400">';
							}else{
							  $modal.='<iframe type="text/html" width="400" height="400" src="http://www.youtube.com/embed/M7lc1UVf-VE?autoplay=1&origin="'.$select->app_url.'"></iframe>';
							}
										
			$modal.='</div>';
	        }
        }elseif($cou == 2 && $tmp == 'temp_4')
        {
        	foreach($get_id as $row=>$value)
	        {
	             
	    	  $select = $this->nlp_model->select('assets_apps',array('id'=>$value))->row();
	         
	    	  $modal.='<div class="col-md-12">';
							if($select->path_type != 'Video')
							{ 
	                          $modal.='<img src="'.$select->app_url.'" width="800" height="200">';
							}else{
							  $modal.='<iframe type="text/html" width="800" height="200" src="http://www.youtube.com/embed/M7lc1UVf-VE?autoplay=1&origin="'.$select->app_url.'"></iframe>';
							}
										
			$modal.='</div>';
	        }
        }else{
           foreach($get_id as $row=>$value)
	        {
	             
	    	  $select = $this->nlp_model->select('assets_apps',array('id'=>$value))->row();
	         
	    	  $modal.='<div class="col-md-12">';
							if($select->path_type != 'Video')
							{ 
	                          $modal.='<img src="'.$select->app_url.'" width="230" height="400">';
							}else{
							  $modal.='<iframe type="text/html" width="230" height="400" src="http://www.youtube.com/embed/M7lc1UVf-VE?autoplay=1&origin="'.$select->app_url.'"></iframe>';
							}
										
			$modal.='</div>';
	        }	
        }
        
        $modal.='</div>';

        echo $modal;

    }


    public function composition_array_create()
    {
    	 
    	$id   = $this->input->post("comp_id");
        $uri  = count($id);
        // $uri  = $this->input->post('template');

        $data = array(
                
                'comp_id' => json_encode($id),

                'template' => $this->session->userdata('template'),

                'user_id'=> $this->session->userdata('user_id'),
                
                'created_at' =>date('Y-m-d H:i:s')


                );
        // print_r($data);exit;
        $insert = $this->nlp_model->insert('assets_schedule',$data);

        if($insert == 1)
		{
			echo "1";
		}
		else
		{
			echo "2";
		}        
       
    }

    public function ajax_delete_composition()
    {
    	$id = $this->input->post('id');
        
		$update_status = $this->nlp_model->delete('assets_schedule',array('id'=>$id));

		if($update_status)
		{
			echo "1";
		}
		else
		{
			echo "2";
		}
    }

    public function schedule_calander()
    {
    	$this->load->view('admin/schedule_calander');
    }

    public function getStart()
    {
         // $sart_d = $this->input->post('start');
         $user_name     = $this->input->post('start');
          // echo 'date-'.$user_name;exit;
         if($user_name)
         {
           $this->session->set_userdata(array('start_d' =>$user_name));
           echo "1";
         }else{
           echo "2";
         }
    }

    public function create_schedule()
    {
        if($this->session->userdata('user_role') == 1)
        {
		$assets_schedule = $this->nlp_model->select_order('assets_schedule',array('schedule_status'=>2));
        }else{
        $assets_schedule = $this->nlp_model->select_order('assets_schedule',array('user_id'=>$this->session->userdata('user_id'),'schedule_status'=>2));
        	
        }
	    if($assets_schedule->num_rows()>0)
		 {  

		 	$data['assets_schedule'] = $assets_schedule->result();


		 }
		 else
		 {

		 	$data['assets_schedule'] = array();
		 }

        $this->load->view('admin/create_schedule',$data);
    }



    public function assign_schedule()
    {
       
		$user_name     = $this->input->post('comp_id');

		$email         = $this->input->post('start_date');

		$password      = $this->input->post('start_time');

		$employee_id   = $this->input->post('end_date');

		$phone_no      = $this->input->post('end_time');

		$this->form_validation->set_rules('comp_id', 'Composition', 'required');

		$this->form_validation->set_rules('start_date', 'Start Date', 'required');

			$insert = array(
	                        	
	                        	'start_date'=> $email,

	                        	'end_date'=> $employee_id,
	                        	
	                        	'start_time'=> $password,
	                        	
	                        	'end_time'=> $phone_no,

	                        	'user_id'=> $this->session->userdata('user_id'),

	                        	'schedule_status' => 1,

	                        	'created_at' =>date('Y-m-d H:i:s')

	                        );
	       
				$insert = $this->nlp_model->update('assets_schedule',$insert,array('id'=>$user_name));
		        
		        if($insert)
		        {
				 echo "1";
			    }else{
			    	echo "2";
			    }
				
	 
        	

    }

    public function startCall()
    {
    	$this->load->view('admin/create_schedule');
    }

	public function error_404()
	{

		
		$this->load->view('admin/error_404');

	}

	public function error_500()
	{

		
		$this->load->view('admin/error_500');

	}

    public function plans()
    {

		$plan_list = $this->nlp_model->select_order('subscribe_plans');

	    if($plan_list->num_rows()>0)
		 {  

		 	$data['plan_list'] = $plan_list->result();


		 }
		 else
		 {

		 	$data['plan_list'] = array();
		 }

    	$this->load->view('admin/subscriptions');
    }

    public function update_plan()
    {

		$plan_id          = $this->input->post('plan_id');
       
		$plan_name        = $this->input->post('plan_name');
        
        $plan_price       = $this->input->post('plan_price');

        $plan_type        = $this->input->post('plan_type');

        $plan_storage     = $this->input->post('plan_storage');

        $plan_description = $this->input->post('plan_description');

        $plan_status      = $this->input->post('plan_status');

        $user_id          = $this->session->userdata('user_id');

		$insert           = array(
			                   
			                   'user_id'    => $user_id,
			                   
			                   'name'  => $plan_name,

			                   'price'  => $plan_price,

			                   'type'  => $plan_type,

			                   'storage'    => $plan_storage,

			                   'description'   => $plan_description,

			                   'status' => 1
							 );
        
		$insert = $this->nlp_model->update('subscribe_plans',$insert,array('id'=>$plan_id));
       
		if($insert)
		{
			echo "1";
		}
		else
		{
			echo  "2";
		}

    }


    public function webscreen()
    {
    	  $this->load->view('temp_2');
        
        
    }

}
