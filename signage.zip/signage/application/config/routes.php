<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller']     = 'login';

$route['404_override']           = '';

$route['translate_uri_dashes']   = FALSE;

$route['home']                   =   'home';

$route['activities']             =   'Home/activities';

$route['assets']                 =   'Home/assets';

$route['attendance_employee']    =   'Home/attendance_employee';

$route['attendance']             =   'Home/attendance';

$route['blank_page']             =   'Home/blank_page';

$route['change_password']        =   'Home/change_password';

$route['chat']                   =   'Home/chat';

$route['client_profile']         =   'Home/client_profile';

$route['clients_list']           =   'Home/clients_list';

$route['clients']                =   'Home/clients';

$route['components']             =   'Home/components';

$route['compose']                =   'Home/compose';

$route['contacts']               =   'Home/contacts';

$route['create_estimate']        =   'Home/create_estimate';

$route['create_invoice']         =   'Home/create_invoice';

$route['data_tables']            =   'Home/data_tables';

$route['departments']            =   'Home/departments';

$route['designations']           =   'Home/designations';

$route['edit_estimate']          =   'Home/edit_estimate';

$route['edit_invoice']           =   'Home/edit_invoice';

$route['email_settings']         =   'Home/email_settings';

$route['employee_dashboard']     =   'Home/employee_dashboard';

$route['employees_list']         =   'Home/employees_list';

$route['employees']              =   'Home/employees';

$route['error_404']              =   'Home/error_404';

$route['error_500']              =   'Home/error_500';

$route['estimate_view']          =   'Home/estimate_view';

$route['estimates']              =   'Home/estimates';

$route['events']                 =   'Home/events';

$route['expense_reports']        =   'Home/expense_reports';

$route['expenses']               =   'Home/expenses';

$route['faq']                    =   'Home/faq';

$route['file_manager']           =   'Home/file_manager';

$route['forgot_password']        =   'Home/forgot_password';

$route['form_basic_inputs']      =   'Home/form_basic_inputs';

$route['form_horizontal']        =   'Home/form_horizontal';

$route['form_input_groups']      =   'Home/form_input_groups';

$route['form_mask']              =   'Home/form_mask';

$route['form_validation']        =   'Home/form_validation';

$route['form_vertical']          =   'Home/form_vertical';

$route['goal_tracking']          =   'Home/goal_tracking';

$route['goal_type']              =   'Home/goal_type';

$route['holidays']               =   'Home/holidays';

$route['inbox']                  =   'Home/inbox';

$route['incoming_call']          =   'Home/incoming_call';

$route['invoice_reports']        =  'Home/invoice_reports';

$route['invoice_settings']       =  'Home/invoice_settings';

$route['invoice_view']           =  'Home/invoice_view';

$route['invoices']               =  'Home/invoices';

$route['job_applicants']         =  'Home/job_applicants';

$route['job_details']            =  'Home/job_details';

$route['job_list']               =  'Home/job_list';

$route['job_view']               =  'Home/job_view';

$route['jobs']                   =  'Home/jobs';

$route['knowledgebase_view']     =  'Home/knowledgebase_view';

$route['knowledgebase']          =  'Home/knowledgebase';
    
$route['leads']                  =  'Home/leads';
    
$route['leave_settings']         =  'Home/leave_settings';
    
$route['leave_type']             =  'Home/leave_type';
    
$route['leaves_employee']        =  'Home/leaves_employee';
    
$route['leaves']                 =  'Home/leaves';
    
$route['localization']           =  'Home/localization';
    
$route['lock_screen']            =  'Home/lock_screen';
    
$route['login']                  =  'login';
    
$route['notifications_settings'] =  'Home/notifications_settings';
    
$route['otp']                    =  'Home/otp';
    
$route['outgoing_call']          =  'Home/outgoing_call';
    
$route['overtime']               =  'Home/overtime';
    
$route['payments']               =  'Home/payments';
    
$route['payroll_items']          =  'Home/payroll_items';
    
$route['performance_appraisal']  =  'Home/performance_appraisal';
    
$route['performance_indicator']  =  'Home/performance_indicator';
    
$route['performance']            =  'Home/performance';
    
$route['policies']               =  'Home/policies';
    
$route['privacy_policy']         =  'Home/privacy_policy';
    
$route['profile']                =  'Home/profile';
    
$route['project_list']           =  'Home/project_list';
    
$route['project_view']           =  'Home/project_view';
    
$route['projects']               =  'Home/projects';
    
$route['promotion']              =  'Home/promotion';
    
$route['provident_fund']         =  'Home/provident_fund';
    
$route['register']               =  'Home/register';
    
$route['resignation']            =  'Home/resignation';

$route['roles_permissions']      =  'Home/roles_permissions';
    
$route['salary_settings']        =  'Home/salary_settings';
    
$route['salary_view']            =  'Home/salary_view';
    
$route['salary']                 =  'Home/salary';
    
$route['search']                 =  'Home/search';
    
$route['settings']               =  'Home/settings';
    
$route['subscribed_companies']   =  'Home/subscribed_companies';
    
$route['subscriptions_company']  =  'Home/subscriptions_company';
    
$route['subscriptions']          =  'Home/subscriptions';
    
$route['tables_basic']           =  'Home/tables_basic';
    
$route['task_board']             =  'Home/task_board';
    
$route['tasks']                  =  'Home/tasks';
    
$route['taxes']                  =  'Home/taxes';
    
$route['termination']            =  'Home/termination';
    
$route['terms']                  =  'Home/terms';
    
$route['theme_settings']         =  'Home/theme_settings';
    
$route['ticket_view']            =  'Home/ticket_view';
    
$route['tickets']                =  'Home/tickets';
    
$route['timesheet']              =  'Home/timesheet';
    
$route['trainers']               =  'Home/trainers';
    
$route['training_type']          =  'Home/training_type';
    
$route['training']               =  'Home/training';
    
$route['users']                  =  'Home/users';
    
$route['video_call']             =  'Home/video_call';
    
$route['voice_call']             =  'Home/voice_call';

$route['attendance_dashboard']   =  'Home/attendance_dashboard';
 


