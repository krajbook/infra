<?php $schedule_list = $schedule_list;?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
        <title>Schedule list </title>

        <?php $this->load->view('common_css_js/css'); ?>
		
    </head>
    <body>
		<!-- Main Wrapper -->
        <div class="main-wrapper">
		
			<!-- Header -->
        <?php $this->load->view('common/set_header'); ?>
			<!-- Header -->
            <?php $this->load->view('common_css_js/side_header'); ?>
			<!-- /Sidebar -->
			
			<!-- Page Wrapper -->
            <div class="page-wrapper">
			
				<!-- Page Content -->
                <div class="content container-fluid">
				
					<!-- Page Header -->
					<div class="page-header">
						<div class="row align-items-center">
							<div class="col">
								<h3 class="page-title">Schedule</h3>
								<ul class="breadcrumb">
									<li class="breadcrumb-item"><a href="<?php echo base_url(); ?>">Dashboard</a></li>
									<li class="breadcrumb-item active">Schedule</li>
								</ul>
							</div>
							<div class="col-auto float-right ml-auto">
						<?php if($this->session->userdata('mob_reg_code_status') == 1 || $this->session->userdata('user_role') == 1){ ?>
							<a href="<?php echo base_url(); ?>admin_dashboard/schedule_calander" class="btn add-btn"><i class="fa fa-plus"></i>Create Schedule</a>
						<?php }else{ ?>
                                 <p>Please submit your registration code before create assets...</p>
						<?php } ?>		 
							</div>
							
						</div>
					</div>
					<!-- /Page Header -->
					
					<!-- Search Filter -->
					<!--<div class="row filter-row">-->
					<!--	<div class="col-sm-6 col-md-3">  -->
					<!--		<div class="form-group form-focus">-->
					<!--			<input type="text" class="form-control floating">-->
					<!--			<label class="focus-label">User ID</label>-->
					<!--		</div>-->
					<!--	</div>-->
					<!--	<div class="col-sm-6 col-md-3">  -->
					<!--		<div class="form-group form-focus">-->
					<!--			<input type="text" class="form-control floating">-->
					<!--			<label class="focus-label">user Name</label>-->
					<!--		</div>-->
					<!--	</div>-->
					<!--	<div class="col-sm-6 col-md-3"> -->
					<!--		<div class="form-group form-focus select-focus">-->
					<!--			<select class="select floating"> -->
					<!--				<option>Select Designation</option>-->
					<!--				<option>Web Developer</option>-->
					<!--				<option>Web Designer</option>-->
					<!--				<option>Android Developer</option>-->
					<!--				<option>Ios Developer</option>-->
					<!--			</select>-->
					<!--			<label class="focus-label">Designation</label>-->
					<!--		</div>-->
					<!--	</div>-->
					<!--	<div class="col-sm-6 col-md-3">  -->
					<!--		<a href="#" class="btn btn-success btn-block"> Search </a>  -->
					<!--	</div>-->
     <!--               </div>-->
					<!-- Search Filter -->
		           
						<div class="row">
						<div class="col-md-12">
							<div class="table-responsive">
					
								<table class="table table-striped table-nowrap custom-table mb-0 datatable">
									<thead>
										<tr>
											<th>#</th>
											<th>Schedule</th>
											<th>Start Date</th>
											<th>Start Time</th>
											<th>End Date</th>
											<th>End Time</th>
										</tr>
									</thead>
									<tbody>
									<?php 
									
									if(!empty($schedule_list))
						            {
						                $i = 1;
            							foreach ($schedule_list as $schedule_list_value) 
            							{ ?>
									<tr>
									<td><?php echo $i++; ?></td>
									<td><?php echo $schedule_list_value->id; ?></td>
									<td><?php echo $schedule_list_value->start_date; ?></td>
									<td><?php if($schedule_list_value->start_time != ''){ echo date('h:i A', strtotime($schedule_list_value->start_time)); }else{ echo "";}?></td>
									<td><?php echo $schedule_list_value->end_date; ?></td>
									<td><?php if($schedule_list_value->end_time != ''){echo date('h:i A', strtotime($schedule_list_value->end_time)); }else{ echo "";} ?></td>
									</tr>
									<?php } 
									} ?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
                </div>
				<!-- /Page Content -->
				
				
            </div>
			<!-- /Page Wrapper -->
			
        </div>
		<!-- /Main Wrapper -->
		
		<!-- jQuery -->
       <?php $this->load->view('common_css_js/footer_js');?>
		<script type="text/javascript">
    
     function lead_function($id)
      {
          $("#status_user_id").val($id);
      }

	$(document).on("submit", "#employee_add", function (event) 
	{
		//$('#myModal').modal('hide'); 

		//alert(); 

		//return false;
		
		event.preventDefault(); 

        $.ajax({
			                   type: "POST",
			                   url: "<?php echo site_url().'admin_dashboard/ajax_add_employee'; ?>",
			                   data: $("#employee_add").serialize(), 
			                   success: function(data)
			                   {

			                   	//alert(data);
			                   //	console.log(date);

			                   	//return false;

                             
			                        if(data =='1')
			                        {    



			                              swal("Success!", "Employee Details Added Successfully", "success");
			                              $( '#employee_add' ).each(function()
			                              {
			                                this.reset();
			                               $( ".close" ).click();
			                               location.reload();
			                                //$( ".page-title" ).text('ss');

			                             });

			                        }
			                        else
			                        {

			                        	swal("Failed!", "Try Again Later.", "error");
			                              $( '#employee_add' ).each(function()
			                              {
			                                //this.reset();
			                               //$( "#cancel_model" ).click();

			                             });

			                        	

			                        }
			                   }
                });


    });

    $(document).on("click", ".edit_employee_model", function (event) 
    {
    	
   	//  	alert($(this).data('user_id'));
    	$('#edit_user_id').val($(this).data('user_id'));
    	$('#edit_user_name').val($(this).data('user_name'));
    	$('#edit_employee_id').val($(this).data('employee_id'));
    	$('#edit_email').val($(this).data('email'));
    	$('#edit_password').val($(this).data('password'));
    	$('#confirm_password').val($(this).data('confirm_password'));
    	$('#edit_phone').val($(this).data('phone_no'));
        $('#edit_status').val($(this).data('status'));
    	

        $('select[name=edit_employee_role]').val($(this).data('employee_role'));
        var select_value = $("#edit_employee_role option[value="+$(this).data('employee_role')+"]").text();
        $('#select2-edit_employee_role-container').text(select_value);

         //alert($(this).data('department'));
         $('select[name=edit_department]').val($(this).data('department'));
        var select_department = $("#edit_department option[value="+$(this).data('department')+"]").text();
        $('#select2-edit_department-container').text(select_department);

         //alert($(this).data('department'));
         $('select[name=edit_designation]').val($(this).data('designation'));
        var select_designation = $("#edit_designation option[value="+$(this).data('designation')+"]").text();
        $('#select2-edit_designation-container').text(select_designation);



    	//$('#edit_department').val($(this).data('department'));
    	//$('#edit_designation').val($(this).data('designation'));
    	 //$("#edit_employee_role]").val();
    	$('#user_id').val($(this).data('user_id'));
    
    });

    $(document).on("submit", "#employee_edit", function (event) 
	{
		event.preventDefault(); 
		
        $.ajax({
			                   type: "POST",
			                   url: "<?php echo site_url().'admin_dashboard/ajax_edit_employee'; ?>",
			                   data: $("#employee_edit").serialize(), 
			                   success: function(data)
			                   {

			                   	//alert(data);
			                   ///console.log(data);

			                   //return false;

                             
			                        if(data =='1')
			                        {    

			                        	$('#change_user_name').val();


			                            swal("Success!", "Employee Details Updated Successfully", "success");



			                              //alert(); return false;
			                              $( '#employee_edit' ).each(function()
			                              {
			                                this.reset();
			                               $( ".close" ).click();
			                               location.reload();
			                                //$( ".page-title" ).text('ss');

			                             });

			                        }
			                        else
			                        {

			                        	swal("Failed!", "Try Again Later.", "error");
			                              $( '#employee_edit' ).each(function()
			                              {
			                                //this.reset();
			                               //$( "#cancel_model" ).click();

			                             });

			                        	

			                        }
			                   }
                });


    });
    
    
    $(document).on("submit", "#employee_status", function (event) 
	{
		event.preventDefault(); 
		
        $.ajax({
			                   type: "POST",
			                   url: "<?php echo site_url().'admin_dashboard/ajax_employee_status'; ?>",
			                   data: $("#employee_status").serialize(), 
			                   success: function(data)
			                   {
                             
			                        if(data =='1')
			                        {    

			                        	$('#change_user_name').val();


			                            swal("Success!", "User Status Updated Successfully", "success");



			                              //alert(); return false;
			                              $( '#employee_status' ).each(function()
			                              {
			                                this.reset();
			                               $( ".close" ).click();
			                               location.reload();
			                                //$( ".page-title" ).text('ss');

			                             });

			                        }
			                        else
			                        {

			                        	swal("Failed!", "Try Again Later.", "error");
			                              $( '#employee_status' ).each(function()
			                              {
			                                //this.reset();
			                               //$( "#cancel_model" ).click();

			                             });

			                        	

			                        }
			                   }
                });


    });

    $(document).on("click", ".delete_employee", function (event) 
    {
    	
   	 	//alert($(this).data('user_id'));

   	 	$("#comform_delete").attr('data-user_id', $(this).data('user_id'));
    
    });

     $(document).on("click", "#comform_delete", function () 
	{
		
       /*alert($(this).data('user_id'));
		return  false;*/
		//$(this).attr('','');

		var user_id = $(this).data('user_id');
		
        $.ajax({
			                   type: "POST",
			                   url: "<?php echo site_url().'admin_dashboard/ajax_delete_employee'; ?>",
			                   data: {'user_id':$(this).data('user_id')}, 
			                   success: function(data)
			                   {

			                       // alert(data);
			                        //console.log(data);

			                        //return false;

                             
			                        if(data =='1')
			                        {    

			                        	/*$('#change_user_name').text($('#edit_first_name').val()+' '+$('#edit_last_name').val());

			          
			                        	$('#change_designation').text($("#edit_designation option:selected").text());*/

			                        	//alert(user_id);

			                        	$('#eemployees_list_'+user_id).hide();


			                            swal("Success!", "Employee Details Deleted Successfully", "success");

                                         $('#modal-content').hide();

                                         $(".cancel-btn").click();
			                             location.reload();
			                                

			                        }
			                        else
			                        {

			                        	swal("Failed!", "Try Again Later.", "error");
			                              $( '#employee_edit' ).each(function()
			                              {
			                                //this.reset();
			                               //$( "#cancel_model" ).click();

			                             });

			                        	

			                        }
			                   }
                });


    });
    
    
    


</script>
    </body>
    
</html>