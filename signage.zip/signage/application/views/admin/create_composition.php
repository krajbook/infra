﻿<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
        <title>Create Composition</title>
		
		<!-- Favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url(); ?>assets\img\faviconbg.png">
		
		<!-- Bootstrap CSS -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets\css\bootstrap.min.css">
		
		<!-- Fontawesome CSS -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets\css\font-awesome.min.css">
		
		<!-- Lineawesome CSS -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets\css\line-awesome.min.css">
		
		<!-- Main CSS -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets\css\style.css">
		
		<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!--[if lt IE 9]>
			<script src="<?php echo base_url(); ?>assets/js/html5shiv.min.js"></script>
			<script src="<?php echo base_url(); ?>assets/js/respond.min.js"></script>
		<![endif]-->
       <style>
        .card {
            word-wrap: break-word;
        }
        .perpendicular-line {
		  width: 50%;
		  margin: auto;
		  margin-top: 10%;
		  margin-bottom: 0;
		  transform: rotate(90deg);
		  border-color: #1A85FD;
		}
    </style>
    </head>
    <body>
		<!-- Main Wrapper -->
        <div class="main-wrapper">
		
			<!-- Header -->
            <?php $this->load->view('common/set_header'); ?>
			<!-- Header -->
            <?php $this->load->view('common_css_js/side_header'); ?>
			
			<!-- Page Wrapper -->
            <div class="page-wrapper">
			
				<!-- Page Content -->
                <div class="content container-fluid">
					
					<!-- Page Header -->
					<div class="page-header">
						<div class="row filter-row">
							<div class="col-sm-6">
								<h3 class="page-title">Create Composition</h3>
								<ul class="breadcrumb">
									<li class="breadcrumb-item"><a href="<?php echo base_url(); ?>">Dashboard</a></li>
									<li class="breadcrumb-item active">Create Composition</li>
								</ul>
								
							</div>
						</div>
					</div>
					<!-- /Page Header -->
                 <!-- Template area start -->
                <div class="row">
	                 <div class="col-sm-5 card-body" style="border-style: solid; background-color:#fff;width:200px;height:250px;">
	                   <a href="<?php echo base_url(); ?>admin_dashboard/composition_temp/temp_1">
	                     <p style="padding-top:50px;" align="center">Zone 1</p>
	                   </a>
	                 </div>
	                 <div class="col-md-1"></div>
	                 <div class="col-sm-5 card-body" style="border-style: solid; background-color:#fff;width:200px;height:250px;">
		                 <a href="<?php echo base_url(); ?>admin_dashboard/composition_temp/temp_2">
			                 <div class="row">
			                 	<div class="col-md-6">
					                 <p style="padding-top:50px;" align="center">Zone 1</p>
					             </div>
					             <div class="col-md-6">
					                 <p style="padding-top:50px;" align="center">Zone 2</p>
					             </div>
		                     </div>
	                    </a>
	                 </div>
                </div>
                <div class="row">
                	<div class="col-sm-6"><p align="left">One zone landscape</p></div>
                	<div class="col-sm-6"><p align="left">Two zone landscape</p></div>

                </div>
                <hr>
                <div class="row">
	                 <div class="col-sm-5 card-body" style="border-style: solid; background-color:#fff;width:200px;height:250px;">
	                   <a href="<?php echo base_url(); ?>admin_dashboard/composition_temp/temp_3">
	                     <div class="row">
			                 	<div class="col-md-6">
					                 <p style="padding-top:50px;" align="center">Zone 1</p>
					             </div>
					             <div class="col-md-6">
					                 <p style="padding-top:50px;" align="center">Zone 2</p>
					             </div>
		                 </div>
		                 <div class="row">
			                 	<div class="col-md-12">
					                 <p style="padding-top:100px;" align="center">Zone 3</p>
					             </div>
		                 </div>
	                   </a>
	                 </div>
	                 <div class="col-md-1"></div>
	                 <div class="col-sm-5 card-body" style="border-style: solid; background-color:#fff;width:200px;height:250px;">
		                 <a href="<?php echo base_url(); ?>admin_dashboard/composition_temp/temp_4">
			                 <div class="row">
			                 	<div class="col-md-12">
					                 <p style="padding-top:50px;" align="center">Zone 1</p>
					             </div>
					             <div class="col-md-12">
					                 <p style="padding-top:100px;" align="center">Zone 2</p>
					             </div>
		                     </div>
	                    </a>
	                 </div>
                </div>
                 <div class="row">
                	<div class="col-sm-6"><p align="left">Three zone landscape</p></div>
                	<div class="col-sm-6"><p align="left">Two zone landscape</p></div>

                </div>
                <hr>
                <div class="row">
                	<div class="col-sm-4"></div>
	                 <div class="col-sm-2 card-body" style="border-style: solid; background-color:#fff;width:50px;height:250px;">
	                   <a href="<?php echo base_url(); ?>admin_dashboard/composition_temp/temp_5">
	                     <p style="padding-top:80px;" align="center">Zone 1</p>
	                   </a>
	                 </div>
	                 <div class="col-sm-6"></div>
                </div>   
                <p align="center" style="padding-right: 200px">Single zone Portrait</p>
				<!-- Template area end -->

					<!-- Content Starts -->
		             <div class="file-cont-wrap">
          	    <!-- Add Client Modal -->
				<div id="upload_modal" class="modal custom-modal fade" role="dialog">
					<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
						<div class="modal-content">
							<div class="modal-header">
								<h5 class="modal-title">Upload File</h5>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>
							<div class="modal-body">
								<form method="POST" id="upload" enctype="multipart/form-data">
									<div class="row">
										
										<div class="col-md-12">
											<div class="form-group">
												<input class="form-control" type="file" name="update_file" id="update_file">	

												<input type="hidden" name="file_from" id="file_from" value="Composition">
								
											</div>
										</div>
										

									</div>
									
									<div class="submit-section">
										<button class="btn btn-primary submit-btn">Submit</button>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
		

            </div>
			<!-- /Page Wrapper -->
			
        </div>
		<!-- /Main Wrapper -->
		

		
           <?php $this->load->view('common_css_js/footer_js');?>
    </body>

    <!-- jQuery -->
        <script src="<?php echo base_url(); ?>assets\js\jquery-3.2.1.min.js"></script>
		
		<!-- Bootstrap Core JS -->
        <script src="<?php echo base_url(); ?>assets\js\popper.min.js"></script>
        <script src="<?php echo base_url(); ?>assets\js\bootstrap.min.js"></script>
		
		<!-- Slimscroll JS -->
		<script src="<?php echo base_url(); ?>assets\js\jquery.slimscroll.min.js"></script>
		
		<!-- Custom JS -->
		<script src="<?php echo base_url(); ?>assets\js\app.js"></script><!-- jQuery -->
        <script src="<?php echo base_url(); ?>assets\js\jquery-3.2.1.min.js"></script>
		
		<!-- Bootstrap Core JS -->
        <script src="<?php echo base_url(); ?>assets\js\popper.min.js"></script>
        <script src="<?php echo base_url(); ?>assets\js\bootstrap.min.js"></script>
		
		<!-- Slimscroll JS -->
		<script src="<?php echo base_url(); ?>assets\js\jquery.slimscroll.min.js"></script>
		
		<!-- Custom JS -->
		<script src="<?php echo base_url(); ?>assets\js\app.js"></script>
    		<script type="text/javascript">
             

              $(function() {
                $('#colorselector').change(function(){
                    $('.colors').hide();
                    $('#' + $(this).val()).show();
                   });
              });

				$('#project_update_cost').validate({
  				
  				rules:
  				{ 
  					update_file: 'required',

  				    
                },
				 
				messages: 
				{ 
					update_file: 'The file is required',

				    
				},
				submitHandler: function(forms,event)
				{

				   event.preventDefault(); 
                      
				    $.ajax({
					            type: "POST",
					            
					            url: "<?php echo site_url().'admin_dashboard/project_update_cost'; ?>",
					            
					            //data: $("#add_client_form").serialize(), 

					            data: new FormData($('#project_update_cost')[0]),
        						cache: false,
        						contentType: false,
        						processData: false,
					            
					            success: function(data)
					            {

					                alert(data); console.log(data); return false;
					                if(data =='1')
					                {    

					                    swal("Success!", "Details Added Successfully","success").then( () => {
                                    
                                         location.reload(); });

					                }
					                else
					                {

					                    swal("Failed!", "Try Again Later.", "error");
					                    
					                    $( '#project_update_cost' ).each(function()
					                    {
					                                

					                    });

					                        	

					                }
					            
					            }
		                  }); 
				}
			});
			
			
    		function previewFile(input)
    		{
                var file = $("input[type=file]").get(0).files[0];
                if(file)
                {
                    var reader = new FileReader();
         
                    reader.onload = function()
                    {
                        $("#previewImg").attr("src", reader.result);
                    }
         
                    reader.readAsDataURL(file);
                }
            }
            
       
		</script>
</html>