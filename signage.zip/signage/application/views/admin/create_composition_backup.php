<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
        <title>Create Composition</title>
		
		<!-- Favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url(); ?>assets\img\faviconbg.png">
		
		<!-- Bootstrap CSS -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets\css\bootstrap.min.css">
		
		<!-- Fontawesome CSS -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets\css\font-awesome.min.css">
		
		<!-- Lineawesome CSS -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets\css\line-awesome.min.css">
		
		<!-- Main CSS -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets\css\style.css">
		
		<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!--[if lt IE 9]>
			<script src="<?php echo base_url(); ?>assets/js/html5shiv.min.js"></script>
			<script src="<?php echo base_url(); ?>assets/js/respond.min.js"></script>
		<![endif]-->
       <style>
        .card {
            word-wrap: break-word;
        }
    </style>
    </head>
    <body>
		<!-- Main Wrapper -->
        <div class="main-wrapper">
		
			<!-- Header -->
            <?php $this->load->view('common/set_header'); ?>
			<!-- Header -->
            <?php $this->load->view('common_css_js/side_header'); ?>
			
			<!-- Page Wrapper -->
            <div class="page-wrapper">
			
				<!-- Page Content -->
                <div class="content container-fluid">
					
					<!-- Page Header -->
					<div class="page-header">
						<div class="row filter-row">
							<div class="col-sm-6">
								<h3 class="page-title">Create Composition</h3>
								<ul class="breadcrumb">
									<li class="breadcrumb-item"><a href="<?php echo base_url(); ?>">Dashboard</a></li>
									<li class="breadcrumb-item active">Create Composition</li>
								</ul>
								
							</div>
							<div class="col-sm-6"> 
							<div class="dropdown">
							   
								<select class="btn btn-white btn-sm btn-rounded dropdown-toggle" data-toggle="dropdown" aria-expanded="false" id="colorselector">
									<div class="dropdown-menu">
									    <option class="dropdown-item">Select Template</option>
										<option class="dropdown-item" value="t1">Template A</option>
										<option class="dropdown-item" value="t2">Template B</option>
										<option class="dropdown-item" value="t3">Template C</option>
									</div>
								</select>
							</div>
															
							</div>
						</div>
					</div>
					<!-- /Page Header -->
					
					<!-- Content Starts -->
		             <div class="file-cont-wrap">
                        <!--Template 1-->
		             	<div  id="t1" class="row colors" style="display:none">
		             	    <div class="col-sm-6">
                             
		             		<div class="col-sm-6">
		             			<img src="<?php echo base_url(); ?>assets/img/assets_addition.svg" style="width:200%;">
		             			<div data-toggle="modal" data-target="#add_client"class="file-options" align="center" style="padding-top: 100px;">
		                        <form method="POST" action="<?php echo site_url().'admin_dashboard/ajax_upload'; ?>" enctype="multipart/form-data">
									<div class="row">
										
										<div class="col-md-12">
											<div class="form-group">
											    <label>Select Zone File <span class="text-danger">*</span></label>
												<input class="form-control" type="file" name="profile_picture" id="profile_picture" onchange="previewFile(this);" required/>
												
												<input type="hidden" name="file_from" id="file_from" value="Composition">
											</div>
										</div>
									</div>
									<div class="submit-section">
										<button class="btn btn-primary submit-btn"><i class="fa fa-plus"></i>Create Display</button><br><br>
									    <a href="#" class="btn add-btn" data-toggle="modal" data-target="#preview_template" >Preview Display</a>
									</div>
								</form>		
							     <!--  -->
					
								</div>
		             		 </div>
                            
                            </div>
                            
                            <div class="col-sm-4 card-body" style="border-style: solid; background-color:#fff;width:200px;height:250px;">
                                <p style="padding-top:50px;" align="center">Zone 1</p>
                            </div>
                            </div>
                            
                            <!--Template 1 end-->
                            
                            <!--Template 2 -->
                            <div  id="t2" class="row colors" style="display:none">
		             	    <div class="col-sm-6">
                             
		             		<div class="col-sm-6">
		             			<img src="<?php echo base_url(); ?>assets/img/assets_addition.svg" style="width:200%;">
		             			<div data-toggle="modal" data-target="#add_client"class="file-options" align="center" style="padding-top: 100px;">
		                        <form method="POST" action="<?php echo site_url().'admin_dashboard/ajax_upload_temp2'; ?>" enctype="multipart/form-data" runat="server">
									<div class="row">
										
										<div class="col-md-12">
											<div class="form-group">
											    <label>Select Zone1 File <span class="text-danger">*</span></label>
												<input class="form-control" type="file" name="profile_picture" id="profile_picture" onchange="document.getElementById('blah').src = window.URL.createObjectURL(this.files[0])" required="true">
												<label>Select Zone2 File <span class="text-danger">*</span></label>
												<input class="form-control" type="file" name="profile_picture2" id="profile_picture2" onchange="document.getElementById('abcd').src = window.URL.createObjectURL(this.files[0])"  required="true">
												<input type="hidden" name="file_from" id="file_from" value="Composition">
											</div>
										</div>
									</div>
									
									<div class="submit-section">
										<button class="btn btn-primary submit-btn"><i class="fa fa-upload fa-4x btn submit-btn"></i></button><br>
									    <a href="#" class="btn add-btn" data-toggle="modal" data-target="#preview_template_multiple">Preview Display</a>
									</div>
								</form>		
							     <!--  -->
					
								</div>
		             		 </div>
                            
                            </div>
                            
                            <div class="col-sm-4 card-body" style="border-style: solid; background-color:#fff;width:200px;height:250px;">
                                <p style="padding-top:60px;" align="center">Zone 1</p><hr>
                                <p style="padding:50px;" align="center">Zone 2</p>
                            </div>
                            </div>
                            <!--Template 2 end-->
                            
                            <!--Template 3 -->
                             <div  id="t3" class="row colors" style="display:none">
		             	    <div class="col-sm-6">
                             
		             		<div class="col-sm-6">
		             			<img src="<?php echo base_url(); ?>assets/img/assets_addition.svg" style="width:200%;">
		             			<div data-toggle="modal" data-target="#add_client"class="file-options" align="center" style="padding-top: 100px;">
		                        <form method="POST" action="<?php echo site_url().'admin_dashboard/ajax_upload_temp3'; ?>" enctype="multipart/form-data">
									<div class="row">
										
										<div class="col-md-12">
											<div class="form-group">
											    <label>Select Zone1 File <span class="text-danger">*</span></label>
												<input class="form-control" type="file" name="profile_picture" id="profile_picture" onchange="document.getElementById('tempa').src = window.URL.createObjectURL(this.files[0])" required="true">
												<label>Select Zone2 File <span class="text-danger">*</span></label>
												<input class="form-control" type="file" name="profile_pictur2" id="profile_picture2" onchange="document.getElementById('tempb').src = window.URL.createObjectURL(this.files[0])" required="true">
												<label>Select Zone3 File <span class="text-danger">*</span></label>
												<input class="form-control" type="file" name="profile_picture3" id="profile_picture3" onchange="document.getElementById('tempc').src = window.URL.createObjectURL(this.files[0])" required="true">
												<input type="hidden" name="file_from" id="file_from" value="Composition">
											</div>
										</div>
									</div>
									
									<div class="submit-section">
										<button class="btn btn-primary submit-btn"><i class="fa fa-upload fa-4x btn submit-btn"></i></button><br>
										<a href="#" class="btn add-btn" data-toggle="modal" data-target="#preview_template_multiple_final">Preview Display</a>
									</div>
								</form>		
							     <!--  -->
					
								</div>
		             		 </div>
                            
                            </div>
                            
                            <div class="col-sm-4 card-body" style="border-style: solid; background-color:#fff;width:200px;height:250px;">
                                <div class="row">
                                    <div class="col-sm-6"><p align="center">Zone 1</p></div>
                                    <div class="col-sm-6"><p align="center">Zone 2</p></div>
                                </div>
                                <div class="row" style="height:50px;">
                                    <p style="padding-top:150px;padding-left:150px;" align="center">Zone 3</p>
                                </div>
                            </div>
                            </div>
		             	    <!--Template 3 end-->
		             	    </div>
		             		<!--Details view start-->
		             
		             	   <!--Detail view end -->
		             	</div> 
		             	
		             </div>
					<!-- /Content End -->
					
                </div>
				<!-- /Page Content -->
			    
			    <!-- Template 1 Modal -->
				<div id="preview_template" class="modal custom-modal fade" role="dialog" style="display:none">
					<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
						<div class="modal-content">
						    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>&nbsp;
								<div class="row">
								    <div class="col-md-12">
								<div class="form-group" align="center">
									<img id="previewImg" src="" width="700" height="400">
									    <!--<source  type="video/mp4"></source>-->
									<!--</iframe>-->
								</div>
								</div>
								</div>
						</div>
					</div>
				</div>
				
				<!-- /Template 1 Modal -->
				
				
			    <!-- Template 2 Modal -->
				<div id="preview_template_multiple" class="modal custom-modal fade" role="dialog" style="display:none">
					<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
						<div class="modal-content">
						    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>&nbsp;
								<div class="row">
								<div class="col-md-6">
								<div class="form-group">
									<img id="blah" src="" width="350" height="400">
								</div>
								</div>
								<div class="col-md-6">
								    <img id="abcd" src="" width="350" height="400">
								</div>
								</div>
						</div>
					</div>
				</div>
				
				<!-- /Template 2 Modal -->
				
				<!-- Template 3 Modal -->
				<div id="preview_template_multiple_final" class="modal custom-modal fade" role="dialog" style="display:none">
					<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
						<div class="modal-content">
						    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>&nbsp;
								<div class="row">
								<div class="col-md-6">
								<div class="form-group">
									<img id="tempa" src="" width="350" height="400">
								</div>
								</div>
								<div class="col-md-6">
								    <img id="tempb" src="" width="350" height="400">
								</div>
								</div>
								<div class="row">
								    <div class="col-md-12">
								        <img id="tempc" src="" width="700" height="30">
								    </div>
								</div>
						</div>
					</div>
				</div>
				
				<!-- /Template 3 Modal -->
			    
			    <!-- Add Client Modal -->
				<div id="upload_modal" class="modal custom-modal fade" role="dialog">
					<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
						<div class="modal-content">
							<div class="modal-header">
								<h5 class="modal-title">Upload File</h5>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>
							<div class="modal-body">
								<form method="POST" id="upload" enctype="multipart/form-data">
									<div class="row">
										
										<div class="col-md-12">
											<div class="form-group">
												<input class="form-control" type="file" name="update_file" id="update_file">	

												<input type="hidden" name="file_from" id="file_from" value="Composition">
								
											</div>
										</div>
										

									</div>
									
									<div class="submit-section">
										<button class="btn btn-primary submit-btn">Submit</button>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
		

            </div>
			<!-- /Page Wrapper -->
			
        </div>
		<!-- /Main Wrapper -->
		

		
           <?php $this->load->view('common_css_js/footer_js');?>
    </body>

    <!-- jQuery -->
        <script src="<?php echo base_url(); ?>assets\js\jquery-3.2.1.min.js"></script>
		
		<!-- Bootstrap Core JS -->
        <script src="<?php echo base_url(); ?>assets\js\popper.min.js"></script>
        <script src="<?php echo base_url(); ?>assets\js\bootstrap.min.js"></script>
		
		<!-- Slimscroll JS -->
		<script src="<?php echo base_url(); ?>assets\js\jquery.slimscroll.min.js"></script>
		
		<!-- Custom JS -->
		<script src="<?php echo base_url(); ?>assets\js\app.js"></script><!-- jQuery -->
        <script src="<?php echo base_url(); ?>assets\js\jquery-3.2.1.min.js"></script>
		
		<!-- Bootstrap Core JS -->
        <script src="<?php echo base_url(); ?>assets\js\popper.min.js"></script>
        <script src="<?php echo base_url(); ?>assets\js\bootstrap.min.js"></script>
		
		<!-- Slimscroll JS -->
		<script src="<?php echo base_url(); ?>assets\js\jquery.slimscroll.min.js"></script>
		
		<!-- Custom JS -->
		<script src="<?php echo base_url(); ?>assets\js\app.js"></script>
    		<script type="text/javascript">
              
              $(function() {
                $('#colorselector').change(function(){
                    $('.colors').hide();
                    $('#' + $(this).val()).show();
                   });
              });

				$('#project_update_cost').validate({
  				
  				rules:
  				{ 
  					update_file: 'required',

  				    
                },
				 
				messages: 
				{ 
					update_file: 'The file is required',

				    
				},
				submitHandler: function(forms,event)
				{

				   event.preventDefault(); 
                      
				    $.ajax({
					            type: "POST",
					            
					            url: "<?php echo site_url().'admin_dashboard/project_update_cost'; ?>",
					            
					            //data: $("#add_client_form").serialize(), 

					            data: new FormData($('#project_update_cost')[0]),
        						cache: false,
        						contentType: false,
        						processData: false,
					            
					            success: function(data)
					            {

					                alert(data); console.log(data); return false;
					                if(data =='1')
					                {    

					                    swal("Success!", "Details Added Successfully","success").then( () => {
                                    
                                         location.reload(); });

					                }
					                else
					                {

					                    swal("Failed!", "Try Again Later.", "error");
					                    
					                    $( '#project_update_cost' ).each(function()
					                    {
					                                

					                    });

					                        	

					                }
					            
					            }
		                  }); 
				}
			});
			
			
    		function previewFile(input)
    		{
                var file = $("input[type=file]").get(0).files[0];
                if(file)
                {
                    var reader = new FileReader();
         
                    reader.onload = function()
                    {
                        $("#previewImg").attr("src", reader.result);
                    }
         
                    reader.readAsDataURL(file);
                }
            }
            
            var loadFile = function(event) {
                var output = document.getElementById('output');
                output.src = URL.createObjectURL(event.target.files[0]);
                output.onload = function() {
                  URL.revokeObjectURL(output.src) // free memory
                }
              };
            
            // function clickCounter() 
            // {
            // //   var Values = $( "#profile_picture" ).val();
            //   if(typeof(Storage) !== "undefined") 
            //   {
            //     if (localStorage.clickcount) 
            //     {
            //       localStorage.clickcount = Number(localStorage.clickcount)+1;
            //     } else {
            //       localStorage.clickcount = 1;
            //     }
            //     document.getElementById("result").innerHTML = "You have viewed " + localStorage.clickcount + " time(s).";
            //     // localStorage.clear();
            //   } else {
            //     document.getElementById("result").innerHTML = "Sorry, your browser does not support web storage...";
            //   }
            // }

		</script>
</html>