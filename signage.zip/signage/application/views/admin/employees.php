<?php $employees_list = $employees_list;

 ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
        <title>User </title>

        <?php $this->load->view('common_css_js/css'); ?>
		
    </head>
    <body>
		<!-- Main Wrapper -->
        <div class="main-wrapper">
		
			<!-- Header -->
        <?php $this->load->view('common/set_header'); ?>
			<!-- Header -->
            <?php $this->load->view('common_css_js/side_header'); ?>
			<!-- /Sidebar -->
			
			<!-- Page Wrapper -->
            <div class="page-wrapper">
			
				<!-- Page Content -->
                <div class="content container-fluid">
				
					<!-- Page Header -->
					<?php $this->load->view('common_css_js/employee_header'); ?>
					<!-- /Page Header -->
					
					<!-- Search Filter -->
					<!--<div class="row filter-row">-->
					<!--	<div class="col-sm-6 col-md-3">  -->
					<!--		<div class="form-group form-focus">-->
					<!--			<input type="text" class="form-control floating">-->
					<!--			<label class="focus-label">User ID</label>-->
					<!--		</div>-->
					<!--	</div>-->
					<!--	<div class="col-sm-6 col-md-3">  -->
					<!--		<div class="form-group form-focus">-->
					<!--			<input type="text" class="form-control floating">-->
					<!--			<label class="focus-label">user Name</label>-->
					<!--		</div>-->
					<!--	</div>-->
					<!--	<div class="col-sm-6 col-md-3"> -->
					<!--		<div class="form-group form-focus select-focus">-->
					<!--			<select class="select floating"> -->
					<!--				<option>Select Designation</option>-->
					<!--				<option>Web Developer</option>-->
					<!--				<option>Web Designer</option>-->
					<!--				<option>Android Developer</option>-->
					<!--				<option>Ios Developer</option>-->
					<!--			</select>-->
					<!--			<label class="focus-label">Designation</label>-->
					<!--		</div>-->
					<!--	</div>-->
					<!--	<div class="col-sm-6 col-md-3">  -->
					<!--		<a href="#" class="btn btn-success btn-block"> Search </a>  -->
					<!--	</div>-->
     <!--               </div>-->
					<!-- Search Filter -->
		           
						<div class="row">
						<div class="col-md-12">
							<div class="table-responsive">
							    <div align="center">  
            					 <form action="<?php echo site_url().'admin_dashboard/exportCSV'; ?>" method="post">		    
                                 <button align="right" type="submit" class="btn btn-success">Create Excel File</button>  
                                 </form>
                                
                </div> 
								<table class="table table-striped table-nowrap custom-table mb-0 datatable">
									<thead>
										<tr>
											<th>#</th>
											<th>User ID</th>
											<th>Name</th>
											<th>Status</th>
											<th>Email</th>
											<th>Mobile</th>
											<th class="text-right">Actions</th>
										</tr>
									</thead>
									<tbody>
									<?php 
									if(!empty($employees_list))
						            {
						                $i = 1;
            							foreach ($employees_list as $employees_list_value) 
            							{ ?>
									<tr>
									<td><?php echo $i++; ?></td>
									<td><?php echo $employees_list_value->employee_id; ?></td>
									<td><?php echo $employees_list_value->user_login_name; ?></td>
									<td><a class="btn btn-white btn-sm"  data-toggle="modal" data-target="#status_model" onclick="lead_function(<?php echo $employees_list_value->user_id; ?>)"  aria-expanded="false">
                                                            <?php if($employees_list_value->status == '1') { ?>
                                                                <i class="fa fa-dot-circle-o text-success"></i> Approved
                                                                <?php } else { ?>
                                                                <i class="fa fa-dot-circle-o text-danger"></i> Pending
                                                                <?php } ?>
                                                            </a></td> 
									<td><?php echo $employees_list_value->user_login_email; ?></td>
                                    <td><?php echo $employees_list_value->phone_no; ?></td>
									<td class="text-right">
									
								    <div class="dropdown dropdown-action">
									<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>
									<div class="dropdown-menu dropdown-menu-right">
										<a 
											class="dropdown-item edit_employee_model" 

											href="#" data-toggle="modal" 

											data-user_id="<?php echo $employees_list_value->user_id; ?>" 

											data-target="#edit_employee" 
											
											data-employee_id="<?php echo $employees_list_value->employee_id; ?>"

											data-user_name="<?php echo $employees_list_value->user_login_name; ?>"

											data-email="<?php echo $employees_list_value->user_login_email; ?>"

											data-password="<?php echo $employees_list_value->user_password; ?>"

											data-confirm_password="<?php echo $employees_list_value->user_password; ?>"

											data-phone_no="<?php echo $employees_list_value->phone_no; ?>"

											data-designation="<?php echo $employees_list_value->status; ?>"

										>

										<i class="fa fa-pencil m-r-5"></i> Edit</a>
										<a class="dropdown-item delete_employee" href="#" data-toggle="modal" data-target="#delete_employee"

										data-user_id="<?php echo $employees_list_value->user_id; ?>" 
										><i class="fa fa-trash-o m-r-5"></i> Delete</a>
									</div>
								</div>
											</td>
									</tr>
									<?php } 
									} ?>
									</tbody>
								</table>
							</div>
						</div>
					</div>

						<!-- <div class="col-md-4 col-sm-6 col-12 col-lg-4 col-xl-3">
						<!--	<div class="profile-widget">-->
						<!--		<div class="profile-img">-->
						<!--			<a href="<?php echo site_url(); ?>admin_dashboard/profile" class="avatar"><img src="<?php echo base_url(); ?>assets\img\profiles\avatar-02.jpg" alt=""></a>-->
						<!--		</div>-->
						<!--		<div class="dropdown profile-action">-->
						<!--			<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>-->
						<!--			<div class="dropdown-menu dropdown-menu-right">-->
						<!--				<a class="dropdown-item" href="#" data-toggle="modal" data-target="#edit_employee"><i class="fa fa-pencil m-r-5"></i> Edit</a>-->
						<!--				<a class="dropdown-item" href="#" data-toggle="modal" data-target="#delete_employee"><i class="fa fa-trash-o m-r-5"></i> Delete</a>-->
						<!--			</div>-->
						<!--		</div>-->
						<!--		<h4 class="user-name m-t-10 mb-0 text-ellipsis"><a href="<?php echo site_url(); ?>admin_dashboard/profile">John Doe</a></h4>-->
						<!--		<div class="small text-muted">Web Designer</div>-->
						<!--	</div>-->
						<!--</div>-->



						<!--<div class="col-md-4 col-sm-6 col-12 col-lg-4 col-xl-3">-->
						<!--	<div class="profile-widget">-->
						<!--		<div class="profile-img">-->
						<!--			<a href="<?php echo site_url(); ?>admin_dashboard/profile" class="avatar"><img src="<?php echo base_url(); ?>assets\img\profiles\avatar-09.jpg" alt=""></a>-->
						<!--		</div>-->
						<!--		<div class="dropdown profile-action">-->
						<!--			<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>-->
						<!--			<div class="dropdown-menu dropdown-menu-right">-->
						<!--				<a class="dropdown-item" href="#" data-toggle="modal" data-target="#edit_employee"><i class="fa fa-pencil m-r-5"></i> Edit</a>-->
						<!--				<a class="dropdown-item" href="#" data-toggle="modal" data-target="#delete_employee"><i class="fa fa-trash-o m-r-5"></i> Delete</a>-->
						<!--			</div>-->
						<!--		</div>-->
						<!--		<h4 class="user-name m-t-10 mb-0 text-ellipsis"><a href="<?php echo site_url(); ?>admin_dashboard/profile">Richard Miles</a></h4>-->
						<!--		<div class="small text-muted">Web Developer</div>-->
						<!--	</div>-->
						<!--</div>-->
						<!--<div class="col-md-4 col-sm-6 col-12 col-lg-4 col-xl-3">-->
						<!--	<div class="profile-widget">-->
						<!--		<div class="profile-img">-->
						<!--			<a href="<?php echo site_url(); ?>admin_dashboard/profile" class="avatar"><img src="<?php echo base_url(); ?>assets\img\profiles\avatar-10.jpg" alt=""></a>-->
						<!--		</div>-->
						<!--		<div class="dropdown profile-action">-->
						<!--			<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>-->
						<!--			<div class="dropdown-menu dropdown-menu-right">-->
						<!--				<a class="dropdown-item" href="#" data-toggle="modal" data-target="#edit_employee"><i class="fa fa-pencil m-r-5"></i> Edit</a>-->
						<!--				<a class="dropdown-item" href="#" data-toggle="modal" data-target="#delete_employee"><i class="fa fa-trash-o m-r-5"></i> Delete</a>-->
						<!--			</div>-->
						<!--		</div>-->
						<!--		<h4 class="user-name m-t-10 mb-0 text-ellipsis"><a href="<?php echo site_url(); ?>admin_dashboard/profile">John Smith</a></h4>-->
						<!--		<div class="small text-muted">Android Developer</div>-->
						<!--	</div>-->
						<!--</div>-->
						<!--<div class="col-md-4 col-sm-6 col-12 col-lg-4 col-xl-3">-->
						<!--	<div class="profile-widget">-->
						<!--		<div class="profile-img">-->
						<!--			<a href="<?php echo site_url(); ?>admin_dashboard/profile" class="avatar"><img src="<?php echo base_url(); ?>assets\img\profiles\avatar-05.jpg" alt=""></a>-->
						<!--		</div>-->
						<!--		<div class="dropdown profile-action">-->
						<!--			<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>-->
						<!--			<div class="dropdown-menu dropdown-menu-right">-->
						<!--				<a class="dropdown-item" href="#" data-toggle="modal" data-target="#edit_employee"><i class="fa fa-pencil m-r-5"></i> Edit</a>-->
						<!--				<a class="dropdown-item" href="#" data-toggle="modal" data-target="#delete_employee"><i class="fa fa-trash-o m-r-5"></i> Delete</a>-->
						<!--			</div>-->
						<!--		</div>-->
						<!--		<h4 class="user-name m-t-10 mb-0 text-ellipsis"><a href="<?php echo site_url(); ?>admin_dashboard/profile">Mike Litorus</a></h4>-->
						<!--		<div class="small text-muted">IOS Developer</div>-->
						<!--	</div>-->
						<!--</div>-->
						<!--<div class="col-md-4 col-sm-6 col-12 col-lg-4 col-xl-3">-->

						<!--	<div class="profile-widget">-->
						<!--		<div class="profile-img">-->
						<!--			<a href="<?php echo site_url(); ?>admin_dashboard/profile" class="avatar"><img src="<?php echo base_url(); ?>assets\img\profiles\avatar-11.jpg" alt=""></a>-->
						<!--		</div>-->
						<!--		<div class="dropdown profile-action">-->
						<!--			<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>-->
						<!--			<div class="dropdown-menu dropdown-menu-right">-->
						<!--				<a class="dropdown-item" href="#" data-toggle="modal" data-target="#edit_employee"><i class="fa fa-pencil m-r-5"></i> Edit</a>-->
						<!--				<a class="dropdown-item" href="#" data-toggle="modal" data-target="#delete_employee"><i class="fa fa-trash-o m-r-5"></i> Delete</a>-->
						<!--			</div>-->
						<!--		</div>-->
						<!--		<h4 class="user-name m-t-10 mb-0 text-ellipsis"><a href="<?php echo site_url(); ?>admin_dashboard/profile">Wilmer Deluna</a></h4>-->
						<!--		<div class="small text-muted">Team Leader</div>-->
						<!--	</div>-->
						<!--</div>-->
						<!--<div class="col-md-4 col-sm-6 col-12 col-lg-4 col-xl-3">-->
						<!--	<div class="profile-widget">-->
						<!--		<div class="profile-img">-->
						<!--			<a href="<?php echo site_url(); ?>admin_dashboard/profile" class="avatar"><img src="<?php echo base_url(); ?>assets\img\profiles\avatar-12.jpg" alt=""></a>-->
						<!--		</div>-->
						<!--		<div class="dropdown profile-action">-->
						<!--			<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>-->
						<!--			<div class="dropdown-menu dropdown-menu-right">-->
						<!--				<a class="dropdown-item" href="#" data-toggle="modal" data-target="#edit_employee"><i class="fa fa-pencil m-r-5"></i> Edit</a>-->
						<!--				<a class="dropdown-item" href="#" data-toggle="modal" data-target="#delete_employee"><i class="fa fa-trash-o m-r-5"></i> Delete</a>-->
						<!--			</div>-->
						<!--		</div>-->
						<!--		<h4 class="user-name m-t-10 mb-0 text-ellipsis"><a href="<?php echo site_url(); ?>admin_dashboard/profile">Jeffrey Warden</a></h4>-->
						<!--		<div class="small text-muted">Web Developer</div>-->
						<!--	</div>-->
						<!--</div>-->
						<!--<div class="col-md-4 col-sm-6 col-12 col-lg-4 col-xl-3">-->
						<!--	<div class="profile-widget">-->
						<!--		<div class="profile-img">-->
						<!--			<a href="<?php echo site_url(); ?>admin_dashboard/profile" class="avatar"><img src="<?php echo base_url(); ?>assets\img\profiles\avatar-13.jpg" alt=""></a>-->
						<!--		</div>-->
						<!--		<div class="dropdown profile-action">-->
						<!--			<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>-->
						<!--			<div class="dropdown-menu dropdown-menu-right">-->
						<!--				<a class="dropdown-item" href="#" data-toggle="modal" data-target="#edit_employee"><i class="fa fa-pencil m-r-5"></i> Edit</a>-->
						<!--				<a class="dropdown-item" href="#" data-toggle="modal" data-target="#delete_employee"><i class="fa fa-trash-o m-r-5"></i> Delete</a>-->
						<!--			</div>-->
						<!--		</div>-->
						<!--		<h4 class="user-name m-t-10 mb-0 text-ellipsis"><a href="<?php echo site_url(); ?>admin_dashboard/profile">Bernardo Galaviz</a></h4>-->
						<!--		<div class="small text-muted">Web Developer</div>-->
						<!--	</div>-->
						<!--</div>-->
						<!--<div class="col-md-4 col-sm-6 col-12 col-lg-4 col-xl-3">-->
						<!--	<div class="profile-widget">-->
						<!--		<div class="profile-img">-->
						<!--			<a href="<?php echo site_url(); ?>admin_dashboard/profile" class="avatar"><img src="<?php echo base_url(); ?>assets\img\profiles\avatar-01.jpg" alt=""></a>-->
						<!--		</div>-->
						<!--		<div class="dropdown profile-action">-->
						<!--			<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>-->
						<!--			<div class="dropdown-menu dropdown-menu-right">-->
						<!--				<a class="dropdown-item" href="#" data-toggle="modal" data-target="#edit_employee"><i class="fa fa-pencil m-r-5"></i> Edit</a>-->
						<!--				<a class="dropdown-item" href="#" data-toggle="modal" data-target="#delete_employee"><i class="fa fa-trash-o m-r-5"></i> Delete</a>-->
						<!--			</div>-->
						<!--		</div>-->
						<!--		<h4 class="user-name m-t-10 mb-0 text-ellipsis"><a href="<?php echo site_url(); ?>admin_dashboard/profile">Lesley Grauer</a></h4>-->
						<!--		<div class="small text-muted">Team Leader</div>-->
						<!--	</div>-->
						<!--</div>-->
						<!--<div class="col-md-4 col-sm-6 col-12 col-lg-4 col-xl-3">-->
						<!--	<div class="profile-widget">-->
						<!--		<div class="profile-img">-->
						<!--			<a href="<?php echo site_url(); ?>admin_dashboard/profile" class="avatar"><img src="<?php echo base_url(); ?>assets\img\profiles\avatar-16.jpg" alt=""></a>-->
						<!--		</div>-->
						<!--		<div class="dropdown profile-action">-->
						<!--			<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>-->
						<!--			<div class="dropdown-menu dropdown-menu-right">-->
						<!--				<a class="dropdown-item" href="#" data-toggle="modal" data-target="#edit_employee"><i class="fa fa-pencil m-r-5"></i> Edit</a>-->
						<!--				<a class="dropdown-item" href="#" data-toggle="modal" data-target="#delete_employee"><i class="fa fa-trash-o m-r-5"></i> Delete</a>-->
						<!--			</div>-->
						<!--		</div>-->
						<!--		<h4 class="user-name m-t-10 mb-0 text-ellipsis"><a href="<?php echo site_url(); ?>admin_dashboard/profile">Jeffery Lalor</a></h4>-->
						<!--		<div class="small text-muted">Team Leader</div>-->
						<!--	</div>-->
						<!--</div>-->
						<!--<div class="col-md-4 col-sm-6 col-12 col-lg-4 col-xl-3">-->
						<!--	<div class="profile-widget">-->
						<!--		<div class="profile-img">-->
						<!--			<a href="<?php echo site_url(); ?>admin_dashboard/profile" class="avatar"><img src="<?php echo base_url(); ?>assets\img\profiles\avatar-04.jpg" alt=""></a>-->
						<!--		</div>-->
						<!--		<div class="dropdown profile-action">-->
						<!--			<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>-->
						<!--			<div class="dropdown-menu dropdown-menu-right">-->
						<!--				<a class="dropdown-item" href="#" data-toggle="modal" data-target="#edit_employee"><i class="fa fa-pencil m-r-5"></i> Edit</a>-->
						<!--				<a class="dropdown-item" href="#" data-toggle="modal" data-target="#delete_employee"><i class="fa fa-trash-o m-r-5"></i> Delete</a>-->
						<!--			</div>-->
						<!--		</div>-->
						<!--		<h4 class="user-name m-t-10 mb-0 text-ellipsis"><a href="<?php echo site_url(); ?>admin_dashboard/profile">Loren Gatlin</a></h4>-->
						<!--		<div class="small text-muted">Android Developer</div>-->
						<!--	</div>-->
						<!--</div>-->
						<!--<div class="col-md-4 col-sm-6 col-12 col-lg-4 col-xl-3">-->
						<!--	<div class="profile-widget">-->
						<!--		<div class="profile-img">-->
						<!--			<a href="<?php echo site_url(); ?>admin_dashboard/profile" class="avatar"><img src="<?php echo base_url(); ?>assets\img\profiles\avatar-03.jpg" alt=""></a>-->
						<!--		</div>-->
						<!--		<div class="dropdown profile-action">-->
						<!--			<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>-->
						<!--			<div class="dropdown-menu dropdown-menu-right">-->
						<!--				<a class="dropdown-item" href="#" data-toggle="modal" data-target="#edit_employee"><i class="fa fa-pencil m-r-5"></i> Edit</a>-->
						<!--				<a class="dropdown-item" href="#" data-toggle="modal" data-target="#delete_employee"><i class="fa fa-trash-o m-r-5"></i> Delete</a>-->
						<!--			</div>-->
						<!--		</div>-->
						<!--		<h4 class="user-name m-t-10 mb-0 text-ellipsis"><a href="<?php echo site_url(); ?>admin_dashboard/profile">Tarah Shropshire</a></h4>-->
						<!--		<div class="small text-muted">Android Developer</div>-->
						<!--	</div>-->
						<!--</div>-->
						<!--<div class="col-md-4 col-sm-6 col-12 col-lg-4 col-xl-3">-->
						<!--	<div class="profile-widget">-->
						<!--		<div class="profile-img">-->
						<!--			<a href="<?php echo site_url(); ?>admin_dashboard/profile" class="avatar"><img src="<?php echo base_url(); ?>assets\img\profiles\avatar-08.jpg" alt=""></a>-->
						<!--		</div>-->
						<!--		<div class="dropdown profile-action">-->
						<!--			<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>-->
						<!--			<div class="dropdown-menu dropdown-menu-right">-->
						<!--				<a class="dropdown-item" href="#" data-toggle="modal" data-target="#edit_employee"><i class="fa fa-pencil m-r-5"></i> Edit</a>-->
						<!--				<a class="dropdown-item" href="#" data-toggle="modal" data-target="#delete_employee"><i class="fa fa-trash-o m-r-5"></i> Delete</a>-->
						<!--			</div>-->
						<!--		</div>-->
						<!--		<h4 class="user-name m-t-10 mb-0 text-ellipsis"><a href="<?php echo site_url(); ?>admin_dashboard/profile">Catherine Manseau</a></h4>-->
						<!--		<div class="small text-muted">Android Developer</div>-->
						<!--	</div>-->
						<!--</div> -->
					</div>
                </div>
				<!-- /Page Content -->
				
				<!-- Add Employee Modal -->
				<div id="add_employee" class="modal custom-modal fade" role="dialog">
					<div class="modal-dialog modal-dialog-centered modal-lg">
						<div class="modal-content">
							<div class="modal-header">
								<h5 class="modal-title">Add User</h5>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>
							<div class="modal-body">
								<form id="employee_add" method="post">
									<div class="row">
										
										<div class="col-sm-6">
											<div class="form-group">
												<label class="col-form-label">Username <span class="text-danger">*</span></label>
												<input class="form-control" type="text" id="user_name" name="user_name" required>
											</div>
										</div>
										<div class="col-sm-6">
											<div class="form-group">
												<label class="col-form-label">Email <span class="text-danger">*</span></label>
												<input class="form-control" type="email" id="email" name="email" required>
											</div>
										</div>
										<div class="col-sm-6">
											<div class="form-group">
												<label class="col-form-label">Password</label>
												<input class="form-control" type="password" id="password" name="password" required>
											</div>
										</div>
										<div class="col-sm-6">
											<div class="form-group">
												<label class="col-form-label">Confirm Password</label>
												<input class="form-control" type="password">
											</div>
										</div>
									
										<div class="col-sm-6">
											<div class="form-group">
												<label class="col-form-label">Phone <span class="text-danger">*</span></label>
												<input class="form-control" type="text" id="phone_no" name="phone_no" required>
											</div>
										</div>
										
									<!-- <div class="table-responsive m-t-15">-->
									<!--	<table class="table table-striped custom-table">-->
									<!--		<thead>-->
									<!--			<tr>-->
									<!--				<th>Module Permission</th>-->
									<!--				<th class="text-center">Read</th>-->
									<!--				<th class="text-center">Write</th>-->
									<!--				<th class="text-center">Create</th>-->
									<!--				<th class="text-center">Delete</th>-->
									<!--				<th class="text-center">Import</th>-->
									<!--				<th class="text-center">Export</th>-->
									<!--			</tr>-->
									<!--		</thead>-->
									<!--		<tbody>-->
									<!--			<tr>-->
									<!--				<td>Holidays</td>-->
									<!--				<td class="text-center">-->
									<!--					<input checked="" type="checkbox">-->
									<!--				</td>-->
									<!--				<td class="text-center">-->
									<!--					<input type="checkbox">-->
									<!--				</td>-->
									<!--				<td class="text-center">-->
									<!--					<input type="checkbox">-->
									<!--				</td>-->
									<!--				<td class="text-center">-->
									<!--					<input type="checkbox">-->
									<!--				</td>-->
									<!--				<td class="text-center">-->
									<!--					<input type="checkbox">-->
									<!--				</td>-->
									<!--				<td class="text-center">-->
									<!--					<input type="checkbox">-->
									<!--				</td>-->
									<!--			</tr>-->
									<!--			<tr>-->
									<!--				<td>Leaves</td>-->
									<!--				<td class="text-center">-->
									<!--					<input checked="" type="checkbox">-->
									<!--				</td>-->
									<!--				<td class="text-center">-->
									<!--					<input checked="" type="checkbox">-->
									<!--				</td>-->
									<!--				<td class="text-center">-->
									<!--					<input checked="" type="checkbox">-->
									<!--				</td>-->
									<!--				<td class="text-center">-->
									<!--					<input type="checkbox">-->
									<!--				</td>-->
									<!--				<td class="text-center">-->
									<!--					<input type="checkbox">-->
									<!--				</td>-->
									<!--				<td class="text-center">-->
									<!--					<input type="checkbox">-->
									<!--				</td>-->
									<!--			</tr>-->
									<!--			<tr>-->
									<!--				<td>Clients</td>-->
									<!--				<td class="text-center">-->
									<!--					<input checked="" type="checkbox">-->
									<!--				</td>-->
									<!--				<td class="text-center">-->
									<!--					<input checked="" type="checkbox">-->
									<!--				</td>-->
									<!--				<td class="text-center">-->
									<!--					<input checked="" type="checkbox">-->
									<!--				</td>-->
									<!--				<td class="text-center">-->
									<!--					<input type="checkbox">-->
									<!--				</td>-->
									<!--				<td class="text-center">-->
									<!--					<input type="checkbox">-->
									<!--				</td>-->
									<!--				<td class="text-center">-->
									<!--					<input type="checkbox">-->
									<!--				</td>-->
									<!--			</tr>-->
									<!--			<tr>-->
									<!--				<td>Projects</td>-->
									<!--				<td class="text-center">-->
									<!--					<input checked="" type="checkbox">-->
									<!--				</td>-->
									<!--				<td class="text-center">-->
									<!--					<input type="checkbox">-->
									<!--				</td>-->
									<!--				<td class="text-center">-->
									<!--					<input type="checkbox">-->
									<!--				</td>-->
									<!--				<td class="text-center">-->
									<!--					<input type="checkbox">-->
									<!--				</td>-->
									<!--				<td class="text-center">-->
									<!--					<input type="checkbox">-->
									<!--				</td>-->
									<!--				<td class="text-center">-->
									<!--					<input type="checkbox">-->
									<!--				</td>-->
									<!--			</tr>-->
									<!--			<tr>-->
									<!--				<td>Tasks</td>-->
									<!--				<td class="text-center">-->
									<!--					<input checked="" type="checkbox">-->
									<!--				</td>-->
									<!--				<td class="text-center">-->
									<!--					<input checked="" type="checkbox">-->
									<!--				</td>-->
									<!--				<td class="text-center">-->
									<!--					<input checked="" type="checkbox">-->
									<!--				</td>-->
									<!--				<td class="text-center">-->
									<!--					<input checked="" type="checkbox">-->
									<!--				</td>-->
									<!--				<td class="text-center">-->
									<!--					<input type="checkbox">-->
									<!--				</td>-->
									<!--				<td class="text-center">-->
									<!--					<input type="checkbox">-->
									<!--				</td>-->
									<!--			</tr>-->
									<!--			<tr>-->
									<!--				<td>Chats</td>-->
									<!--				<td class="text-center">-->
									<!--					<input checked="" type="checkbox">-->
									<!--				</td>-->
									<!--				<td class="text-center">-->
									<!--					<input checked="" type="checkbox">-->
									<!--				</td>-->
									<!--				<td class="text-center">-->
									<!--					<input checked="" type="checkbox">-->
									<!--				</td>-->
									<!--				<td class="text-center">-->
									<!--					<input checked="" type="checkbox">-->
									<!--				</td>-->
									<!--				<td class="text-center">-->
									<!--					<input type="checkbox">-->
									<!--				</td>-->
									<!--				<td class="text-center">-->
									<!--					<input type="checkbox">-->
									<!--				</td>-->
									<!--			</tr>-->
									<!--			<tr>-->
									<!--				<td>Assets</td>-->
									<!--				<td class="text-center">-->
									<!--					<input checked="" type="checkbox">-->
									<!--				</td>-->
									<!--				<td class="text-center">-->
									<!--					<input checked="" type="checkbox">-->
									<!--				</td>-->
									<!--				<td class="text-center">-->
									<!--					<input checked="" type="checkbox">-->
									<!--				</td>-->
									<!--				<td class="text-center">-->
									<!--					<input checked="" type="checkbox">-->
									<!--				</td>-->
									<!--				<td class="text-center">-->
									<!--					<input type="checkbox">-->
									<!--				</td>-->
									<!--				<td class="text-center">-->
									<!--					<input type="checkbox">-->
									<!--				</td>-->
									<!--			</tr>-->
									<!--			<tr>-->
									<!--				<td>Timing Sheets</td>-->
									<!--				<td class="text-center">-->
									<!--					<input checked="" type="checkbox">-->
									<!--				</td>-->
									<!--				<td class="text-center">-->
									<!--					<input checked="" type="checkbox">-->
									<!--				</td>-->
									<!--				<td class="text-center">-->
									<!--					<input checked="" type="checkbox">-->
									<!--				</td>-->
									<!--				<td class="text-center">-->
									<!--					<input checked="" type="checkbox">-->
									<!--				</td>-->
									<!--				<td class="text-center">-->
									<!--					<input type="checkbox">-->
									<!--				</td>-->
									<!--				<td class="text-center">-->
									<!--					<input type="checkbox">-->
									<!--				</td>-->
									<!--			</tr>-->
									<!--		</tbody>-->
									<!--	</table>-->
									<!--</div>-->
									</div>
									<div class="submit-section">
										<button class="btn btn-primary submit-btn">Submit</button>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
				<!-- /Add Employee Modal -->
				
				<!-- Edit Employee Modal -->
				<div id="edit_employee" class="modal custom-modal fade" role="dialog">
					<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
						<div class="modal-content">
							<div class="modal-header">
								<h5 class="modal-title">Edit Employee</h5>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>
							<div class="modal-body">
								<form id="employee_edit" method="post">
									<div class="row">
									    <input type="hidden" name="edit_user_id" id="edit_user_id">
										<div class="col-sm-6">
											<div class="form-group">
												<label class="col-form-label">Username <span class="text-danger">*</span></label>
												<input class="form-control" value="" type="text" id="edit_user_name" name="edit_user_name">
											</div>
										</div>
										<div class="col-sm-6">
											<div class="form-group">
												<label class="col-form-label">User ID <span class="text-danger">*</span></label>
												<input class="form-control" value="" type="text" id="edit_employee_id" name="edit_employee_id">
											</div>
										</div>
										<div class="col-sm-6">
											<div class="form-group">
												<label class="col-form-label">Email <span class="text-danger">*</span></label>
												<input class="form-control" value="" type="email" id="edit_email" name="edit_email">
											</div>
										</div>
										<div class="col-sm-6">
											<div class="form-group">
												<label class="col-form-label">Password</label>
												<input class="form-control" value="" type="password" id="edit_password" name="edit_password">
											</div>
										</div>
										<div class="col-sm-6">
											<div class="form-group">
												<label class="col-form-label">Confirm Password</label>
												<input class="form-control" value="" type="password" id="confirm_password" name="confirm_password">
											</div>
										</div>
										<div class="col-sm-6">
											<div class="form-group">
												<label class="col-form-label">Phone </label>
												<input class="form-control" value="" type="text" id="edit_phone" name="edit_phone">
											</div>
										</div>

									</div>
									<!-- <div class="table-responsive m-t-15">
										<table class="table table-striped custom-table">
											<thead>
												<tr>
													<th>Module Permission</th>
													<th class="text-center">Read</th>
													<th class="text-center">Write</th>
													<th class="text-center">Create</th>
													<th class="text-center">Delete</th>
													<th class="text-center">Import</th>
													<th class="text-center">Export</th>
												</tr>
											</thead>
											<tbody>
												<tr>
													<td>Holidays</td>
													<td class="text-center">
														<input checked="" type="checkbox">
													</td>
													<td class="text-center">
														<input type="checkbox">
													</td>
													<td class="text-center">
														<input type="checkbox">
													</td>
													<td class="text-center">
														<input type="checkbox">
													</td>
													<td class="text-center">
														<input type="checkbox">
													</td>
													<td class="text-center">
														<input type="checkbox">
													</td>
												</tr>
												<tr>
													<td>Leaves</td>
													<td class="text-center">
														<input checked="" type="checkbox">
													</td>
													<td class="text-center">
														<input checked="" type="checkbox">
													</td>
													<td class="text-center">
														<input checked="" type="checkbox">
													</td>
													<td class="text-center">
														<input type="checkbox">
													</td>
													<td class="text-center">
														<input type="checkbox">
													</td>
													<td class="text-center">
														<input type="checkbox">
													</td>
												</tr>
												<tr>
													<td>Clients</td>
													<td class="text-center">
														<input checked="" type="checkbox">
													</td>
													<td class="text-center">
														<input checked="" type="checkbox">
													</td>
													<td class="text-center">
														<input checked="" type="checkbox">
													</td>
													<td class="text-center">
														<input type="checkbox">
													</td>
													<td class="text-center">
														<input type="checkbox">
													</td>
													<td class="text-center">
														<input type="checkbox">
													</td>
												</tr>
												<tr>
													<td>Projects</td>
													<td class="text-center">
														<input checked="" type="checkbox">
													</td>
													<td class="text-center">
														<input type="checkbox">
													</td>
													<td class="text-center">
														<input type="checkbox">
													</td>
													<td class="text-center">
														<input type="checkbox">
													</td>
													<td class="text-center">
														<input type="checkbox">
													</td>
													<td class="text-center">
														<input type="checkbox">
													</td>
												</tr>
												<tr>
													<td>Tasks</td>
													<td class="text-center">
														<input checked="" type="checkbox">
													</td>
													<td class="text-center">
														<input checked="" type="checkbox">
													</td>
													<td class="text-center">
														<input checked="" type="checkbox">
													</td>
													<td class="text-center">
														<input checked="" type="checkbox">
													</td>
													<td class="text-center">
														<input type="checkbox">
													</td>
													<td class="text-center">
														<input type="checkbox">
													</td>
												</tr>
												<tr>
													<td>Chats</td>
													<td class="text-center">
														<input checked="" type="checkbox">
													</td>
													<td class="text-center">
														<input checked="" type="checkbox">
													</td>
													<td class="text-center">
														<input checked="" type="checkbox">
													</td>
													<td class="text-center">
														<input checked="" type="checkbox">
													</td>
													<td class="text-center">
														<input type="checkbox">
													</td>
													<td class="text-center">
														<input type="checkbox">
													</td>
												</tr>
												<tr>
													<td>Assets</td>
													<td class="text-center">
														<input checked="" type="checkbox">
													</td>
													<td class="text-center">
														<input checked="" type="checkbox">
													</td>
													<td class="text-center">
														<input checked="" type="checkbox">
													</td>
													<td class="text-center">
														<input checked="" type="checkbox">
													</td>
													<td class="text-center">
														<input type="checkbox">
													</td>
													<td class="text-center">
														<input type="checkbox">
													</td>
												</tr>
												<tr>
													<td>Timing Sheets</td>
													<td class="text-center">
														<input checked="" type="checkbox">
													</td>
													<td class="text-center">
														<input checked="" type="checkbox">
													</td>
													<td class="text-center">
														<input checked="" type="checkbox">
													</td>
													<td class="text-center">
														<input checked="" type="checkbox">
													</td>
													<td class="text-center">
														<input type="checkbox">
													</td>
													<td class="text-center">
														<input type="checkbox">
													</td>
												</tr>
											</tbody>
										</table>
									</div> -->
									<div class="submit-section">
										<button class="btn btn-primary submit-btn">Save</button>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
				<!-- /Edit Employee Modal -->
				
				<!-- Delete Employee Modal -->
				<div class="modal custom-modal fade" id="delete_employee" role="dialog">
					<div class="modal-dialog modal-dialog-centered">
						<div class="modal-content">
							<div class="modal-body">
								<div class="form-header">
									<h3>Delete Employee</h3>
									<p>Are you sure want to delete?</p>
								</div>
								<div class="modal-btn delete-action">
									<div class="row">
										<div class="col-6">
											<a id="comform_delete" href="javascript:void(0);" data-user_id="" class="btn btn-primary continue-btn">Delete</a>
										</div>
										<div class="col-6">
											<a href="javascript:void(0);" data-dismiss="modal" class="btn btn-primary cancel-btn">Cancel</a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- /Delete Employee Modal -->
				
				<!-- Status Employee Modal -->
				<div class="modal custom-modal fade" id="status_model" role="dialog">
					<div class="modal-dialog modal-dialog-centered">
						<div class="modal-content">
							<div class="modal-body">
								<div class="form-header">
									<h3>User Status</h3>
									<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
								</div>
								<div class="modal-btn delete-action">
								    <form id="employee_status" method="post">
									    <input type="hidden" name="status_user_id" id="status_user_id">
									<div class="row">
									    <div class="col-sm-6">
											<div class="form-group">
												<label class="col-form-label">Status</label>
											    <select class="select" id="user_status" name="user_status">
													<option value="1">Approve</option>
													<option value="2">Reject</option>
												</select>
											</div>
										 </div>
										 </div>
										<div class="row" align="center">
										<div class="submit-section">
										<button class="btn btn-primary submit-btn">Save</button>
									</div>
									</div>
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- /Status Employee Modal -->
				
            </div>
			<!-- /Page Wrapper -->
			
        </div>
		<!-- /Main Wrapper -->
		
		<!-- jQuery -->
       <?php $this->load->view('common_css_js/footer_js');?>
		<script type="text/javascript">
    
     function lead_function($id)
      {
          $("#status_user_id").val($id);
      }

	$(document).on("submit", "#employee_add", function (event) 
	{
		//$('#myModal').modal('hide'); 

		//alert(); 

		//return false;
		
		event.preventDefault(); 

        $.ajax({
			                   type: "POST",
			                   url: "<?php echo site_url().'admin_dashboard/ajax_add_employee'; ?>",
			                   data: $("#employee_add").serialize(), 
			                   success: function(data)
			                   {

			                   	//alert(data);
			                   //	console.log(date);

			                   	//return false;

                             
			                        if(data =='1')
			                        {    



			                              swal("Success!", "Employee Details Added Successfully", "success");
			                              $( '#employee_add' ).each(function()
			                              {
			                                this.reset();
			                               $( ".close" ).click();
			                               location.reload();
			                                //$( ".page-title" ).text('ss');

			                             });

			                        }
			                        else
			                        {

			                        	swal("Failed!", "Try Again Later.", "error");
			                              $( '#employee_add' ).each(function()
			                              {
			                                //this.reset();
			                               //$( "#cancel_model" ).click();

			                             });

			                        	

			                        }
			                   }
                });


    });

    $(document).on("click", ".edit_employee_model", function (event) 
    {
    	
   	//  	alert($(this).data('user_id'));
    	$('#edit_user_id').val($(this).data('user_id'));
    	$('#edit_user_name').val($(this).data('user_name'));
    	$('#edit_employee_id').val($(this).data('employee_id'));
    	$('#edit_email').val($(this).data('email'));
    	$('#edit_password').val($(this).data('password'));
    	$('#confirm_password').val($(this).data('confirm_password'));
    	$('#edit_phone').val($(this).data('phone_no'));
        $('#edit_status').val($(this).data('status'));
    	

        $('select[name=edit_employee_role]').val($(this).data('employee_role'));
        var select_value = $("#edit_employee_role option[value="+$(this).data('employee_role')+"]").text();
        $('#select2-edit_employee_role-container').text(select_value);

         //alert($(this).data('department'));
         $('select[name=edit_department]').val($(this).data('department'));
        var select_department = $("#edit_department option[value="+$(this).data('department')+"]").text();
        $('#select2-edit_department-container').text(select_department);

         //alert($(this).data('department'));
         $('select[name=edit_designation]').val($(this).data('designation'));
        var select_designation = $("#edit_designation option[value="+$(this).data('designation')+"]").text();
        $('#select2-edit_designation-container').text(select_designation);



    	//$('#edit_department').val($(this).data('department'));
    	//$('#edit_designation').val($(this).data('designation'));
    	 //$("#edit_employee_role]").val();
    	$('#user_id').val($(this).data('user_id'));
    
    });

    $(document).on("submit", "#employee_edit", function (event) 
	{
		event.preventDefault(); 
		
        $.ajax({
			                   type: "POST",
			                   url: "<?php echo site_url().'admin_dashboard/ajax_edit_employee'; ?>",
			                   data: $("#employee_edit").serialize(), 
			                   success: function(data)
			                   {

			                   	//alert(data);
			                   ///console.log(data);

			                   //return false;

                             
			                        if(data =='1')
			                        {    

			                        	$('#change_user_name').val();


			                            swal("Success!", "Employee Details Updated Successfully", "success");



			                              //alert(); return false;
			                              $( '#employee_edit' ).each(function()
			                              {
			                                this.reset();
			                               $( ".close" ).click();
			                               location.reload();
			                                //$( ".page-title" ).text('ss');

			                             });

			                        }
			                        else
			                        {

			                        	swal("Failed!", "Try Again Later.", "error");
			                              $( '#employee_edit' ).each(function()
			                              {
			                                //this.reset();
			                               //$( "#cancel_model" ).click();

			                             });

			                        	

			                        }
			                   }
                });


    });
    
    
    $(document).on("submit", "#employee_status", function (event) 
	{
		event.preventDefault(); 
		
        $.ajax({
			                   type: "POST",
			                   url: "<?php echo site_url().'admin_dashboard/ajax_employee_status'; ?>",
			                   data: $("#employee_status").serialize(), 
			                   success: function(data)
			                   {
                             
			                        if(data =='1')
			                        {    

			                        	$('#change_user_name').val();


			                            swal("Success!", "User Status Updated Successfully", "success");



			                              //alert(); return false;
			                              $( '#employee_status' ).each(function()
			                              {
			                                this.reset();
			                               $( ".close" ).click();
			                               location.reload();
			                                //$( ".page-title" ).text('ss');

			                             });

			                        }
			                        else
			                        {

			                        	swal("Failed!", "Try Again Later.", "error");
			                              $( '#employee_status' ).each(function()
			                              {
			                                //this.reset();
			                               //$( "#cancel_model" ).click();

			                             });

			                        	

			                        }
			                   }
                });


    });

    $(document).on("click", ".delete_employee", function (event) 
    {
    	
   	 	//alert($(this).data('user_id'));

   	 	$("#comform_delete").attr('data-user_id', $(this).data('user_id'));
    
    });

     $(document).on("click", "#comform_delete", function () 
	{
		
       /*alert($(this).data('user_id'));
		return  false;*/
		//$(this).attr('','');

		var user_id = $(this).data('user_id');
		
        $.ajax({
			                   type: "POST",
			                   url: "<?php echo site_url().'admin_dashboard/ajax_delete_employee'; ?>",
			                   data: {'user_id':$(this).data('user_id')}, 
			                   success: function(data)
			                   {

			                       // alert(data);
			                        //console.log(data);

			                        //return false;

                             
			                        if(data =='1')
			                        {    

			                        	/*$('#change_user_name').text($('#edit_first_name').val()+' '+$('#edit_last_name').val());

			          
			                        	$('#change_designation').text($("#edit_designation option:selected").text());*/

			                        	//alert(user_id);

			                        	$('#eemployees_list_'+user_id).hide();


			                            swal("Success!", "Employee Details Deleted Successfully", "success");

                                         $('#modal-content').hide();

                                         $(".cancel-btn").click();
			                             location.reload();
			                                

			                        }
			                        else
			                        {

			                        	swal("Failed!", "Try Again Later.", "error");
			                              $( '#employee_edit' ).each(function()
			                              {
			                                //this.reset();
			                               //$( "#cancel_model" ).click();

			                             });

			                        	

			                        }
			                   }
                });


    });
    
    
    


</script>
    </body>
    
</html>