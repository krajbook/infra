﻿<?php 

$clients = $clients_list;

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
        
        <title>Apps</title>
		
	

		<?php $this->load->view('common_css_js/css'); ?>
		
    </head>
    <body>
		<!-- Main Wrapper -->
        <div class="main-wrapper">
		
			<!-- Header -->
            <?php $this->load->view('common/set_header'); ?>
			<!-- Header -->
            <?php $this->load->view('common_css_js/side_header'); ?>
			<!-- /Sidebar -->
			
			<!-- Page Wrapper -->
            <div class="page-wrapper">
			
				<!-- Page Content -->
                <div class="content container-fluid">
				
					<!-- Page Header -->
					<?php $this->load->view('common_css_js/clients_header'); ?>
					<!-- /Page Header -->
					
				
					
					<div class="row staff-grid-row">

					   	<!-- Add Client Modal -->
				<div id="add_client" class="modal custom-modal fade" role="dialog">
					<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
						<div class="modal-content">
							<div class="modal-header">
								<h5 class="modal-title">Custom Apps</h5>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>
							<div class="modal-body">
								<form method="post" id="add_client_form" enctype="multipart/form-data">
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<label class="col-form-label">First Name <span class="text-danger">*</span></label>
												<input class="form-control" type="text" name="first_name" id="first_name" required>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label class="col-form-label">Last Name</label>
												<input class="form-control" type="text" name="last_name" id="last_name">
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label class="col-form-label">Username <span class="text-danger">*</span></label>
												<input class="form-control" type="text" name="user_name" id="user_name" required>
											</div>
										</div>
										

									</div>
									
									<div class="submit-section">
										<button class="btn btn-primary submit-btn">Submit</button>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
				
						

						
					</div>
                </div>
				<!-- /Page Content -->
			
			<?php $this->load->view('common_css_js/clients_models');?>
				
            </div>
			<!-- /Page Wrapper -->
			
        </div>
		<!-- /Main Wrapper -->
		


		<?php $this->load->view('common_css_js/footer_js');?>

		<?php $this->load->view('common_css_js/clients_js');?>

	
		
    </body>
</html>