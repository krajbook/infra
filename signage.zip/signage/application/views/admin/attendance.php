﻿<?php $employees_list = $employees_list;

$employees_in_out     = array_reverse($employees_in_out);


//echo "<pre>"; print_r($employees_list); exit;

$datecount            = date('d');

$check_user           = array();

$check_user1          = array();


foreach ($employees_in_out as $getkey => $getvalue) 
{
	$check_user1[$getvalue->user_id] = $getvalue->user_id;

}

$list = array();

for($i=0;$i<count($employees_list);$i++)
{


	if(array_key_exists($employees_list[$i]->user_id, $check_user1))
	{

		$cal = array();

		for($j=1;$j<=$datecount;$j++)
		{

			$cal[$j] ='false';

			$in_out_list[$j] =array(
			        							'time_sheet'=>'',

			        							'punch_in_at'=>'',

			        							'punch_in_out'=>'',

			        							'break'=>'',

			        							'over_time'=>'',

			        							'total_work'=>'',

			        							'activity'=>''

			        						);

			for($ec=0;$ec<count($employees_in_out);$ec++)
			{

			    $current_date = ltrim(date('d',strtotime($employees_in_out[$ec]->in_time)),0);

			    if($current_date==$j && $employees_list[$i]->user_id==$employees_in_out[$ec]->user_id)
			    {

			    	$time_in  = date('H:i',strtotime($employees_in_out[$ec]->in_time));

			    	$cal_time = date('H:i',strtotime('0000-00-00 11:59:59'));

			    	$time_out = ($employees_in_out[$ec]->out_time !='') ?

			    				 date('H:i',strtotime($employees_in_out[$ec]->out_time)) :date('H:i',strtotime('23:59'));

			    	$out_time_diff = ($employees_in_out[$ec]->out_time!='') ? $employees_in_out[$ec]->out_time :date('Y-m-d H:i:s'); 


					$datetime1 = new DateTime($employees_in_out[$ec]->in_time);
					
					$datetime2 = new DateTime($out_time_diff);
					
					$interval = $datetime1->diff($datetime2);
					
					$diff =$interval->format('%h').'.'.$interval->format('%i')." hrs";

			        $in_out_list[$j] =array(
			        							'time_sheet'=>date('d M Y',strtotime($employees_in_out[$ec]->in_time)),

			        							'punch_in_at'=>date('D,jS M Y h.i A',strtotime($employees_in_out[$ec]->in_time)),

			        							'punch_in_out'=>($employees_in_out[$ec]->out_time !='') ? date('D,jS M Y h.i A',strtotime($employees_in_out[$ec]->out_time)) :'',

			        							'break'=>'1.00 hrs',

			        							'over_time'=>($interval->format('%h')>=9) ? ($interval->format('%h')-9):0,

			        							'total_work'=>$diff,

			        							'activity'=>array(

			        												'punch_in_at'=>date('h:i A',strtotime($employees_in_out[$ec]->in_time)),


			        							                    'punch_in_out'=>($employees_in_out[$ec]->out_time !='') ? date('h:i A',strtotime($employees_in_out[$ec]->out_time)) :'')

			        						);

			    				

			    	if((strtotime($time_in) <= strtotime($cal_time)  && strtotime($time_out) >= strtotime($cal_time)) && ($employees_in_out[$ec]->time_status =='time_in' || $employees_in_out[$ec]->time_status =='time_out'))
			    	{

			    		$cal[$j]  = 'full_day';

			    		


			    	}
			    	else if((strtotime($time_in) >= strtotime($cal_time)  && strtotime($time_out) >= strtotime($time_in)) && ($employees_in_out[$ec]->time_status =='time_in' || $employees_in_out[$ec]->time_status =='time_out'))
			    	{

			    		$cal[$j]  = 'second_half_day';

			    		


			    	}
			    	else if((strtotime($time_in) <= strtotime($cal_time)  && strtotime($time_out) <= strtotime($cal_time)) && ($employees_in_out[$ec]->time_status =='time_out'))
			    	{

			    		$cal[$j]  = 'first_half_day';

			    		


			    	}
                 
			    }
				
			}


			
		}

		$list[$employees_list[$i]->user_id] =array('emp_details'=>$employees_list[$i],'att'=>$cal,'in_out_list'=>$in_out_list); 



	}
	else
	{
		$cal =array();

		for($j=1;$j<=$datecount;$j++)
		{


			$cal[$j] ='false';

			  $in_out_list[$j] =array(
			        							'time_sheet'=>'',

			        							'punch_in_at'=>'',

			        							'punch_in_out'=>'',

			        							'break'=>'',

			        							'over_time'=>'',

			        							'total_work'=>'',

			        							'activity'=>''

			        						);

		}
		$list[$employees_list[$i]->user_id] =array('emp_details'=>$employees_list[$i],'att'=>$cal,'in_out_list'=>$in_out_list); 


	}

/*for($j=1;$j<=$datecount;$j++)
{


	$cal[$j] ='false';
}


	$list[$employees_list[$i]->user_id] =array('att'=>$cal); */

	//print_r($list); exit;
}
/*echo "<pre>";
print_r($list); exit;*/



?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
        
        <title>Attendance</title>
		
		<?php $this->load->view('common_css_js/css'); ?>
    </head>
    <body>
		<!-- Main Wrapper -->
        <div class="main-wrapper">
		
			<!-- Header -->
             <?php $this->load->view('common_css_js/header'); ?>
             <?php $this->load->view('common_css_js/side_header'); ?>

			<!-- /Sidebar -->
			
			<!-- Page Wrapper -->
            <div class="page-wrapper">
                <div class="content container-fluid">
				
					<!-- Page Header -->
					<div class="page-header">
						<div class="row">
							<div class="col-sm-12">
								<h3 class="page-title">Attendance</h3>
								<ul class="breadcrumb">
									<li class="breadcrumb-item"><a href="<?php echo base_url(); ?>">Dashboard</a></li>
									<li class="breadcrumb-item active">Attendance</li>
								</ul>
							</div>
						</div>
					</div>
					<!-- /Page Header -->
					
					<!-- Search Filter -->
					<div class="row filter-row">
						<div class="col-sm-6 col-md-3">  
							<div class="form-group form-focus">
								<input type="text" class="form-control floating">
								<label class="focus-label">Employee Name</label>
							</div>
						</div>
						<div class="col-sm-6 col-md-3"> 
							<div class="form-group form-focus select-focus">
								<select class="select floating"> 
									<option>-</option>
									<option>Jan</option>
									<option>Feb</option>
									<option>Mar</option>
									<option>Apr</option>
									<option>May</option>
									<option>Jun</option>
									<option>Jul</option>
									<option>Aug</option>
									<option>Sep</option>
									<option>Oct</option>
									<option>Nov</option>
									<option>Dec</option>
								</select>
								<label class="focus-label">Select Month</label>
							</div>
						</div>
						<div class="col-sm-6 col-md-3"> 
							<div class="form-group form-focus select-focus">
								<select class="select floating"> 
									<option>-</option>
									<option>2019</option>
									<option>2018</option>
									<option>2017</option>
									<option>2016</option>
									<option>2015</option>
								</select>
								<label class="focus-label">Select Year</label>
							</div>
						</div>
						<div class="col-sm-6 col-md-3">  
							<a href="#" class="btn btn-success btn-block"> Search </a>  
						</div>     
                    </div>
					<!-- /Search Filter -->
					
                    <div class="row">
                        <div class="col-lg-12">
							<div class="table-responsive">
								<table class="table table-striped custom-table table-nowrap mb-0">
									<thead>
										<tr>
											<th>Employee</th>

											<?php 

										    $total_days = date('t');

											for($ii=1;$ii<=$total_days;$ii++) 
											{ ?>
												<th><?= $ii; ?></th>
											 
											 <?php 

											}

											 ?>
											
										</tr>
									</thead>
<tbody>

	<?php 
	

		if(!empty($list))
		{
			foreach ($list as $employees_list_value) 


			{  $first_name = $employees_list_value['emp_details']->user_fname;

		       $user_lname = $employees_list_value['emp_details']->user_lname;


		        //print_r($employees_list_value['emp_details']->user_lname);
		?>

				<tr>
		
		            <td>
			
						<h2 class="table-avatar">
			
							<a class="avatar avatar-xs" href="<?php echo base_url(); ?>home/profile">

								<img alt="" src="<?php echo base_url(); ?>assets\img\profiles\avatar-09.jpg">

							</a>
				
							<a href="<?php echo base_url(); ?>home/profile">

								<?php echo $first_name." ".$user_lname; ?>

							</a>
				
				        </h2>
					
		            </td>

		            <?php 
		            foreach($employees_list_value['att'] as $key=>$attr)
		            { 
		            	//echo $employees_list_value['in_out_list'][$key]['time_sheet']; 

		                //echo "<pre>"; print_r($employees_list_value['in_out_list'][$key]['activity']);

		                $implode='';

		                if(!empty($employees_list_value['in_out_list'][$key]['activity']))
		                {
		                	foreach ($employees_list_value['in_out_list'][$key]['activity'] as $keys => $values) 
		                		{
		                			//print_r($keys);
		                		$implode.=($implode=='')? $keys.'__'.$values:'___'.$keys.'__'.$values;
		                		}


		                }

		                

		            	if($attr=='full_day')
		            	{
		            		echo '<td><a href="javascript:void(0);"  class="show_time_details"

		            		data-time_sheet="'.$employees_list_value['in_out_list'][$key]['time_sheet'].'"

		            		data-punch_in_at="'.$employees_list_value['in_out_list'][$key]['punch_in_at'].'"

		            		data-punch_in_out="'.$employees_list_value['in_out_list'][$key]['punch_in_out'].'"

		            		data-break="'.$employees_list_value['in_out_list'][$key]['break'].'"

		            		data-over_time="'.$employees_list_value['in_out_list'][$key]['over_time'].'"

		            		data-total_work="'.$employees_list_value['in_out_list'][$key]['total_work'].'"

		            		data-activity="'.$implode.'"


		            		data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>';

		            	}
		            	else if($attr=='second_half_day')
		            	{
		            		echo '<td>
												<div class="half-day">
													<span class="first-off"><i class="fa fa-close text-danger"></i></span> 
													<span class="first-off"><a href="javascript:void(0);" class="show_time_details"

													data-time_sheet="'.$employees_list_value['in_out_list'][$key]['time_sheet'].'"

		            		data-punch_in_at="'.$employees_list_value['in_out_list'][$key]['punch_in_at'].'"

		            		data-punch_in_out="'.$employees_list_value['in_out_list'][$key]['punch_in_out'].'"

		            		data-break="'.$employees_list_value['in_out_list'][$key]['break'].'"

		            		data-over_time="'.$employees_list_value['in_out_list'][$key]['over_time'].'"

		            		data-total_work="'.$employees_list_value['in_out_list'][$key]['total_work'].'"

		            		data-activity="'.$implode.'"

													data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></span>
												</div>
											</td>';

		            	}
		            	else if($attr=='first_half_day')
		            	{
		            		echo '<td>
													<div class="half-day">
														<span class="first-off"><a href="javascript:void(0);" class="show_time_details"

														data-time_sheet="'.$employees_list_value['in_out_list'][$key]['time_sheet'].'"

		            		data-punch_in_at="'.$employees_list_value['in_out_list'][$key]['punch_in_at'].'"

		            		data-punch_in_out="'.$employees_list_value['in_out_list'][$key]['punch_in_out'].'"

		            		data-break="'.$employees_list_value['in_out_list'][$key]['break'].'"

		            		data-over_time="'.$employees_list_value['in_out_list'][$key]['over_time'].'"

		            		data-total_work="'.$employees_list_value['in_out_list'][$key]['total_work'].'"

		            		data-activity="'.$implode.'"

														data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></span> 
														<span class="first-off"><i class="fa fa-close text-danger"></i></span>
													</div>
												</td>';

		            	}
		            	else if($attr=='false')
		            	{
		            		echo '<td><i class="fa fa-close text-danger"></i> </td>';

		            	}

		            	


		            	
		            }


		            ?>


					
                </tr>
				



			 <?php 
		    }
		}
		?>

	



<!-- 
	 <tr>
		
		<td>
			
			<h2 class="table-avatar">
			
				<a class="avatar avatar-xs" href="<?php echo base_url(); ?>home/profile">

						<img alt="" src="<?php echo base_url(); ?>assets\img\profiles\avatar-09.jpg">

				</a>
				
				<a href="<?php echo base_url(); ?>home/profile">John Doe

				</a>
				
				</h2>
					
					</td>
					<td>
						<a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info">

							<i class="fa fa-check text-success"></i>

						</a>
					</td>
					
					<td>

						<a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info">

							<i class="fa fa-check text-success"></i>

						</a>

					</td>
					
					<td>

						<a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info">

							<i class="fa fa-check text-success">
								

							</i>
						</a>

					</td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td>
												<div class="half-day">
													<span class="first-off"><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></span> 
													<span class="first-off"><i class="fa fa-close text-danger"></i></span>
												</div>
											</td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td>
												<div class="half-day">
													<span class="first-off"><i class="fa fa-close text-danger"></i></span> 
													<span class="first-off"><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></span>
												</div>
											</td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
   </tr>  -->
										<!-- <tr>
											<td>
												<h2 class="table-avatar">
													<a class="avatar avatar-xs" href="<?php echo base_url(); ?>home/profile"><img alt="" src="<?php echo base_url(); ?>assets\img\profiles\avatar-09.jpg"></a>
													<a href="<?php echo base_url(); ?>home/profile">Richard Miles</a>
												</h2>
											</td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
										</tr> -->
										<!-- <tr>
											<td>
												<h2 class="table-avatar">
													<a class="avatar avatar-xs" href="<?php echo base_url(); ?>home/profile"><img alt="" src="<?php echo base_url(); ?>assets\img\profiles\avatar-10.jpg"></a>
													<a href="<?php echo base_url(); ?>home/profile">John Smith</a>
												</h2>
											</td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
										</tr> -->
										<!-- <tr>
											<td>
												<h2 class="table-avatar">
													<a class="avatar avatar-xs" href="<?php echo base_url(); ?>home/profile"><img alt="" src="<?php echo base_url(); ?>assets\img\profiles\avatar-05.jpg"></a>
													<a href="<?php echo base_url(); ?>home/profile">Mike Litorus</a>
												</h2>
											</td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
										</tr> -->
										<!-- <tr>
											<td>
												<h2 class="table-avatar">
													<a class="avatar avatar-xs" href="<?php echo base_url(); ?>home/profile"><img alt="" src="<?php echo base_url(); ?>assets\img\profiles\avatar-11.jpg"></a>
													<a href="<?php echo base_url(); ?>home/profile">Wilmer Deluna</a>
												</h2>
											</td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
										</tr> -->
										<!-- <tr>
											<td>
												<h2 class="table-avatar">
													<a class="avatar avatar-xs" href="<?php echo base_url(); ?>home/profile"><img alt="" src="<?php echo base_url(); ?>assets\img\profiles\avatar-12.jpg"></a>
													<a href="<?php echo base_url(); ?>home/profile">Jeffrey Warden</a>
												</h2>
											</td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
										</tr> -->
										<!-- <tr>
											<td>
												<h2 class="table-avatar">
													<a class="avatar avatar-xs" href="<?php echo base_url(); ?>home/profile"><img alt="" src="<?php echo base_url(); ?>assets\img\profiles\avatar-13.jpg"></a>
													<a href="<?php echo base_url(); ?>home/profile">Bernardo Galaviz</a>
												</h2>
											</td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
										</tr> -->
										<!-- <tr>
											<td>
												<h2 class="table-avatar">
													<a class="avatar avatar-xs" href="<?php echo base_url(); ?>home/profile"><img alt="" src="<?php echo base_url(); ?>assets\img\profiles\avatar-01.jpg"></a>
													<a href="<?php echo base_url(); ?>home/profile">Lesley Grauer</a>
												</h2>
											</td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
										</tr> -->
										<!-- <tr>
											<td>
												<h2 class="table-avatar">
													<a class="avatar avatar-xs" href="<?php echo base_url(); ?>home/profile"><img alt="" src="<?php echo base_url(); ?>assets\img\profiles\avatar-16.jpg"></a>
													<a href="<?php echo base_url(); ?>home/profile">Jeffery Lalor</a>
												</h2>
											</td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
										</tr> -->
									<!-- 	<tr>
											<td>
												<h2 class="table-avatar">
													<a class="avatar avatar-xs" href="<?php echo base_url(); ?>home/profile"><img alt="" src="<?php echo base_url(); ?>assets\img\profiles\avatar-04.jpg"></a>
													<a href="<?php echo base_url(); ?>home/profile">Loren Gatlin</a>
												</h2>
											</td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><i class="fa fa-close text-danger"></i> </td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
											<td><a href="javascript:void(0);" data-toggle="modal" data-target="#attendance_info"><i class="fa fa-check text-success"></i></a></td>
										</tr> -->
									</tbody>
								</table>
							</div>
                        </div>
                    </div>
                </div>
				<!-- /Page Content -->
				
				<!-- Attendance Modal -->
				<div class="modal custom-modal fade" id="attendance_info" role="dialog">
					<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
						<div class="modal-content">
							<div class="modal-header">
								<h5 class="modal-title">Attendance Info</h5>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>
							<div class="modal-body">
								<div class="row">
									<div class="col-md-6">
										<div class="card punch-status">
											<div class="card-body">
												<h5 class="card-title">Timesheet <small class="text-muted"><span id="time_sheet"></span></small></h5>

												<div class="punch-det">
													<h6>Punch In at</h6>
													<p id="punch_in_at">Wed, 11th Mar 2019 10.00 AM</p>
												</div>
												<div class="punch-info">
													<div class="punch-hours">
														<span id="total_work">3.45 hrs</span>
													</div>
												</div>
												<div class="punch-det">
													<h6>Punch Out at</h6>
													<p id="punch_in_out">Wed, 20th Feb 2019 9.00 PM</p>
												</div>
												<div class="statistics">
													<div class="row">
														<div class="col-md-6 col-6 text-center">
															<div class="stats-box">
																<p>Break</p>
																<h6 id="break">1.21 hrs</h6>
															</div>
														</div>
														<div class="col-md-6 col-6 text-center">
															<div class="stats-box">
																<p>Overtime</p>
																<h6 id="over_time">3 hrs</h6>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div><!-- activity -->
									<div class="col-md-6">
										<div class="card recent-activity">
											<div class="card-body">
												<h5 class="card-title">Activity</h5>
												<ul class="res-activity-list" id="add_activity">
													<!-- <li>
														<p class="mb-0">Punch In at</p>
														<p class="res-activity-time">
															<i class="fa fa-clock-o"></i>
															10.00 AM.
														</p>
													</li>
													<li>
														<p class="mb-0">Punch Out at</p>
														<p class="res-activity-time">
															<i class="fa fa-clock-o"></i>
															11.00 AM.
														</p>
													</li>
													<li>
														<p class="mb-0">Punch In at</p>
														<p class="res-activity-time">
															<i class="fa fa-clock-o"></i>
															11.15 AM.
														</p>
													</li>
													<li>
														<p class="mb-0">Punch Out at</p>
														<p class="res-activity-time">
															<i class="fa fa-clock-o"></i>
															1.30 PM.
														</p>
													</li>
													<li>
														<p class="mb-0">Punch In at</p>
														<p class="res-activity-time">
															<i class="fa fa-clock-o"></i>
															2.00 PM.
														</p>
													</li>
													<li>
														<p class="mb-0">Punch Out at</p>
														<p class="res-activity-time">
															<i class="fa fa-clock-o"></i>
															7.30 PM.
														</p>
													</li> -->
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- /Attendance Modal -->
				
            </div>
			<!-- Page Wrapper -->
			
        </div>
		<!-- /Main Wrapper -->
		
		<!-- jQuery -->
       <?php $this->load->view('common_css_js/footer_js');?>

		<script type="text/javascript">

			  $(document).on("click", ".show_time_details", function (event) 
    {
    	$('#add_activity').html('');
   	 	

   	 	var activity = $(this).data('activity');

   	 	var cons = activity.split("___");

   	 
   	 	cons.forEach(function(cons)
   	 	{
              var cons_sub = cons.split("__");

              	//console.log(cons_sub);

              if(cons_sub[0]=='punch_in_at')
              {
              	
              	$('#add_activity').append('<li><p class="mb-0">Punch In at</p><p class="res-activity-time"><i class="fa fa-clock-o"></i>'+cons_sub[1]+'.</p></li>');
              	
              }
               if(cons_sub[0]=='punch_in_out')
              {
              	
              	$('#add_activity').append('<li><p class="mb-0">Punch Out at</p><p class="res-activity-time"><i class="fa fa-clock-o"></i>'+cons_sub[1]+'.</p></li>');
              }

              
         });


    	$('#time_sheet').text($(this).data('time_sheet'));
    	$('#punch_in_at').text($(this).data('punch_in_at'));
    	$('#punch_in_out').text($(this).data('punch_in_out'));
    	$('#break').text($(this).data('break'));
    	$('#over_time').text($(this).data('over_time'));
    	$('#total_work').text($(this).data('total_work'));
    	
    	
    
    });
			
			
	</script>
		
    </body>
</html>