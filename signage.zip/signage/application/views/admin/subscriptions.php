﻿<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
        <title>Subscriptions</title>
        <?php $this->load->view('common_css_js/css'); ?>
    </head>
    <body>
		<!-- Main Wrapper -->
        <div class="main-wrapper">
		
			<!-- Header -->
            <?php $this->load->view('common/set_header'); ?>
			<!-- Header -->
            <?php $this->load->view('common_css_js/side_header'); ?>
			<!-- /Sidebar -->
			
			<!-- Page Wrapper -->
            <div class="page-wrapper">
			
				<!-- Page Content -->
                <div class="content container-fluid">
					
					<!-- Page Header -->
					<div class="page-header">
						
						<div class="row">
							<div class="col">
								<h3 class="page-title">Subscriptions</h3>
								<ul class="breadcrumb">
									<li class="breadcrumb-item"><a href="<?php echo base_url(); ?>">Dashboard</a></li>
									<li class="breadcrumb-item active">Subscriptions</li>
								</ul>
							</div>
<!-- 							<div class="col-auto float-right ml-auto">
								<a href="#" class="btn add-btn" data-toggle="modal" data-target="#add_plan"><i class="fa fa-plus"></i> Add Subscription</a>
							</div> -->
						</div>
		  
				
					</div>
					<!-- /Page Header -->
				
					<div class="row">
						<div class="col-lg-10 mx-auto">
						
							<!-- Plan Tab -->
							<div class="row justify-content-center mb-4">
								<div class="col-auto">
									<nav class="nav btn-group">
										<a href="#monthly" class="btn btn-outline-secondary active show" data-toggle="tab">Monthly Plan</a>
										<a href="#annual" class="btn btn-outline-secondary" data-toggle="tab">Annual Plan</a>
									</nav>
								</div>
							</div>
							<!-- /Plan Tab -->

							<!-- Plan Tab Content -->
							<div class="tab-content">
							
								<!-- Monthly Tab -->
								<div class="tab-pane fade active show" id="monthly">
								<?php $plan_list = $this->nlp_model->select_order('subscribe_plans',array('id'=>1))->row();
								$plan_list2 = $this->nlp_model->select_order('subscribe_plans',array('id'=>2))->row();
								$plan_list3 = $this->nlp_model->select_order('subscribe_plans',array('id'=>3))->row();
								$plan_list4 = $this->nlp_model->select_order('subscribe_plans',array('id'=>4))->row(); ?>

									<div class="row mb-30 equal-height-cards">
										<div class="col-md-2"></div>
										<div class="col-md-4">
											<div class="card pricing-box">
												<div class="card-body d-flex flex-column">
													<div class="mb-4">
														<h3><?php echo $plan_list->name ?></h3>
														<span class="display-4">Rs. <?php echo $plan_list->price ?></span>

								    <div class="dropdown dropdown-action" align="right">
									
									<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>
									<div class="dropdown-menu dropdown-menu-right">
										<a 
											class="dropdown-item edit_employee_model" 

											href="#" data-toggle="modal" 

											data-plan_id="<?php echo $plan_list->id; ?>" 

                                            data-plan_price="<?php echo $plan_list->price; ?>"

                                            data-plan_name="<?php echo $plan_list->name; ?>"

											data-target="#edit_plan" 
											
											data-plan_type="<?php echo $plan_list->type; ?>"

											data-plan_users="<?php echo $plan_list->users; ?>"

											data-plan_display="<?php echo $plan_list->display; ?>"

											data-plan_storage="<?php echo $plan_list->storage; ?>"

											data-plan_description="<?php echo $plan_list->description; ?>"

										>

										<i class="fa fa-pencil m-r-5"></i> Edit</a>
									</div>
								</div>
													</div>
													<ul>
														<li><i class="fa fa-check"></i> <b><?php echo $plan_list->users ?></b></li>
														<li><i class="fa fa-check"></i><?php echo $plan_list->display ?></li>
														<li><i class="fa fa-check"></i><?php echo $plan_list->storage ?></li>
														<li><i class="fa fa-check"></i><?php echo $plan_list->description ?></li>
													</ul>
													

												</div>
											</div>
										</div>
										<div class="col-md-4">
											<div class="card pricing-box">
												<div class="card-body d-flex flex-column">
													<div class="mb-4">
														<h3><?php echo $plan_list2->name ?></h3>
														<span class="display-4">Rs. <?php echo $plan_list2->price ?></span>
														
								    <div class="dropdown dropdown-action" align="right">
									
									<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>
									<div class="dropdown-menu dropdown-menu-right">
										<a 
											class="dropdown-item edit_employee_model" 

											href="#" data-toggle="modal" 

											data-plan_id="<?php echo $plan_list2->id; ?>" 

                                            data-plan_price="<?php echo $plan_list2->price; ?>"

                                            data-plan_name="<?php echo $plan_list2->name; ?>"

											data-target="#edit_plan" 
											
											data-plan_type="<?php echo $plan_list2->type; ?>"

											data-plan_users="<?php echo $plan_list2->users; ?>"

											data-plan_display="<?php echo $plan_list2->display; ?>"

											data-plan_storage="<?php echo $plan_list2->storage; ?>"

											data-plan_description="<?php echo $plan_list2->description; ?>"

										>

										<i class="fa fa-pencil m-r-5"></i> Edit</a>
									</div>
								</div>
													</div>
													<ul>
														<li><i class="fa fa-check"></i> <b><?php echo $plan_list2->users ?></b></li>
														<li><i class="fa fa-check"></i><?php echo $plan_list2->display ?></li>
														<li><i class="fa fa-check"></i><?php echo $plan_list2->storage ?></li>
														<li><i class="fa fa-check"></i><?php echo $plan_list2->description ?></li>
													</ul>
													

												</div>
											</div>
										</div>
										<div class="col-md-2"></div>
									</div>
									
									<!-- Monthly Plan Details -->
									<div class="row">
										<div class="col-md-12">
											<div class="card card-table mb-0">
												<div class="card-header">
													<h4 class="card-title mb-0">Plan Details</h4>
												</div>
												<div class="card-body">
													<div class="table-responsive">
														<table class="table table-hover table-center mb-0">
															<thead>
																<tr>
																	<th>Plan</th>
																	<th>Plan Type</th>
																	<th>Create Date</th>
																	<th>Modified Date</th>
																	<th>Amount</th>
																	<th>Subscribed Users</th>
																</tr>
															</thead>
															<tbody>
																<tr>
																	<td>Free Trial</td>
																	<td>Monthly</td>
																	<td>9 Nov 2019</td>
																	<td>8 Dec 2019</td>
																	<td>Free</td>
																	<td><a class="btn btn-info btn-sm" href="<?php echo base_url(); ?>">30 Users</a></td>
																</tr>
																<tr>
																	<td>Professional</td>
																	<td>Monthly</td>
																	<td>9 Nov 2019</td>
																	<td>8 Dec 2019</td>
																	<td>Rs.21</td>
																	<td><a class="btn btn-info btn-sm" href="<?php echo base_url(); ?>">97 Users</a></td>
																</tr>
																<tr>
																	<td>Enterprise</td>
																	<td>Monthly</td>
																	<td>9 Nov 2019</td>
																	<td>8 Dec 2019</td>
																	<td>Rs.38</td>
																	<td><a class="btn btn-info btn-sm" href="<?php echo base_url(); ?>">125 Users</a></td>
																</tr>
															</tbody>
														</table>
													</div>
												</div>
											</div>
										</div>
									</div>
									<!-- /Monthly Plan Details -->
								
								</div>
								<!-- /Monthly Tab -->
								
								<!-- Annual Plan Tab -->
								<div class="tab-pane fade" id="annual">
									<div class="row mb-30 equal-height-cards">
										<div class="col-md-2"></div>
										<div class="col-md-4">
											<div class="card pricing-box">
												<div class="card-body d-flex flex-column">
													<div class="mb-4">
														<h3><?php echo $plan_list3->name ?></h3>
														<span class="display-4">Rs. <?php echo $plan_list3->price ?></span>
														
								    <div class="dropdown dropdown-action" align="right">
									
									<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>
									<div class="dropdown-menu dropdown-menu-right">
										<a 
											class="dropdown-item edit_employee_model" 

											href="#" data-toggle="modal" 

											data-plan_id="<?php echo $plan_list3->id; ?>" 

                                            data-plan_price="<?php echo $plan_list3->price; ?>"

                                            data-plan_name="<?php echo $plan_list3->name; ?>"

											data-target="#edit_plan" 
											
											data-plan_type="<?php echo $plan_list3->type; ?>"

											data-plan_users="<?php echo $plan_list3->users; ?>"

											data-plan_display="<?php echo $plan_list3->display; ?>"

											data-plan_storage="<?php echo $plan_list3->storage; ?>"

											data-plan_description="<?php echo $plan_list3->description; ?>"

										>

										<i class="fa fa-pencil m-r-5"></i> Edit</a>
									</div>
								</div>
													</div>
													<ul>
														<li><i class="fa fa-check"></i> <b><?php echo $plan_list3->users ?></b></li>
														<li><i class="fa fa-check"></i><?php echo $plan_list3->display ?></li>
														<li><i class="fa fa-check"></i><?php echo $plan_list3->storage ?></li>
														<li><i class="fa fa-check"></i><?php echo $plan_list3->description ?></li>
													</ul>
													

												</div>
											</div>
										</div>
										<div class="col-md-4">
											<div class="card pricing-box">
												<div class="card-body d-flex flex-column">
													<div class="mb-4">
														<h3><?php echo $plan_list4->name ?></h3>
														<span class="display-4">Rs. <?php echo $plan_list4->price ?></span>
														
								    <div class="dropdown dropdown-action" align="right">
									
									<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>
									<div class="dropdown-menu dropdown-menu-right">
										<a 
											class="dropdown-item edit_employee_model" 

											href="#" data-toggle="modal" 

											data-plan_id="<?php echo $plan_list4->id; ?>" 

                                            data-plan_price="<?php echo $plan_list4->price; ?>"

                                            data-plan_name="<?php echo $plan_list4->name; ?>"

											data-target="#edit_plan" 
											
											data-plan_type="<?php echo $plan_list4->type; ?>"

											data-plan_users="<?php echo $plan_list4->users; ?>"

											data-plan_display="<?php echo $plan_list4->display; ?>"

											data-plan_storage="<?php echo $plan_list4->storage; ?>"

											data-plan_description="<?php echo $plan_list4->description; ?>"

										>

										<i class="fa fa-pencil m-r-5"></i> Edit</a>
									</div>
								</div>
													</div>
													<ul>
														<li><i class="fa fa-check"></i> <b><?php echo $plan_list4->users ?></b></li>
														<li><i class="fa fa-check"></i><?php echo $plan_list4->display ?></li>
														<li><i class="fa fa-check"></i><?php echo $plan_list4->storage ?></li>
														<li><i class="fa fa-check"></i><?php echo $plan_list4->description ?></li>
													</ul>
													

												</div>
											</div>
										</div>
										<div class="col-md-2">
										</div>
									</div>
									
									<!-- Yearly Plan Details -->
									<div class="row">
										<div class="col-md-12">
											<div class="card card-table mb-0">
												<div class="card-header">
													<h4 class="card-title mb-0">Plan Details</h4>
												</div>
												<div class="card-body">
													<div class="table-responsive">
														<table class="table table-hover table-center mb-0">
															<thead>
																<tr>
																	<th>Plan</th>
																	<th>Plan Type</th>
																	<th>Create Date</th>
																	<th>Modified Date</th>
																	<th>Amount</th>
																	<th>Subscribed Users</th>
																</tr>
															</thead>
															<tbody>
																<tr>
																	<td>Free Trial</td>
																	<td>Yearly</td>
																	<td>9 Nov 2019</td>
																	<td>8 Dec 2019</td>
																	<td>Free</td>
																	<td><a class="btn btn-info btn-sm" href="<?php echo base_url(); ?>home/subscribed_companies">62 Users</a></td>
																</tr>
																<tr>
																	<td>Professional</td>
																	<td>Yearly</td>
																	<td>9 Nov 2019</td>
																	<td>8 Dec 2019</td>
																	<td>Rs.199</td>
																	<td><a class="btn btn-info btn-sm" href="<?php echo base_url(); ?>home/subscribed_companies">157 Users</a></td>
																</tr>
																<tr>
																	<td>Enterprise</td>
																	<td>Yearly</td>
																	<td>9 Nov 2019</td>
																	<td>8 Dec 2019</td>
																	<td>Rs.399</td>
																	<td><a class="btn btn-info btn-sm" href="<?php echo base_url(); ?>home/subscribed_companies">241 Users</a></td>
																</tr>
															</tbody>
														</table>
													</div>
												</div>
											</div>
										</div>
									</div>
									<!-- /Yearly Plan Details -->
								
								</div>
								<!-- /Annual Plan Tab -->
								
							</div>
							<!-- /Plan Tab Content -->
						  
							<!-- Add Plan Modal -->
							<div class="modal custom-modal fade" id="add_plan" tabindex="-1" role="dialog" aria-hidden="true">
								<div class="modal-dialog modal-md modal-dialog-centered">
									<div class="modal-content">
										<button type="button" class="close" data-dismiss="modal"><i class="fa fa-close"></i></button>
										<div class="modal-body">
											<h5 class="modal-title text-center mb-3">Add Plan</h5>
											<form>
												<div class="row">
													<div class="col-md-6">
														<div class="form-group">
															<label>Plan Name</label>
															<input type="text" placeholder="Free Trial" class="form-control">
														</div>
													</div>
													<div class="col-md-6">
														<div class="form-group">
															<label>Plan Amount</label>
															<input type="text" class="form-control">
														</div>
													</div>
													<div class="col-md-6">
														<div class="form-group">
															<label>Plan Type</label>
															<select class="select"> 
																<option> Monthly </option>
																<option> Yearly </option>
															</select>
														</div>
													</div>
													<div class="col-md-6">
														<div class="form-group">
															<label>No of Users</label>
															<select class="select"> 
																<option> 5 Users </option>
																<option> 50 Users </option>
																<option> Unlimited </option>
															</select>
														</div>
													</div>
													<div class="col-md-6">
														<div class="form-group">
															<label>No of Projects</label>
															<select class="select"> 
																<option> 5 Projects </option>
																<option> 50 Projects </option>
																<option> Unlimited </option>
															</select>
														</div>
													</div>
													<div class="col-md-6">
														<div class="form-group">
															<label>No of Storage Space</label>
															<select class="select"> 
																<option> 5 GB </option>
																<option> 100 GB </option>
																<option> 500 GB </option>
															</select>
														</div>
													</div>
												</div>
												<div class="form-group">
													<label>Plan Description</label>
													<textarea class="form-control" rows="4" cols="30"></textarea>
												</div>
												<div class="form-group">
													<label class="d-block">Status</label>
													<div class="status-toggle">
														<input type="checkbox" id="add_plan_status" class="check">
														<label for="add_plan_status" class="checktoggle">checkbox</label>
													</div>
												</div>
												<div class="m-t-20 text-center">
													<button class="btn btn-primary submit-btn">Submit</button>
												</div>
											</form>
										</div>
									</div>
								</div>
							</div>
							<!-- /Add Plan Modal -->

							<!-- Edit Plan Modal -->
							<div class="modal custom-modal fade" id="edit_plan" role="dialog">
								<div class="modal-dialog modal-md modal-dialog-centered">
									<div class="modal-content">
										<button type="button" class="close" data-dismiss="modal"><i class="fa fa-close"></i></button>
										<div class="modal-body">
											<h5 class="modal-title text-center mb-3">Edit Plan</h5>
											<form id="employee_add" method="post">
												<div class="row">
											<input type="hidden" name="plan_id" id="edit_plan_id">
													<div class="col-md-6">
														<div class="form-group">
															<label>Plan Name</label>
															<input type="text" placeholder="Free Trial" class="form-control" id="edit_plan_name" name="plan_name">
														</div>
													</div>
													<div class="col-md-6">
														<div class="form-group">
															<label>Plan Amount</label>
															<input type="text" class="form-control" name="plan_price" id="edit_plan_price">
														</div>
													</div>
													<div class="col-md-6">
														<div class="form-group">
															<label>Plan Type</label>
															<select class="select" name="plan_type" id="edit_plan_type"> 
																<option value="Monthly"> Monthly </option>
																<option value="Yearly"> Yearly </option>
															</select>
														</div>
													</div>
													<div class="col-md-6">
														<div class="form-group">
															<label>No of Storage Space</label>
															<select class="select" name="plan_storage" id="edit_plan_storage"> 
																<option> 5 GB </option>
																<option> 100 GB </option>
																<option> 500 GB </option>
															</select>
														</div>
													</div>
												</div>
												<div class="form-group">
													<label>Plan Description</label>
													<textarea class="form-control" rows="4" cols="30" name="plan_description" id="edit_plan_description"></textarea>
												</div>
												<!-- <div class="form-group">
													<label class="d-block">Status</label>
													<div class="status-toggle">
														<input type="checkbox" id="edit_plan_status" class="check" name="plan_status">
														<label for="edit_plan_status" class="checktoggle">checkbox</label>
													</div>
												</div> -->
												<div class="m-t-20 text-center">
													<button class="btn btn-primary submit-btn">Save</button>
												</div>
											</form>
										</div>
									</div>
								</div>
							</div>
							<!-- /Edit Plan Modal -->
						  
						</div>
					</div>
					
                </div>
				<!-- /Page Content -->
				
            </div>
			<!-- /Page Wrapper -->
			
        </div>
		<!-- /Main Wrapper -->
		
		<!-- jQuery -->
        <script src="<?php echo base_url(); ?>assets\js\jquery-3.2.1.min.js"></script>
		
      <?php $this->load->view('common_css_js/footer_js');?>
		
    </body>

    <script type="text/javascript">
    
    $(document).on("submit", "#employee_add", function (event) 
	{
		event.preventDefault(); 

        $.ajax({
			                   type: "POST",
			                   url: "<?php echo site_url().'admin_dashboard/update_plan'; ?>",
			                   data: $("#employee_add").serialize(), 
			                   success: function(data)
			                   {
			                        if(data =='1')
			                        {    

			                              swal("Success!", "Employee Details Added Successfully", "success");
			                              $( '#employee_add' ).each(function()
			                              {
			                                this.reset();
			                               $( ".close" ).click();
			                               location.reload();
			                                //$( ".page-title" ).text('ss');

			                             });

			                        }
			                        else
			                        {

			                        	swal("Failed!", "Try Again Later.", "error");
			                              $( '#employee_add' ).each(function()
			                              {
			                                //this.reset();
			                               //$( "#cancel_model" ).click();

			                             });

			                        	

			                        }
			                   }
                });


    });

    $(document).on("click", ".edit_employee_model", function (event) 
    {
    	$('#edit_plan_id').val($(this).data('plan_id'));
    	$('#edit_plan_name').val($(this).data('plan_name'));
    	$('#edit_plan_price').val($(this).data('plan_price'));
    	$('#edit_plan_type').val($(this).data('plan_type'));
    	$('#edit_plan_storage').val($(this).data('plan_storage'));
    	$('#edit_plan_description').val($(this).data('plan_description'));
        $('#edit_plan_status').val($(this).data('plan_status'));
    	
    });

    
    </script>
</html>