<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
        <title>Schedule list </title>

        <?php $this->load->view('common_css_js/css'); ?>
		
    </head>
    <body>
		<!-- Main Wrapper -->
        <div class="main-wrapper">
		
			<!-- Header -->
        <?php $this->load->view('common/set_header'); ?>
			<!-- Header -->
            <?php $this->load->view('common_css_js/side_header'); ?>
			<!-- /Sidebar -->
			
			<!-- Page Wrapper -->
            <div class="page-wrapper">
			
				<!-- Page Content -->
                <div class="content container-fluid">
				
					<!-- Page Header -->
					<div class="page-header">
						<div class="row align-items-center">
							<div class="col">
								<h3 class="page-title">Schedule</h3>
								<ul class="breadcrumb">
									<li class="breadcrumb-item"><a href="<?php echo base_url(); ?>">Dashboard</a></li>
									<li class="breadcrumb-item active">Schedule</li>
								</ul>
							</div>
							</div>
							
						</div>
					</div>
		           <?php echo validation_errors(); ?>
						<div class="row">

						<div class="col-md-8">
							<div class="table-responsive">
					
								<table class="table table-striped table-nowrap custom-table mb-0 datatable">
									<thead>
										<tr>
											<th>Schedule</th>
											<th>Date Added</th>
											<th>Orientation</th>
											<th>Select</th>
										</tr>
									</thead>
								<tbody>
							<?php 
                    		
						 	if(!empty($assets_schedule))
						 	{ 
						 		foreach ($assets_schedule as $clients_value) 
						 		{ 
						 		 $clients_id = $clients_value->id; 
						 		
						 		 $clients_img = base_url().'assets/img/'.$clients_img;
						 	    ?>
						 	    <tr>
						 	    	
						 	        <td>
						 	        <?php  if($clients_value->path_type == 'Image')
        						 		 { ?><img src="<?=$clients_value->app_url; ?>" width="100" height="60" >
        						 		 <?php } else if($clients_value->path_type == 'Video')
        						 		 {?><iframe width="150px" height="100px;" src="<?=$clients_value->app_url; ?>"></iframe>
        						 		 <?php } ?>
						 		    </td>
						 	    	<td>c-<?php echo date('Y-d-F h:i A', strtotime($clients_value->created_at))?></td>
						 	    	<td>Horizontal</td>
						 	    	<td><input type="checkbox" class="select-product" id="check_temp" value="<?php echo $clients_id ?>"></td>
						 	    </tr>
	                        <?php } } ?>
									</tbody>
								</table>
							</div>
						</div>
					
					<div class="col-md-4">
						<form method="post" id="employee_add"  enctype="multipart/form-data">
									<div class="row">

										<div class="col-md-6">
											<input type="hidden" id="start_d" name="comp_id" required>
											<div class="form-group">
												<label class="col-form-label">Start Date</label>
												<input type="text" class="form-control rounded-0" name="start_date" value="<?php echo $this->session->userdata('start_d');?>" readonly >
											</div>
											<div class="form-group">
												<label class="col-form-label">Start Time</label>
												<input type="time" class="form-control rounded-0" name="start_time" required>
											</div>
										</div>
										
										<div class="col-md-6">
											<div class="form-group">
												<label class="col-form-label">End Date</label>
												<input type="date" class="form-control rounded-0" name="end_date">
											</div>
											<div class="form-group">
												<label class="col-form-label">End Time</label>
												<input type="time" class="form-control rounded-0" name="end_time">
											</div>
										</div>

									</div>
									
									<div class="submit-section">
										<button id="display_button" class="btn btn-primary submit-btn">Submit</button>
									</div>
								</form>
					</div>
					</div>
				</div>
                </div>
               

				<!-- /Page Content -->
				
				
            </div>
			<!-- /Page Wrapper -->
			
        </div>
		<!-- /Main Wrapper -->
		
		<!-- jQuery -->
       <?php $this->load->view('common_css_js/footer_js');?>
		<script type="text/javascript">
    

      $(".select-product").change(function() {
    	 var total = [];
        $(":checkbox:checked").each(function(i){
          var temp_display_id = "1";
	      var temp_display_count = $("#check_temp").val();
          var price =$(this).val();
          $("#start_d").val(price);
          total.push(price);
          if (total.length > 1) 
            {

                swal("Failed!", "Please select 1 ", "error");
               $("#display_button").prop("disabled", true);  
            }else{
            	$("#display_button").prop("disabled", false);
            }
           });
        });  
        
    $(document).on("submit", "#employee_add", function (event) 
	{
		 
		 $.ajax({
			                   type: "POST",
			                   url: "<?php echo site_url().'admin_dashboard/assign_schedule'; ?>",
			                   data: $("#employee_add").serialize(), 

			                   success: function(data)
			                   {
                                  
			                        if(data =='1')
			                        {   
			                        	swal("Success!", "Schedule created Successfully", "success");
			                        	  $( '#employee_add' ).each(function()
			                              {
			                                this.reset();
			                               $( ".close" ).click();
			                               
			                             });
			                              window.location.href = "<?php echo site_url().'admin_dashboard/asset_schedule'; ?>";
			                        }
			                        else
			                        {
										swal("Failed!", "Select 1 Composition", "error");
			                              $( '#employee_add' ).each(function()
			                              {
			                                this.reset();
			                               $( ".close" ).click();
			                               location.reload();

			                             });
			                        	 

			                        }
			                   }
                });

    });

   
    
</script>
    </body>
    
</html>