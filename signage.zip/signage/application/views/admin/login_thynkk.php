<!doctype html>
<html lang="en" class="fullscreen-bg">

<head>
	<title>Sign in </title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  
	<!-- VENDOR CSS -->
    <link href="<?php echo base_url(); ?>assets/css/semantic.min.css" rel="stylesheet" type="text/css">
	<link href="<?php echo base_url(); ?>assets/css/auth.css" rel="stylesheet">

</head>

<body>
	<!-- WRAPPER -->
	<div id="wrapper">
		
		<div class="vertical-align-wrap">
			<div class="vertical-align-middle">
			    <div class="logo align-center"><img src="<?php echo base_url(); ?>assets/img/logo.svg" width="200">
			    </div>
				<div class="auth-box" style="background: #000;">
					<div class="content">
						<div class="header">
							<p class="lead">Sign in to your account</p>
						</div>
						<form class="form-auth-small ui form" action="<?php echo base_url(); ?>login" method="POST">
                       		<input type="hidden" name="_token" value="BZ49a6p5cZ2qWkfZ3TBVTyei7oDEuwCJuiC5Kn7Y">
							
							<div class="fields">
								<div class="sixteen wide field ">
									<label for="email" class="color-white">Email</label>
									<input id="email" type="email" class="" name="email" value="" placeholder="Your e-mail address" required autofocus>

										
								</div>
							</div>
							<div class="fields">
								<div class="sixteen wide field ">
									<label for="password" class="color-white">Password</label>
                                	<input id="password" type="password" class="" name="password" placeholder="Your password" required>

                                									</div>
							</div>
							<div class="fields">
								<div class="sixteen wide field">
									<div class="ui checkbox">
										<input type="checkbox" name="remember" >
										<label class="color-white">Remember me</label>
									</div>
								</div>
							</div>

							<button type="submit" class="ui green button large fluid cs-btn" style="background-color: #484848;">SIGN IN</button>
						</form>
		
						<?php if($msg = $this->session->flashdata('flash_message')) { echo $msg; } ?>
					</div>
				</div>
			</div>
		</div>

		
	</div>
	<!-- END WRAPPER -->

	<!--   Core JS Files   -->
    <script src="https://sirisigns.xyz/signage/assets/vendor/jquery/jquery-3.3.1.min.js"></script>
    <script src="https://sirisigns.xyz/signage/assets/vendor/semantic-ui/semantic.min.js"></script>
	<script>
		$('.ui.checkbox').checkbox('uncheck', 'toggle');
	</script>
</body>

<script>'undefined'=== typeof _trfq || (window._trfq = []);'undefined'=== typeof _trfd && (window._trfd=[]),_trfd.push({'tccl.baseHost':'secureserver.net'}),_trfd.push({'ap':'cpsh'},{'server':'sg3plcpnl0080'}) // Monitoring performance to make your website faster. If you want to opt-out, please contact web hosting support.</script><script src='https://img1.wsimg.com/tcc/tcc_l.combined.1.0.6.min.js'></script></html>
