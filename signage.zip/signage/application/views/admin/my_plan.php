﻿<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
        <title>My Plan</title>
		
		<!-- Favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url(); ?>assets\img\faviconbg.png">
		
		<!-- Bootstrap CSS -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets\css\bootstrap.min.css">
		
		<!-- Fontawesome CSS -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets\css\font-awesome.min.css">
		
		<!-- Lineawesome CSS -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets\css\line-awesome.min.css">
		
		<!-- Select2 CSS -->
		<link rel="stylesheet" href="<?php echo base_url(); ?>assets\css\select2.min.css">
		
		<!-- Main CSS -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets\css\style.css">
		
		<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!--[if lt IE 9]>
			<script src="<?php echo base_url(); ?>assets/js/html5shiv.min.js"></script>
			<script src="<?php echo base_url(); ?>assets/js/respond.min.js"></script>
		<![endif]-->
    </head>
    <body>
		<!-- Main Wrapper -->
        <div class="main-wrapper">
		
			<!-- Header -->
            <?php $this->load->view('common/set_header'); ?>
			<!-- Header -->
            <?php $this->load->view('common_css_js/side_header'); ?>
			<!-- /Sidebar -->
			
			<!-- Page Wrapper -->
            <div class="page-wrapper">
			
				<!-- Page Content -->
                <div class="content container-fluid">
				
					<!-- Page Header -->
					<div class="page-header">
						<div class="row align-items-center">
							<div class="col">
								<h3 class="page-title">My Plan</h3>
								<ul class="breadcrumb">
									<li class="breadcrumb-item"><a href="<?php echo base_url(); ?>">Dashboard</a></li>
									<li class="breadcrumb-item active">My Plan</li>
								</ul>
							</div>
							
						</div>
					</div>
					<!-- /Page Header -->
					
					<div class="row">
						<div class="col-md-12">
							<div class="table-responsive">
								<table class="table table-striped custom-table mb-0">
									<thead>
										<tr>
											<th><h3>Plan Status</h3></th>
											<th></th>
											<th></th>
										</tr>
										<tr>
											<th>Trial started </th>
											<th>Trial ends</th>
											<th>Trial period remaining</th>
											
										</tr>
									</thead>
									<tbody>
										<tr>
											<td>2021-01-05</td>
											<td>2021-01-20</td>
											<td>
												12 
											</td>
											
										</tr>
										
									</tbody>
								</table>
							</div>
						</div>
					</div>
                     
                    &nbsp;
                    <div class="row">
						<div class="col-md-12">
							<div class="table-responsive">
								<table class="table table-striped custom-table mb-0">
									<thead>
										<tr>
											<th>Plan name</th>
											<th>Subscription charge per display</th>
											<th>Total displays</th>
											<th>Estimated monthly charge</th>
											<th>Action</th>
										</tr>
									</thead>
									<tbody>
										<tr>
											<td>Standard Monthly Subscription</td>
											<td>Rs.900</td>
											<td>
												 	0 
											</td>
											<td>Rs.0</td>
											<td><div class="submit-section">
										<button class="btn btn-primary submit-btn">Upgrade</button>
									</div></td>
										</tr>
										
									</tbody>
								</table>
							</div>
						</div>
					</div>
                    <!-- /Page Header -->

                </div>
				<!-- /Page Content -->
				
			
			  <div class="container-fluid">
			  	<p>Note :
      <ul><li>
    Total monthly charges will depend on number of displays on the billing date.</li><li>
    Billing cycle will be as per the activation date (the day on which you have upgraded) and should be paid within 15 days of invoice generation</li><li>
    Non Payment of invoice will lead to de-activation of the account.</li><li>
    To re-activate the account and for any issues please contact us at contact@sirisigns.xyz</li></ul></p>
			  </div>
				
				
            </div>
			<!-- /Page Wrapper -->

        </div>
		<!-- /Main Wrapper -->

		<!-- jQuery -->
        <script src="<?php echo base_url(); ?>assets\js\jquery-3.2.1.min.js"></script>

		<!-- Bootstrap Core JS -->
        <script src="<?php echo base_url(); ?>assets\js\popper.min.js"></script>
        <script src="<?php echo base_url(); ?>assets\js\bootstrap.min.js"></script>

		<!-- Slimscroll JS -->
		<script src="<?php echo base_url(); ?>assets\js\jquery.slimscroll.min.js"></script>
		
		<!-- Select2 JS -->
		<script src="<?php echo base_url(); ?>assets\js\select2.min.js"></script>

		<!-- Custom JS -->
		<script src="<?php echo base_url(); ?>assets\js\app.js"></script>

    </body>
</html>