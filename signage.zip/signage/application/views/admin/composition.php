<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
       
        <title>Composition</title>
        <link href="<?php echo base_url(); ?>assets/plugins/calendar/dist/fullcalendar.css" rel="stylesheet" />
		
		<?php $this->load->view('common_css_js/css'); ?>
		<style>
video {
  max-width: 100%;
  height: auto;
}

#example tr:hover {
    background-color: #ccc;
}
#example td:hover {
    cursor: pointer;
}
</style>
    </head>
    <body>
		<!-- Main Wrapper -->
        <div class="main-wrapper">
		
			<!-- Header -->
            <?php $this->load->view('common/set_header'); ?>
			<!-- Header -->
            <?php $this->load->view('common_css_js/side_header'); ?>
			<!-- /Sidebar -->
			<!-- /Sidebar -->
			
			<!-- Page Wrapper -->
            <div class="page-wrapper">
			
				<!-- Page Content -->
                <div class="content container-fluid">
				
					<div class="page-header">
						<div class="row align-items-center">
							<div class="col">
								<h3 class="page-title">Composition</h3>
								<ul class="breadcrumb">
									<li class="breadcrumb-item"><a href="<?php echo base_url(); ?>">Admin</a></li>
									<li class="breadcrumb-item active">Composition</li>
								</ul>
							</div>
							<div class="col-auto float-right ml-auto">
						 <?php if($this->session->userdata('mob_reg_code_status') == 1 || $this->session->userdata('user_role') == 1){ ?>		
										
							<a href="<?php echo base_url(); ?>admin_dashboard/create_composition" class="btn add-btn"><i class="fa fa-plus"></i>Create Composition</a>
					    <?php }else{?>
                          <p>Please submit your registration code before create assets...</p>
					    <?php }?>			 
							</div>
							
						</div>
					</div>
				

					<div class="row">
						<div class="col-md-12">
							<div class="table-responsive">
								<table class="table table-striped table-nowrap custom-table mb-0 datatable" id="example">
									<thead>
										<tr>
										    <th>Composition</th>
											<th>Content Name</th>
											<th>Aspect Ratio</th>
											<th>Creation Date</th>
											<th>Action</th>
										</tr>
									</thead>
									<tbody>
							<?php 
                            if($this->session->userdata('user_role') == 1)
                            {
                              $clients = $this->nlp_model->select('assets_schedule',array('comp_id !='=>''));
                            }else{
                            $clients = $this->nlp_model->select('assets_schedule',array('user_id'=>$this->session->userdata('user_id'),'comp_id !='=>''));
                            }
                    		$modal = '';
						 	if(!empty($clients))
						 	{ 
						 		foreach ($clients->result() as $clients_value) 
						 		{ 
						 		 $clients_id = $clients_value->id; 
						 		 
						 		 $clients_img = base_url().'assets/img/'.$clients_img;
						 	    ?>
						 	    <tr><td>

	<?php  
	if($clients_value->template == 'temp_1')
    {

    ?>
      <div class="row">
	        <?php

	        $comp = json_decode($clients_value->comp_id,true);
	                                     
	         foreach($comp as  $r)
	         {
	        						 	 
	         $select = $this->nlp_model->select('assets_apps',array('id'=>$r))->row();
	        						 	
	        ?>
	            <div class="col-md-2">
		     
					<?php
					if($select->path_type != 'Video')
					{ ?>
		            <img src="<?php echo $select->app_url ?>" width="100" height="50">
		     		<?php }else{ ?>
			    	<iframe type="text/html" width="100" height="50" src="http://www.youtube.com/embed/M7lc1UVf-VE?autoplay=1&origin='<?php echo $select->app_url ?>'"></iframe>
			    	<?php
			          }?>
			    </div>      
	   <?php  }?>
	   </div>     
<?php }elseif ($clients_value->template == 'temp_2') 
{ ?>
	<div class="row">
	        <?php

	        $comp = json_decode($clients_value->comp_id,true);
	                                     
	         foreach($comp as  $r)
	         {
	        						 	 
	         $select = $this->nlp_model->select('assets_apps',array('id'=>$r))->row();
	        						 	
	        ?>
	            <div class="col-md-2">
		     
					<?php
					if($select->path_type != 'Video')
					{ ?>
		            <img src="<?php echo $select->app_url ?>" width="50" height="50">
		     		<?php }else{ ?>
			    	<iframe type="text/html" width="50" height="50" src="http://www.youtube.com/embed/M7lc1UVf-VE?autoplay=1&origin='<?php echo $select->app_url ?>'"></iframe>
			    	<?php
			          }?>
			    </div>      
	   <?php  }?>
	   </div>
<?php }elseif($clients_value->template == 'temp_3') {?>
<div class="row">
	        <?php

	        $comp = json_decode($clients_value->comp_id,true);
	                                     
	         foreach($comp as  $r)
	         {
	        						 	 
	         $select = $this->nlp_model->select('assets_apps',array('id'=>$r))->row();
	        						 	
	        ?>
	            <div class="col-md-6">
		     
					<?php
					if($select->path_type != 'Video')
					{ ?>
		            <img src="<?php echo $select->app_url ?>" width="50" height="50">
		     		<?php }else{ ?>
			    	<iframe type="text/html" width="50" height="50" src="http://www.youtube.com/embed/M7lc1UVf-VE?autoplay=1&origin='<?php echo $select->app_url ?>'"></iframe>
			    	<?php
			          }?>
			    </div>      
	   <?php  }?>
	   </div>
<?php }elseif($clients_value->template == 'temp_4') 
{?>
	<div class="row">
	        <?php

	        $comp = json_decode($clients_value->comp_id,true);
	                                     
	         foreach($comp as  $r)
	         {
	        						 	 
	         $select = $this->nlp_model->select('assets_apps',array('id'=>$r))->row();
	        						 	
	        ?>
	            <div class="col-md-12">
		     
					<?php
					if($select->path_type != 'Video')
					{ ?>
		            <img src="<?php echo $select->app_url ?>" width="50" height="50">
		     		<?php }else{ ?>
			    	<iframe type="text/html" width="50" height="50" src="http://www.youtube.com/embed/M7lc1UVf-VE?autoplay=1&origin='<?php echo $select->app_url ?>'"></iframe>
			    	<?php
			          }?>
			    </div>      
	   <?php  }?>
	   </div>
<?php  }else{
	?>
	<div class="row">
	        <?php

	        $comp = json_decode($clients_value->comp_id,true);
	                                     
	         foreach($comp as  $r)
	         {
	        						 	 
	         $select = $this->nlp_model->select('assets_apps',array('id'=>$r))->row();
	        						 	
	        ?>
	            <div class="col-md-12">
		     
					<?php
					if($select->path_type != 'Video')
					{ ?>
		            <img src="<?php echo $select->app_url ?>" width="50" height="50">
		     		<?php }else{ ?>
			    	<iframe type="text/html" width="50" height="50" src="http://www.youtube.com/embed/M7lc1UVf-VE?autoplay=1&origin='<?php echo $select->app_url ?>'"></iframe>
			    	<?php
			          }?>
			    </div>      
	   <?php  }?>
	   </div>
<?php }  ?>
            		 		    </td>

						 	    	<td><a href="<?=$clients_id?>"></a>c-<?php echo date('Y-d-F h:i A', strtotime($clients_value->created_at))?></td>
						 	    	<td>Horizontal</td>
						 	    	<td><?=$clients_value->created_at?></td>
						 	    	 <td class="text-right">
	                                    <div class="dropdown dropdown-action">
										<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>
											<div class="dropdown-menu dropdown-menu-right"> 
													
			                                 <a class="dropdown-item" onclick="lead_function(<?php echo $clients_id ?>);" href="javascript::void(0);"  data-toggle="modal" data-target="#asset_tags"><i class="fa fa-tasks m-r-5"></i> Add tag</a>
											<a class="dropdown-item delete_client_model" data-user_id="<?php echo $clients_id; ?>" href="javascript::void(0);" data-toggle="modal" data-target="#delete_client"><i class="fa fa-trash-o m-r-5"></i> Delete</a>			
													</div>
												</div>
	                                                 </td>
						 	    </tr>
	                        <?php } } ?>
									</tbody>
								</table>
							</div>
						</div>
						
					</div>
								<!-- Add Client Modal -->
				<div id="asset_tags" class="modal custom-modal fade" role="dialog">
					<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
						<div class="modal-content">
							<div class="modal-header">
								<h5 class="modal-title">Add Tag</h5>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>
							<div class="modal-body row">
								<div class="col-md-6">
								<form method="post" id="assets_ajax" action="<?php echo site_url().'admin_dashboard/asset_tag'; ?>" enctype="multipart/form-data">
									<div class="row"> 
			                           <input type="hidden" name="asset_id" id="asset_id">
										<div class="col-md-10">
											<div class="form-group">
												<label class="col-form-label">Key</label>
												<input type="text" class="form-control rounded-0" name="asset_key">
											</div>
											<div class="form-group">
												<label class="col-form-label">Value</label>
												<input type="text" class="form-control rounded-0" name="asset_value">
											</div>
										</div>

									</div>
									
									<div class="submit-section">
										<button class="btn btn-primary submit-btn">Submit</button>
									</div>
								</form>
							   </div>
							   <div class="col-md-6">
							   	<p style="text-align: center;">* Avoid adding standard keys (ex: name ,options, etc)</p>
      							<table class="table dataTables mb-0">
	                                <thead>
	                                    <tr>
	                                     <th>#</th>
	                                     <th style="color:blue;font-size: 18px;">Key</th>
	                                     <th style="color:blue;font-size: 18px;">Value</th>
	                                   </tr>
		                                   </thead>
		                                    <tbody>
	                        <?php 
                            
                            $user_id = $this->session->userdata('user_id');
                            $tag_result = $this->nlp_model->select('assets_tags',array('user_id'=>$user_id));
                    		
                    		$i=1;
						 	if(!empty($tag_result))
						 	{ 
						 		foreach ($tag_result->result() as $tag) 
						 		{ 
						 		 $asset_key   = $tag->asset_key;	
						 		 $asset_value = $tag->asset_value;	
						 	    ?>
						 	    <tr>
						 	    	<td><?=$i?></td>
						 	    	<td><?=$asset_key?></td>
						 	    	<td><?=$asset_value?></td>
						 	    </tr>
						 	<?php $i++;}  }?>
	                                                </tbody>
	                                                </table>
							   </div>
							</div>
						</div>
					</div>
				</div>
				<!-- /Add Client Modal -->

				 <!-- Delete Client Modal -->
				<div class="modal custom-modal fade" id="delete_client" role="dialog">
					<div class="modal-dialog modal-dialog-centered">
						<div class="modal-content">
							<div class="modal-body">
								<div class="form-header">
									<h3>Delete Asset</h3>
									<p>Are you sure want to delete?</p>
								</div>
								<div class="modal-btn delete-action">
									<div class="row">
										<div class="col-6">
											<a id="comform_delete" href="javascript:void(0);" class="btn btn-primary continue-btn" data-user_id="">Delete</a>
										</div>
										<div class="col-6">
											<a href="javascript:void(0);" data-dismiss="modal" class="btn btn-primary cancel-btn">Cancel</a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- /Delete Client Modal -->
                
                </div>
				<!-- /Page Content -->
				
            </div>
			<!-- /Page Wrapper -->

			 

        </div>
		<!-- /Main Wrapper -->
		<!-- jQuery -->
      <?php $this->load->view('common_css_js/footer_js');?>
  	 
		
    </body>
     <script src="<?php echo base_url(); ?>assets\js\jquery-3.2.1.min.js"></script>
     <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
   	<script type="text/javascript">
        

        function lead_function($id)
		{
			$("#asset_id").val($id);
		}
         

        function delete_function($id)
		{
			$("#delete_id").val($id);
		}   

        $(document).ready(function() {

		    $('#example tr').click(function() {
		        var id = $(this).find("a").attr("href");
		        // alert(id);
		        if(id) {
		            $.ajax({
					            type: "POST",
					            
					            url: "<?php echo site_url().'admin_dashboard/composition_ajax'; ?>",
					            
					            data: {id:id},
					             success: function(data)
					            {    
				                   

					                $("#composition_ajax_div").html(data);
					            }
		                  }); 
			        }
			    });

			});

            
             $(document).on("click", ".delete_client_model", function (event) 
    		{

   	 			$("#comform_delete").attr('data-user_id', $(this).data('user_id'));
    
    		});

    		$(document).on("click", "#comform_delete", function () 
			{
					
					
			    $.ajax({
						    type: "POST",
						    
						    url: "<?php echo site_url().'admin_dashboard/ajax_delete_composition'; ?>",
						    
						    data: {'id':$(this).data('user_id')}, 
						    
						    success: function(data)
						    {    
						        if(data =='1')
						        {    
						           Swal.fire("Success!", "Assets Details Deleted Successfully","success").then( () => {
                                    
                                         location.reload(); });
						                              
						        }
						        else
						        {

						            Swal("Failed!", "Try Again Later.", "error");
						                           
						        }
						    }
			            });


			});

        </script>

</html>