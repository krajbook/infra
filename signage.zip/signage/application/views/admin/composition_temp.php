﻿<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
       
        <title>Composition</title>
        <link href="<?php echo base_url(); ?>assets/plugins/calendar/dist/fullcalendar.css" rel="stylesheet" />
		
		<?php $this->load->view('common_css_js/css'); ?>
		<style>
video {
  max-width: 100%;
  height: auto;
}

#example tr:hover {
    background-color: #ccc;
}
#example td:hover {
    cursor: pointer;
}
</style>
    </head>
    <body>
		<!-- Main Wrapper -->
        <div class="main-wrapper">
		
			<!-- Header -->
            <?php $this->load->view('common/set_header'); ?>
			<!-- Header -->
            <?php $this->load->view('common_css_js/side_header'); ?>
			<!-- /Sidebar -->
			<!-- /Sidebar -->
			
			<!-- Page Wrapper -->
            <div class="page-wrapper">
			
				<!-- Page Content -->
                <div class="content container-fluid">
				
					<div class="page-header">
						<div class="row">
					        <div class="col-md-6">
					     		<div id="template_table"></div>
					
							</div>
							<div class="col-md-6">
								<h3 class="page-title">Create</h3>
								<ul class="breadcrumb">
									<li class="breadcrumb-item"><a href="<?php echo base_url(); ?>">Admin</a></li>
									<li class="breadcrumb-item active">Composition</li>
								</ul>
								<div class="table-responsive">
								<table class="table table-striped table-nowrap custom-table mb-0 datatable" id="example">
									<thead>
										<tr>
											<th>Select</th>
										    <th>Composition</th>
											<th>Content Name</th>
											<th>Action</th>
										</tr>
									</thead>
									<tbody>
							<?php
							if($this->session->userdata('user_role') == 1)
                            {
                             
                            $this->session->userdata('template');
                            $clients = $this->nlp_model->select('assets_apps');
                    		}else{
                    			$clients = $this->nlp_model->select('assets_apps',array('user_id'=>$this->session->userdata('user_id')));
                    		}				  
						 	if(!empty($clients))
						 	{ 
						 		foreach ($clients->result() as $clients_value) 
						 		{ 
						 		 $clients_id = $clients_value->id; 
						 		
						 		 $clients_img = base_url().'assets/img/'.$clients_img;
						 	    ?>
						 	    
						 	    <tr>
						 	    <td><input type="checkbox" class="select-product" value="<?php echo $clients_id ?>"></td> 
						 	   	<td>
						 	    
						 	        <?php  if($clients_value->path_type == 'Image')
        						 		 { ?><img src="<?=$clients_value->app_url; ?>" width="100" height="60" >
        						 		 <?php } else if($clients_value->path_type == 'Video')
        						 		 {?><iframe width="150px" height="100px;" src="<?=$clients_value->app_url; ?>"></iframe>
        						 		 <?php } ?>
						 		    
						 	   </td>
						 	    	<td><a onclick="check_demo(<?php echo $clients_id ?>)">c-<?php echo date('Y-d-F h:i A', strtotime($clients_value->created_at))?></a></td>
						 	    	 <td class="text-right">
	                                    <div class="dropdown dropdown-action">
										<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>
											<div class="dropdown-menu dropdown-menu-right"> 
													
											<a data-client_id="<?= $clients_id?>" 
			                                    class="dropdown-item delete_client_model" href="javascript::void(0);" data-toggle="modal" data-target="#delete_client"><i class="fa fa-trash-o m-r-5"></i> Delete</a>			
													</div>
												</div>
	                                                 </td>
						 	    </tr>
	                        <?php } } ?>
									</tbody>
								</table>
							</div>
							</div>
					
						</div>
					</div>
				
                </div>
				<!-- /Page Content -->
				
            </div>
			<!-- /Page Wrapper -->

		  </div>
          
				<!-- Template 2 Modal -->
				<div id="preview_template_multiple" class="modal custom-modal fade" role="dialog">
					<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
						<div class="modal-content">
						    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>&nbsp;
								<div id="response_template_file_path"></div>
					    </div>
					</div>
				</div>
				
				<!-- /Template 2 Modal -->
				
        <!-- </div> -->
		<!-- /Main Wrapper -->
		<!-- jQuery -->
      <?php $this->load->view('common_css_js/footer_js');?>
  	 
		
    </body>

     <script src="<?php echo base_url(); ?>assets\js\jquery-3.2.1.min.js"></script>
     <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
   	<script type="text/javascript">
    
    function display_temp()
    {   
    	
		 var temp_id = [];
        $(":checkbox:checked").each(function(i){
          
          var temp_val =$(this).val();
          temp_id.push(temp_val);
           
        });

    	var display_id = $("#display_id").val();
    	var display_count = $("#display_count").val();
    	if(display_count != display_id)
    	{
    		alert('please select only ' + display_id + ' checkbox !');
    		$("#display_button").prop("disabled", true);
    	}else{

    		$("#display_button").prop("disabled", false);
    		$.ajax({
					            type: "POST",
					            
					            url: "<?php echo site_url().'admin_dashboard/preview_composition'; ?>",
					            
					            data: {id:temp_id},
					             success: function(data)
					            {    
                                  // alert(data);
					                $("#response_template_file_path").html(data);
					            }
		                  });
    		
									$("#preview_template_multiple").modal("show");
    	}
    }


    $(".select-product").change(function() {
    	 var total = [];
        $(":checkbox:checked").each(function(i){
          
          var price =$(this).val();
          total.push(price);
           
        });  
        // alert();
             $.ajax({
					            type: "POST",
					            
					            url: "<?php echo site_url().'admin_dashboard/template_table'; ?>",
					            
					            data: {id:total},
					             success: function(data)
					            {    
                                  // alert(data);
					                $("#template_table").html(data);
					            }
		                  });
	    });


         $(document).on("submit", "#formcomposition", function (event) 
    	{
			var temp_display_id = $("#display_id").val();
	    	var temp_display_count = $("#display_count").val();
	    	
	    	if(temp_display_count == temp_display_id)
	    	{
				 var total = [];
		        $(":checkbox:checked").each(function(i){
		          
		          var price =$(this).val();
		          total.push(price);
		           
		        });  

                   $.ajax({

			                   type: "POST",
			                   url: "<?php echo site_url().'admin_dashboard/composition_array_create'; ?>",
			                   data: {comp_id:total},

			                   success: function(data)
			                   {

			                    if(data == "1")
			                    {
			                    	alert('Success !');
			                    	window.location.href = "<?php echo site_url().'admin_dashboard/composition'; ?>";
			                    }else{
			                    	alert('Fail Try again later !');
			                    }

			                   }
                         });
        }else{
        	alert('Check your Selected assets count');
        }

    });


        </script>

</html>