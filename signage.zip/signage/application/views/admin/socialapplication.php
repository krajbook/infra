<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
       
        <title>Apps</title>
		
		<?php $this->load->view('common_css_js/css'); ?>

		<style>
			
			#example img:hover {
			    background-color: #ccc;
			}
			#example img:hover {
			    cursor: pointer;
			}
			.container {
			  padding: 5px 16px;
			}
</style>
    </head>
    <body>
		<!-- Main Wrapper -->
        <div class="main-wrapper">
		
			<?php $this->load->view('common/set_header'); ?>
			<!-- Header -->
            <?php $this->load->view('common_css_js/side_header'); ?>
			<!-- /Sidebar -->
			
			<!-- Page Wrapper -->
            <div class="page-wrapper">
				
				<!-- Page Content -->
                <div class="content container-fluid">
				
					<!-- Page Header -->
					<div class="page-header">
						<div class="row align-items-center">
							<div class="col">
								<h3 class="page-title">Apps</h3>
								<ul class="breadcrumb">
									<li class="breadcrumb-item"><a href="<?php echo base_url(); ?>">Dashboard</a></li>
									<li class="breadcrumb-item active">Apps</li>
								</ul>
							</div>
							<div class="col-auto float-right ml-auto">
								<a href="#" class="btn add-btn" data-toggle="modal" data-target="#add_asset">Custom App</a>
								
							</div>
						</div>
					</div>
					<!-- /Page Header -->
                 <div class="row">
                 	<div class="col-md-3">
					
						<img src="<?php echo base_url(); ?>assets\img\youtube.png" style="width:100%" data-toggle="modal" data-target="#social_youtube" id="example">
					 
					  <div class="container">
					    <h4><b>Youtube</b><i style="padding-left: 100px" class="la la-rocket"></i></h4> 
					  </div>
					
				</div>
                    <div class="col-md-3">
						<img src="<?php echo base_url(); ?>assets\img\facebook.jpg" style="width:100%" data-toggle="modal" data-target="#social_facebook" >
					 
					  <div class="container">
					    <h4><b>Facebook</b><i style="padding-left: 100px" class="la la-rocket"></i></h4> 
					  </div>
					</div>
				

				<div class="col-md-3">
				    <img src="<?php echo base_url(); ?>assets\img\insta.png" style="width:100%" data-toggle="modal" data-target="#social_instagram">
					 
					  <div class="container">
					    <h4><b>Instagram</b><i style="padding-left: 100px" class="la la-rocket"></i></h4> 
					  </div>
					
				</div>

				<div class="col-md-3">
				
						<img src="<?php echo base_url(); ?>assets\img\twitter.jpg" style="width:100%" data-toggle="modal" data-target="#social_twitter">
					 
					  <div class="container">
					    <h4><b>Twitter</b><i style="padding-left: 100px" class="la la-rocket"></i></h4> 
					  </div>
				
				</div>

                  </div>
                  <!-- page header end -->

                  <!-- row 2 -->

                   <div class="row">
                 	<div class="col-md-3">
					
						<img src="<?php echo base_url(); ?>assets\img\html5-3.png" style="width:100%" data-toggle="modal" data-target="#social_html5">
					 
					  <div class="container">
					    <h4><b>URL</b><i style="padding-left: 100px" class="la la-rocket"></i></h4> 
					  </div>
					
				</div>
                    <div class="col-md-3">
					
					</div>
				

				<div class="col-md-3">
				  
					
				</div>

				<div class="col-md-3">
				
				
				</div>

                  </div>
                  <!-- row 2 end -->
					
				     <!-- Add Asset Modal -->
				<div id="add_asset" class="modal custom-modal fade" role="dialog">
					<div class="modal-dialog modal-md" role="document">
						<div class="modal-content">
							<div class="modal-header">
								<h5 class="modal-title">Custom App</h5>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>
							<div class="modal-body">
								<form>
									<div class="row">
										<div class="col-md-12">
											<div class="form-group" align="center">
												<img src="<?php echo base_url(); ?>assets\img\requirements.svg">
											</div>
										</div>
								
												
										<div class="col-md-12">
											<div class="form-group">
												<p style="text-align: center">Write to us, If you have a unique requirement and would like to have a customized app with specific screen design/business flow or integration with other apps. Provide the details below and submit. </p>
												<label>Description*</label>
												<textarea class="form-control"></textarea>
											</div>
										</div>
									</div>
									
									<div class="submit-section">
										<button class="btn btn-primary submit-btn">Submit Request</button>
									</div>
								</form>

							</div>
						  </div>
						</div>
					</div>
				</div>
				<!-- /Add Asset Modal -->

			    <!-- Add social Modal -->
				<div id="social_youtube" class="modal custom-modal fade" role="dialog">
					<div class="modal-dialog modal-md" role="document">
						<div class="modal-content">
							<div class="modal-header">
								<h5 class="modal-title">YouTube Video App</h5>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>
							<div class="modal-body">
								<form method="post" id="add_youtube_form" enctype="multipart/form-data">
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<label class="col-form-label">Name <span class="text-danger">*</span></label>
												<input class="form-control" type="text" name="app_name" id="app_name" required placeholder="App Name">
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label class="col-form-label">Video URL</label>
												<input class="form-control" type="text" name="app_url" id="app_url" placeholder="https://www.youtube.com/watch?v=qHX7kKWyX">
											</div>
										</div>
									</div>
										<div class="row">
										    <!-- <input type="text" id="previewImg"> -->
										    <div id="previewImg">
										    </div>
										</div>
									<div class="row submit-section">
									
										<div class="col-4">
											<button class="btn btn-primary submit-btn">Add</button>
										</div>
										<div class="col-2">
										</div>
										<div class="col-4">
										<a href="#" class="btn btn-primary cancel-btn" id="myBtn">Preview</a>
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
				<!-- /Add social Modal -->

				<!-- Add social Modal -->
				<div id="social_facebook" class="modal custom-modal fade" role="dialog">
					<div class="modal-dialog modal-md" role="document">
						<div class="modal-content">
							<div class="modal-header">
								<h5 class="modal-title">Configure Facebook Posts App</h5>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>
							<div class="modal-body">
								<form method="post" id="add_facebook_form" enctype="multipart/form-data">
									<div class="row">
										<div class="col-md-12">
											<div class="form-group">
												<label class="col-form-label">Name <span class="text-danger">*</span></label>
												<input class="form-control" type="text" name="app_name" id="app_name" required placeholder="App Name">
											</div>
										</div>
										<div class="col-md-12">
											<div class="form-group">
												<label class="col-form-label">No of Post</label>
												<input class="form-control" type="text" name="no_of_post" id="no_of_post" placeholder="30">
											</div>
										</div>
										<div class="col-md-12">
											<div class="form-group">
												<label class="col-form-label">Slide Duration(in seconds)</label>
												<input class="form-control" type="text" name="slide_duration" id="slide_duration" placeholder="00:00:30">
											</div>
										</div>
										
									</div>
									
									<div class="row submit-section">
										
										<div class="col-4">
											<button class="btn btn-primary submit-btn">Add</button>
										</div>
										<div class="col-2">
										</div>
										<div class="col-4">
											<a href="javascript:void(0);" data-dismiss="modal" class="btn btn-primary cancel-btn">Preview</a>
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
				<!-- /Add social Modal -->

				<!-- Add social Modal -->
				<div id="social_instagram" class="modal custom-modal fade" role="dialog">
					<div class="modal-dialog modal-md" role="document">
						<div class="modal-content">
							<div class="modal-header">
								<h5 class="modal-title">Configure Instagram Posts App</h5>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>
							<div class="modal-body">
								<form method="post" id="add_instagram_form" enctype="multipart/form-data">
									<div class="row">
										<div class="col-md-12">
											<div class="form-group">
												<label class="col-form-label">Name <span class="text-danger">*</span></label>
												<input class="form-control" type="text" name="app_name" id="app_name" required placeholder="App Name">
											</div>
										</div>
										<div class="col-md-12">
											<div class="form-group">
												<label class="col-form-label">No of Post</label>
												<input class="form-control" type="text" name="no_of_post" id="no_of_post" placeholder="30">
											</div>
										</div>
										<div class="col-md-12">
											<div class="form-group">
												<label class="col-form-label">Slide Duration(in seconds)</label>
												<input class="form-control" type="text" name="slide_duration" id="slide_duration" placeholder="00:00:30">
											</div>
										</div>
										
									</div>
									
									<div class="row submit-section">
										
										<div class="col-4">
											<button class="btn btn-primary submit-btn">Add</button>
										</div>
										<div class="col-2">
										</div>
										<div class="col-4">
											<a href="javascript:void(0);" data-dismiss="modal" class="btn btn-primary cancel-btn">Preview</a>
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
				<!-- /Add social Modal -->

				<!-- Add social Modal -->
				<div id="social_twitter" class="modal custom-modal fade" role="dialog">
					<div class="modal-dialog modal-md" role="document">
						<div class="modal-content">
							<div class="modal-header">
								<h5 class="modal-title">Configure Twitter Tweets App</h5>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>
							<div class="modal-body">
								<form method="post" id="add_twitter_form" enctype="multipart/form-data">
									<div class="row">
										<div class="col-md-12">
											<div class="form-group">
												<label class="col-form-label">Name <span class="text-danger">*</span></label>
												<input class="form-control" type="text" name="app_name" id="social_name" required placeholder="App Name">
											</div>
										</div>
										
									</div>
									
									<div class="row submit-section">
										
										<div class="col-4">
											<button class="btn btn-primary submit-btn">Add</button>
										</div>
										<div class="col-2">
										</div>
										<div class="col-4">
											<a href="javascript:void(0);" data-dismiss="modal" class="btn btn-primary cancel-btn">Preview</a>
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
				<!-- /Add social Modal -->


				<!-- Add social Modal -->
				<div id="social_html5" class="modal custom-modal fade" role="dialog">
					<div class="modal-dialog modal-md" role="document">
						<div class="modal-content">
							<div class="modal-header">
								<h5 class="modal-title">Configure URL App</h5>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>
							<div class="modal-body">
								<form method="post" id="add_html_form" enctype="multipart/form-data">
									<div class="row">
										<div class="col-md-12">
											<div class="form-group">
												<label class="col-form-label">Name <span class="text-danger">*</span></label>
												<input class="form-control" type="text" name="app_name" id="app_name" required placeholder="App Name">
											</div>
										</div>
										<div class="col-md-12">
											<div class="form-group">
												<label class="col-form-label">URL</label>
												<input class="form-control" type="text" name="app_url" id="app_url" placeholder="https://www.abcd.com">
											</div>
										</div>
										<div class="col-md-12">
											<div class="form-group">
												<label class="col-form-label">Cache</label>
												<select class="form-control" name="cache" id="cache">
													<option value="1">Enable</option>
													<option value="2">Disable</option>
												</select>
											</div>
										</div>
										
									</div>
									
									<div class="row submit-section">
										
										<div class="col-4">
											<button class="btn btn-primary submit-btn">Add</button>
										</div>
										<div class="col-2">
										</div>
										<div class="col-4">
											<a href="javascript:void(0);" data-dismiss="modal" class="btn btn-primary cancel-btn">Preview</a>
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
				<!-- /Add social Modal -->
				
				<!-- /Page Content -->

				
				
            </div>
			<!-- /Page Wrapper -->

        </div>
		<!-- /Main Wrapper -->

		<!-- jQuery -->
     <?php $this->load->view('common_css_js/footer_js');?>

		
    </body>
    <script type="text/javascript">
    
    $(document).ready(function(){
    // Get value on button click and show alert
    $("#myBtn").click(function(){
        var str = $("#app_url").val();
        var html = "<iframe type='text/html' width='700' height='345' src='http://www.youtube.com/embed/M7lc1UVf-VE?autoplay=1&origin="+ str +"'></iframe>";
      $("#previewImg").html(html);
                });
            });
            
     $('#add_youtube_form').validate({
  				
  				rules:
  				{ 
  					app_name: 'required',

  				    app_url: "required",
                    
                },
				 
				messages: 
				{ 
					app_name: 'The Name is required',

				    app_url: " Enter URL"
				},
				submitHandler: function(forms,event)
				{

				   event.preventDefault(); 
                   
				    $.ajax({
					            type: "POST",
					            
					            url: "<?php echo site_url().'admin_dashboard/ajax_add_client'; ?>",
					            
					            //data: $("#add_client_form").serialize(), 

					            data: new FormData($('#add_youtube_form')[0]),
        						cache: false,
        						contentType: false,
        						processData: false,
					            
					            success: function(data)
					            {

					                // alert(data); console.log(data); return false;
					                if(data =='1')
					                {    

					                    swal("Success!", "Youtube Details Added Successfully","success").then( () => {
                                    
                                         location.reload(); });

					                }
					                else
					                {

					                    swal("Failed!", "Try Again Later.", "error");
					                    
					                    $( '#add_youtube_form' ).each(function()
					                    {
					                                

					                    });

					                        	

					                }
					            
					            }
		                  }); 
				}
			});


             $('#add_facebook_form').validate({
  				
  				rules:
  				{ 
  					app_name: 'required',
                    
                },
				 
				messages: 
				{ 
					app_name: 'The Name is required'
				},
				submitHandler: function(forms,event)
				{

				   event.preventDefault(); 
                   
				    $.ajax({
					            type: "POST",
					            
					            url: "<?php echo site_url().'admin_dashboard/ajax_add_facebook'; ?>",
					            
					            //data: $("#add_client_form").serialize(), 

					            data: new FormData($('#add_facebook_form')[0]),
        						cache: false,
        						contentType: false,
        						processData: false,
					            
					            success: function(data)
					            {

					                // alert(data); console.log(data); return false;
					                if(data =='1')
					                {    

					                    swal("Success!", "Facebook Details Added Successfully","success").then( () => {
                                    
                                         location.reload(); });

					                }
					                else
					                {

					                    swal("Failed!", "Try Again Later.", "error");
					                    
					                    $( '#add_facebook_form' ).each(function()
					                    {
					                                

					                    });

					                        	

					                }
					            
					            }
		                  }); 
				}
			});



             $('#add_instagram_form').validate({
  				
  				rules:
  				{ 
  					app_name: 'required',

  				    app_url: "required",
                    
                },
				 
				messages: 
				{ 
					app_name: 'The Name is required',

				    app_url: " Enter URL"
				},
				submitHandler: function(forms,event)
				{

				   event.preventDefault(); 
                   
				    $.ajax({
					            type: "POST",
					            
					            url: "<?php echo site_url().'admin_dashboard/ajax_add_instagram'; ?>",
					            
					            //data: $("#add_client_form").serialize(), 

					            data: new FormData($('#add_instagram_form')[0]),
        						cache: false,
        						contentType: false,
        						processData: false,
					            
					            success: function(data)
					            {

					                // alert(data); console.log(data); return false;
					                if(data =='1')
					                {    

					                    swal("Success!", "Instagram Details Added Successfully","success").then( () => {
                                    
                                         location.reload(); });

					                }
					                else
					                {

					                    swal("Failed!", "Try Again Later.", "error");
					                    
					                    $( '#add_instagram_form' ).each(function()
					                    {
					                                

					                    });

					                        	

					                }
					            
					            }
		                  }); 
				}
			});


             $('#add_twitter_form').validate({
  				
  				rules:
  				{ 
  					app_name: 'required',
                    
                },
				 
				messages: 
				{ 
					app_name: 'The Name is required'
				},
				submitHandler: function(forms,event)
				{

				   event.preventDefault(); 
                   
				    $.ajax({
					            type: "POST",
					            
					            url: "<?php echo site_url().'admin_dashboard/ajax_add_twitter'; ?>",
					            
					            //data: $("#add_client_form").serialize(), 

					            data: new FormData($('#add_twitter_form')[0]),
        						cache: false,
        						contentType: false,
        						processData: false,
					            
					            success: function(data)
					            {

					                // alert(data); console.log(data); return false;
					                if(data =='1')
					                {    

					                    swal("Success!", "Twitter Details Added Successfully","success").then( () => {
                                    
                                         location.reload(); });

					                }
					                else
					                {

					                    swal("Failed!", "Try Again Later.", "error");
					                    
					                    $( '#add_twitter_form' ).each(function()
					                    {
					                                

					                    });

					                        	

					                }
					            
					            }
		                  }); 
				}
			});



              $('#add_html_form').validate({
  				
  				rules:
  				{ 
  					app_name: 'required',
                    
                },
				 
				messages: 
				{ 
					app_name: 'The Name is required'
				},
				submitHandler: function(forms,event)
				{

				   event.preventDefault(); 
                   
				    $.ajax({
					            type: "POST",
					            
					            url: "<?php echo site_url().'admin_dashboard/ajax_add_html'; ?>",
					            
					            //data: $("#add_client_form").serialize(), 

					            data: new FormData($('#add_html_form')[0]),
        						cache: false,
        						contentType: false,
        						processData: false,
					            
					            success: function(data)
					            {

					                // alert(data); console.log(data); return false;
					                if(data =='1')
					                {    

					                    swal("Success!", "URL Details Added Successfully","success").then( () => {
                                    
                                         location.reload(); });

					                }
					                else
					                {

					                    swal("Failed!", "Try Again Later.", "error");
					                    
					                    $( '#add_html_form' ).each(function()
					                    {
					                                

					                    });

					                        	

					                }
					            
					            }
		                  }); 
				}
			});
</script>
</html>