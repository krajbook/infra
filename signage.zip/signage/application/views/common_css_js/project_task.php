<div class="project-task">
										<ul class="nav nav-tabs nav-tabs-top nav-justified mb-0">
											<li class="nav-item"><a class="task_wish_view nav-link active" href="#all_tasks" data-task_status="all" data-toggle="tab" aria-expanded="true">All Tasks</a></li>
											<li class="nav-item"><a class="task_wish_view nav-link" data-task_status="pending" href="#pending_tasks" data-toggle="tab" aria-expanded="false">Pending Tasks</a></li>
											<li class="nav-item"><a class="task_wish_view nav-link" href="#completed_tasks" data-task_status="completed" data-toggle="tab" aria-expanded="false">Completed Tasks</a></li>
										</ul>
										<div class="tab-content">
											<div class="task_wish_view tab-pane show active" id="all_tasks" data-task_status="all">
												<div class="task-wrapper">
													<div class="task-list-container">
														<div class="task-list-body" >
															<ul id="task-list">
																
															</ul>
														</div>
														<div class="task-list-footer">
															<div class="new-task-wrapper">
																<textarea id="new-task" placeholder="Enter new task here. . ."></textarea>
																<span class="error-message hidden">You need to enter a task first</span>
																<span class="add-new-task-btn btn" id="add-task">Add Task</span>
																<span class="btn" id="close-task-panel">Close</span>
															</div>
														</div>
													</div>
												</div>
											</div>
											<div class="tab-pane" id="pending_tasks">

												<div class="task-wrapper">
													<div class="task-list-container">
														<div class="task-list-body" >
															<ul id="task-list" class="tasks_pending">
																
															</ul>
														</div>
														<div class="task-list-footer">
															<div class="new-task-wrapper">
																<textarea id="new-task" placeholder="Enter new task here. . ."></textarea>
																<span class="error-message hidden">You need to enter a task first</span>
																<span class="add-new-task-btn btn" id="add-task">Add Task</span>
																<span class="btn" id="close-task-panel">Close</span>
															</div>
														</div>
													</div>
												</div>
												
											</div>
											<div class="tab-pane" id="completed_tasks">
												
												<div class="task-wrapper">
													<div class="task-list-container">
														<div class="task-list-body" >
															<ul id="task-list" class="tasks_completed">
																
															</ul>
														</div>
														<div class="task-list-footer">
															<div class="new-task-wrapper">
																<textarea id="new-task" placeholder="Enter new task here. . ."></textarea>
																<span class="error-message hidden">You need to enter a task first</span>
																<span class="add-new-task-btn btn" id="add-task">Add Task</span>
																<span class="btn" id="close-task-panel">Close</span>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>