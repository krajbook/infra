<?php $active_bar = $this->session->userdata('active_menu'); ?>


<?php 
  if($this->session->userdata('user_role')=='1')
  { ?>

    <!-- Sidebar -->
    <div class="sidebar" id="sidebar" style="width: 180px;">

      <div class="sidebar-inner slimscroll">
        
        <div id="sidebar-menu" class="sidebar-menu">
          
          <ul>
             
            <li>  
              <a href="<?php echo base_url(); ?>admin_dashboard"><i class="la la-television"></i> <span>Display</span></a> 
            </li> 
            
              
			<li> 
                <a href="<?php echo site_url(); ?>admin_dashboard/assets"><i class="la la-image"></i> <span>Assets</span></a>
            </li>
            
			<li>  
              <a href="<?php echo site_url(); ?>admin_dashboard/composition"><i class="la la-eye"></i> <span>Composition</span></a> 
            </li>

            <li> 
              <a href="<?php echo site_url(); ?>admin_dashboard/asset_schedule"><i class="la la-calendar"></i> <span>Schedule</span></a>
            </li>

            <li> 
              <a href="<?php echo site_url(); ?>admin_dashboard/socialapplication"><i class="la la-mobile"></i> <span>Apps</span></a>
            </li>
             
            
            <li> 
              <a href="<?php echo site_url(); ?>admin_dashboard/employees"><i class="la la-user"></i><span>Users</span></a>
            </li>
            
            <li> 
              <a href="<?php echo site_url(); ?>admin_dashboard/my_report"><i class="la la-file"></i> <span>Reports</span></a>
            </li>
            
            <li> 
              <a href="<?php echo site_url(); ?>admin_dashboard/plans"><i class="la la-dashboard"></i> <span>Subscription</span></a>
            </li>
            
            <li>
            <a href="<?php echo base_url(); ?>login/logout"><i class="la la-sign-out"></i><span>Sign out</span></a>
            </li>
            
            </ul>
          </div>
                </div>
    </div>

  <?php 
   }
   elseif ($this->session->userdata('user_role')=='2') 
   { ?>
      <div class="sidebar" id="sidebar" style="width: 180px;">

        <div class="sidebar-inner slimscroll">

          <div id="sidebar-menu" class="sidebar-menu">

            <ul>

              <li class="menu-title"> 

                <span>Main</span>

              </li>

              <li>  
              <a href="<?php echo base_url(); ?>admin_dashboard"><i class="la la-television"></i> <span>Display</span></a> 
            </li> 
            
              
			<li> 
                <a href="<?php echo site_url(); ?>admin_dashboard/assets"><i class="la la-image"></i> <span>Assets</span></a>
            </li>
            
			<li>  
              <a href="<?php echo site_url(); ?>admin_dashboard/composition"><i class="la la-eye"></i> <span>Composition</span></a> 
            </li>

            <li> 
              <a href="<?php echo site_url(); ?>admin_dashboard/asset_schedule"><i class="la la-calendar"></i> <span>Schedule</span></a>
            </li>

            <li> 
              <a href="<?php echo site_url(); ?>admin_dashboard/socialapplication"><i class="la la-mobile"></i> <span>Apps</span></a>
            </li>
            
            <li>
                <a href="#"><i class="la la-home"></i><span>My Account</span></a>
            </li>
            <li>
            <a href="#"><i class="la la-credit-card"></i><span>Payment History</span></a>
            </li>
            <li> 
              <a href="<?php echo site_url(); ?>admin_dashboard/my_plan"><i class="la la-play"></i> <span>My Plan</span></a>
            </li>
            <li>
            <a href="<?php echo base_url(); ?>login/logout"><i class="la la-sign-out"></i><span>Sign out</span></a>
            </li>
            </ul>

          </div>

        </div>

      </div>
    <?php } 
    elseif ($this->session->userdata('user_role')=='3') 
   { ?>

      <div class="sidebar" id="sidebar">

        <div class="sidebar-inner slimscroll">

          <div id="sidebar-menu" class="sidebar-menu">

            <ul>

              <li class="menu-title"> <span>Main</span></li>

              <li class="submenu">

                <a href="#"><i class="la la-dashboard"></i> <span> Dashboard</span> <span class="menu-arrow"></span></a>


              </li>


            </ul>

          </div>

        </div>

      </div>
      
   <?php } 

  ?>
