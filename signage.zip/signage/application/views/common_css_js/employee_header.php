<div class="page-header">
						<div class="row align-items-center">
							<div class="col">
								<h3 class="page-title">User</h3>
								<ul class="breadcrumb">
									<li class="breadcrumb-item"><a href="<?php echo base_url(); ?>">Dashboard</a></li>
									<li class="breadcrumb-item active">User</li>
								</ul>
							</div>
							<div class="col-auto float-right ml-auto">
								<a href="#" class="btn add-btn" data-toggle="modal" data-target="#add_employee"> <i class="fa fa-plus"></i> Add User</a>
								<div class="view-icons">
									<!--<a href="<?php echo site_url(); ?>admin_dashboard/employees" class="grid-view btn btn-link active"><i class="fa fa-th"></i></a>-->
									<!--<a href="<?php echo site_url(); ?>admin_dashboard/employees_list" class="list-view btn btn-link"><i class="fa fa-bars"></i></a>-->
								</div>
							</div>
						</div>
					</div>