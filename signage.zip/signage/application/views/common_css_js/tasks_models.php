	<!--crate task asign model -->


				<div id="add_ticket" class="modal custom-modal fade" role="dialog">
					<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
						<div class="modal-content">
							<div class="modal-header">
								<h5 class="modal-title">Asign Task</h5>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>
							<div class="modal-body">
								<form method="post" id="add_ticket_form" enctype="multipart/form-data">

									 <input class="form-control" type="hidden" id="task_id" name="task_id">

									  <input class="form-control" type="hidden" id="task_status" name="task_status">

									 <input class="form-control" type="hidden" id="ticket_read_staus" name="ticket_read_staus" value="<?=$ticket_read_staus; ?>">


									<div class="row">
										
										<div class="col-sm-12">
											<div class="form-group">
												<label>Projects</label>
												<select class="js-select2" id="tproject_id" name="tproject_id" style="width:100%;" <?=($ticket_read_staus=='yes')? 'disabled':'';?>>
													<option value="">-</option>
													 <?php 
 													 if(!empty($projects))
 													 {
 													 	foreach ($projects  as $projects_values) 
 													 	{ 

 								                          echo '<option value="'.$projects_values->project_id.'">'
 													 		.$projects_values->project_name.'</option>';
 													 	}
 													 }
 													 ?>
												</select>
											</div>
										</div>
									</div>

									<div class="row">
										
										<div class="col-sm-6">
											<div class="form-group">
												<label>Ticket subject</label>
												<input class="form-control" type="text" id="ticket_subject" name="ticket_subject" <?=($ticket_read_staus=='yes')? 'readonly':'';?>>
											</div>
										</div>
										<div class="col-sm-6">
											<div class="form-group">
												<label>Client</label>
												<select class="js-select2" id="client" name="client" style="width:100%;" <?=($ticket_read_staus=='yes')? 'disabled':'';?>>
													<option>-</option>
													 <?php 
 													 if(!empty($clients))
 													 {
 													 	foreach ($clients  as $clients_values) 
 													 	{ 

 								                          echo '<option value="'.$clients_values->client_id.'">'
 													 		.$clients_values->first_name.' '.$clients_values->last_name.'</option>';
 													 	}
 													 }
 													 ?>
												</select>
											</div>
										</div>
									</div>

									<div class="row">
										
										<div class="col-sm-6">
											<div class="form-group">
												<label>Ticket Id</label>
												<input class="form-control" type="text" id="ticket_id" name="ticket_id" readonly>
											</div>
										</div>
										<div class="col-sm-6">
											<div class="form-group">
												<label>Assign Staff</label>
												<select class="js-select2" id="assign_staff" name="assign_staff" style="width:100%;">
													<option value="">-</option>
													 <?php 
 													 if(!empty($employees))
 													 {
 													 	foreach ($employees as $employees_values) 
 													 	{ 

 								                          echo '<option value="'.$employees_values->user_id.'">'
 													 		.$employees_values->user_fname.' '.$employees_values->user_lname.'</option>';
 													 	}
 													 }
 													 ?>
												</select>
											</div>
										</div>
									</div>
									
									<div class="row">
										<div class="col-sm-6">
											<div class="form-group">
												<label>Priority</label>
												<select class="select" id="task_priority" name="task_priority">
													<option value="high">High</option>
													<option value="medium">Medium</option>
													<option value="low">Low</option>
												</select>
											</div>
										</div>
										<div class="col-sm-6">
											<div class="form-group">
												<label>Due Date</label>
												<div class="cal-icon">
													<input class="form-control datetimepicker" type="text" name="due_date" id="due_date">
												</div>
											</div>
										</div>
										
									</div>
									<div class="row">
										<div class="col-sm-6">
											<div class="form-group">
												<label>Assign</label>
												<select class="js-select2" id="assign" name="staff" style="width:100%;" required>
													<option value="">-</option>
													 <?php 
 													 if(!empty($employees))
 													 {
 													 	foreach ($employees as $employees_values) 
 													 	{ 
 													 		$img =($employees_values->profile_picture !='') 
 													      ? $employees_values->profile_picture:'avatar.jpg'; 
 													      $img =base_url().'images/profiles/'.$img;
 								                          

 													 		echo '<option  

 																	data-imgs_show="'.$img.'" 

 																	data-user_id="'.$employees_values->user_id.'" 

 																	data-user_name="'.$employees_values->user_login_name.'" 


 																	value="'.$employees_values->user_id.'">'
 													 		.$employees_values->user_fname.' '.$employees_values->user_lname.'</option>';
 													 	}
 													 }
 													 	
 													 
 													 ?>
												</select>
											</div>
										</div>
										<div class="col-sm-6">
											<div class="form-group">
												<label>Ticket Assignee</label>
												<div class="project-members" id="show_ticket_assignee">
													<!-- <a title="John Smith" data-placement="top" data-toggle="tooltip" href="#" class="avatar">
														<img src="<?php echo base_url(); ?>assets\img\profiles\avatar-02.jpg" alt="">
													</a> -->
												</div>
											</div>
										</div>
									</div>
									<div class="row">

										<div class="col-sm-6">
											<div class="form-group">
												<label>Add Followers</label>
												
 													<select multiple="" 
 													class="searchable"
 													 name="add_followers[]" id="add_followers" style="position: absolute; left: -9999px;">

 													 <?php 
 													 if(!empty($employees))
 													 {
 													 	foreach ($employees as $employees_values) 
 													 	{ $img =($employees_values->profile_picture !='') 
 													      ? $employees_values->profile_picture:'avatar.jpg'; 
 													      $img =base_url().'images/profiles/'.$img; 
 								echo '<option class="add_foll" 

 								data-imgs_show="'.$img.'" 

 								data-check_class="followers" 

 								data-user_id="'.$employees_values->user_id.'" 

 								data-user_name="'.$employees_values->user_login_name.'" 


 								value="'.$employees_values->user_id.'">'
 													 		.$employees_values->user_fname.' '.$employees_values->user_lname.'</option>';
 													 	}
 													 }
 													 ?>
											         
											        
         												</select>

											</div>
										</div>


										<div class="col-sm-6">
											<div class="form-group">
												<label>Ticket Followers</label>
												<div class="project-members" id="show_ticket_followers">
													<!-- <a title="Richard Miles" data-toggle="tooltip" href="#" class="avatar">
														<img src="<?php echo base_url(); ?>assets\img\profiles\avatar-09.jpg" alt="">
													</a>
													<a title="John Smith" data-toggle="tooltip" href="#" class="avatar">
														<img src="<?php echo base_url(); ?>assets\img\profiles\avatar-10.jpg" alt="">
													</a>
													<a title="Mike Litorus" data-toggle="tooltip" href="#" class="avatar">
														<img src="<?php echo base_url(); ?>assets\img\profiles\avatar-05.jpg" alt="">
													</a>
													<a title="Wilmer Deluna" data-toggle="tooltip" href="#" class="avatar">
														<img src="<?php echo base_url(); ?>assets\img\profiles\avatar-11.jpg" alt="">
													</a>
													<span class="all-team">+2</span> -->
												</div>
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-sm-12">
											<div class="form-group">
												<label>Description</label>
												<textarea class="form-control summernote1" id="tdescription" name="tdescription" required></textarea>
											</div>
											<div class="form-group">
												<label>Upload Files</label>
												<input class="form-control" type="file" name="files[]" id="files" multiple>
											</div>
										</div>
									</div>
									<div class="submit-section">
										<button class="btn btn-primary submit-btn">Submit</button>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>

				<!--crate edit task asign model -->
				<div id="edit_ticket" class="modal custom-modal fade" role="dialog">
					<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
						<div class="modal-content">
							<div class="modal-header">
								<h5 class="modal-title">Eit Asign Task</h5>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>
							<div class="modal-body">
								<form method="post" id="edit_ticket_form" enctype="multipart/form-data">

									 <input class="form-control" type="hidden" id="edit_id" name="edit_id">
									 <input class="form-control" type="hidden" id="edit_task_id" name="edit_task_id">


									<div class="row">
										
										<div class="col-sm-12">
											<div class="form-group">
												<label>Projects</label>
												<select class="js-select2" id="edit_tproject_id" name="edit_tproject_id" style="width:100%;" <?=($ticket_read_staus=='yes')? 'disabled':'';?>>
													<option value="">-</option>
													 <?php 
 													 if(!empty($projects))
 													 {
 													 	foreach ($projects  as $projects_values) 
 													 	{ 

 								                          echo '<option value="'.$projects_values->project_id.'">'
 													 		.$projects_values->project_name.'</option>';
 													 	}
 													 }
 													 ?>
												</select>
											</div>
										</div>
									</div>

									<div class="row">
										
										<div class="col-sm-6">
											<div class="form-group">
												<label>Ticket subject</label>
												<input class="form-control" type="text" id="edit_ticket_subject" name="edit_ticket_subject" <?=($ticket_read_staus=='yes')? 'readonly':'';?>>
											</div>
										</div>
										<div class="col-sm-6">
											<div class="form-group">
												<label>Client</label>
												<select class="js-select2" id="edit_client" name="edit_client" style="width:100%;" <?=($ticket_read_staus=='yes')? 'disabled':'';?>>
													<option>-</option>
													 <?php 
 													 if(!empty($clients))
 													 {
 													 	foreach ($clients  as $clients_values) 
 													 	{ 

 								                          echo '<option value="'.$clients_values->client_id.'">'
 													 		.$clients_values->first_name.' '.$clients_values->last_name.'</option>';
 													 	}
 													 }
 													 ?>
												</select>
											</div>
										</div>
									</div>

									<div class="row">
										
										<div class="col-sm-6">
											<div class="form-group">
												<label>Ticket Id</label>
												<input class="form-control" type="text" id="edit_ticket_id" name="edit_ticket_id">
											</div>
										</div>
										<div class="col-sm-6">
											<div class="form-group">
												<label>Assign Staff</label>
												<select class="js-select2" id="edit_assign_staff" name="edit_assign_staff" style="width:100%;">
													<option value="">-</option>
													 <?php 
 													 if(!empty($employees))
 													 {
 													 	foreach ($employees as $employees_values) 
 													 	{ 

 								                          echo '<option value="'.$employees_values->user_id.'">'
 													 		.$employees_values->user_fname.' '.$employees_values->user_lname.'</option>';
 													 	}
 													 }
 													 ?>
												</select>
											</div>
										</div>
									</div>
									
									<div class="row">
										<div class="col-sm-6">
											<div class="form-group">
												<label>Priority</label>
												<select class="select" id="edit_task_priority" name="edit_task_priority">
													<option value="high">High</option>
													<option value="medium">Medium</option>
													<option value="low">Low</option>
												</select>
											</div>
										</div>
										<div class="col-sm-6">
											<div class="form-group">
												<label>Due Date</label>
												<div class="cal-icon">
													<input class="form-control datetimepicker" type="text" name="edit_due_date" id="edit_due_date">
												</div>
											</div>
										</div>
										
									</div>
									<div class="row">
										<div class="col-sm-6">
											<div class="form-group">
												<label>Assign</label>
												<select class="js-select2" id="edit_assign" name="edit_assign" style="width:100%;" required>
													<option value="">-</option>
													 <?php 
 													 if(!empty($employees))
 													 {
 													 	foreach ($employees as $employees_values) 
 													 	{ 
 													 		$img =($employees_values->profile_picture !='') 
 													      ? $employees_values->profile_picture:'avatar.jpg'; 
 													      $img =base_url().'images/profiles/'.$img;
 								                          

 													 		echo '<option  

 																	data-imgs_show="'.$img.'" 

 																	data-user_id="'.$employees_values->user_id.'" 

 																	data-user_name="'.$employees_values->user_login_name.'" 


 																	value="'.$employees_values->user_id.'">'
 													 		.$employees_values->user_fname.' '.$employees_values->user_lname.'</option>';
 													 	}
 													 }
 													 	
 													 
 													 ?>
												</select>
											</div>
										</div>
										<div class="col-sm-6">
											<div class="form-group">
												<label>Ticket Assignee</label>
												<div class="project-members" id="edit_show_ticket_assignee">
													<!-- <a title="John Smith" data-placement="top" data-toggle="tooltip" href="#" class="avatar">
														<img src="<?php echo base_url(); ?>assets\img\profiles\avatar-02.jpg" alt="">
													</a> -->
												</div>
											</div>
										</div>
									</div>
									<div class="row">

										<div class="col-sm-6">
											<div class="form-group">
												<label>Add Followers</label>
												
 													<select multiple="" 
 													class="searchable"
 													 name="edit_add_followers[]" id="edit_add_followers" style="position: absolute; left: -9999px;">

 													 <?php 
 													 if(!empty($employees))
 													 {
 													 	foreach ($employees as $employees_values) 
 													 	{ $img =($employees_values->profile_picture !='') 
 													      ? $employees_values->profile_picture:'avatar.jpg'; 
 													      $img =base_url().'images/profiles/'.$img; 
 								echo '<option class="edit_add_foll" 

 								data-imgs_show="'.$img.'" 

 								data-check_class="edit_followers" 

 								data-user_id="'.$employees_values->user_id.'" 

 								data-user_name="'.$employees_values->user_login_name.'" 


 								value="'.$employees_values->user_id.'">'
 													 		.$employees_values->user_fname.' '.$employees_values->user_lname.'</option>';
 													 	}
 													 }
 													 ?>
											         
											        
         												</select>

											</div>
										</div>


										<div class="col-sm-6">
											<div class="form-group">
												<label>Ticket Followers</label>
												<div class="project-members" id="edit_show_ticket_followers">
													<!-- <a title="Richard Miles" data-toggle="tooltip" href="#" class="avatar">
														<img src="<?php echo base_url(); ?>assets\img\profiles\avatar-09.jpg" alt="">
													</a>
													<a title="John Smith" data-toggle="tooltip" href="#" class="avatar">
														<img src="<?php echo base_url(); ?>assets\img\profiles\avatar-10.jpg" alt="">
													</a>
													<a title="Mike Litorus" data-toggle="tooltip" href="#" class="avatar">
														<img src="<?php echo base_url(); ?>assets\img\profiles\avatar-05.jpg" alt="">
													</a>
													<a title="Wilmer Deluna" data-toggle="tooltip" href="#" class="avatar">
														<img src="<?php echo base_url(); ?>assets\img\profiles\avatar-11.jpg" alt="">
													</a>
													<span class="all-team">+2</span> -->
												</div>
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-sm-12">
											<div class="form-group">
												<label>Description</label>
												<textarea class="form-control summernote" id="edit_tdescription" name="edit_tdescription"></textarea>
											</div>
											<div class="form-group">
												<label>Upload Files</label>
												<input class="form-control" type="file" name="files[]" id="files" multiple>
												<input  class="form-control" type=hidden id="edit_files" name="edit_files" value="">
											</div>

											
												<div class="task-follower-list" id="edit_show_upload_files">
										
										
									            </div>
											
										</div>
									</div>
									<div class="submit-section">
										<button id="edit_ticket_subject_btn" class="btn btn-primary submit-btn" disabled="true">Submit</button>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>


				<!-- Delete Ticket Modal -->
			 <div class="modal custom-modal fade" id="delete_ticket" role="dialog">
					<div class="modal-dialog modal-dialog-centered">
						<div class="modal-content">
							<div class="modal-body">
								<div class="form-header">
									<h3>Delete Ticket</h3>
									<p>Are you sure want to delete?</p>
								</div>
								<div class="modal-btn delete-action">
									<div class="row">
										<div class="col-6">
											<a id="comform_delete" href="javascript:void(0);" class="btn btn-primary continue-btn">Delete</a>
											<input type="hidden" name="hidden_delete" id="hidden_delete">
										</div>
										<div class="col-6">
											<a href="javascript:void(0);" data-dismiss="modal" class="btn btn-primary cancel-btn">Cancel</a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div> 
				<!-- /Delete Ticket Modal -->

