
		<script>
			
			
			$(document).on("click", "#add_task", function (event) 
    		{

    		  var project_id = "<?php echo $project->project_id; ?>";

    		  var new_task = $('#new_task').val();

    		  if(new_task=='')
    		  {
    		  	$('#new_task').css("border", "1px solid #D93737");
    		  	$('#new_task').css("outline", "none");
    		  	return false;
    		  }
    		  $('#new_task').css("border", "");
    		  $('#new_task').css("outline", "");

    		    $.ajax({
						    type: "POST",

						    dataType: "json",
						    
						    url: "<?php echo site_url().'tasksController/ajax_add_task'; ?>",
						    
						    data: {'new_task':new_task,'project_id':project_id}, 
						    
						    success: function(data)
						    {

						    	//alert(data);console.log(data.task_id);return false;
						        if(data.status =='1')
						        {    

						        var task_append = '<li class="task" id="common_'+data.task_id+'"><div class="task-container"><span class="task-action-btn task-check" data-task_id="'+data.task_id+'"><span  data-task_id="'+data.task_id+'" class="action-circle large complete-btn" title="Mark Complete"><i class="material-icons">check</i></span></span><span data-task_id="'+data.task_id+'" class="task-label" contenteditable="true">'+new_task+'</span><span class="task-action-btn task-btn-right"><span data-task_id="'+data.task_id+'" class="action-circle large asign_task" data-toggle="modal" data-target="#add_ticket" title="Assign"><i class="material-icons">person_add</i></span><span data-task_id="'+data.task_id+'" class="action-circle large delete_task" title="Delete Task"><i class="material-icons">delete</i></span></span></div></li>';

						        	$('#task-list').append(task_append);

						        	$('#new_task').val('');
						        	

						        	

						           /* swal("Success!", "client Deleted  Deleted Successfully", "success");

						            $('#clients_model_hide_'+$("#hidden_delete").val()).hide();

                                    $(".cancel-btn").click();*/

                                   /* swal("Success!", "Projects Details Deleted Successfully","success").then( () => {
                                    
                                         location.reload(); });*/
						                              
						        }
						        else if(data=='0')
						        {
						        	swal("Warning!", "Task is Already Exits","error")
						        	$('#new_task').css("border", "1px solid #D93737");
    		  	                    $('#new_task').css("outline", "none");

						        }
						        else
						        {

						            swal("Failed!", "Try Again Later.", "error");
						                           
						        }
						    }
			            });


    
    		});

    		$(document).on("keyup", ".task-label", function (event) 
    		{

    		    var task_id = $(this).data('task_id');

    		    var task_name = $(this).text();

    		    var project_id = "<?php echo $project->project_id; ?>";

    		    if(task_name.length<1)
    		    {
    		    	$(this).css("border", "1px solid #D93737");
    		  	    $(this).css("outline", "none");
    		    	return false;

    		    }
    		    $(this).css("border", "");
    		    $(this).css("outline", "");

    		    if(new_task=='')
    		    {
    		  		
    		  		$('#new_task').css("border", "1px solid #D93737");
    		  		
    		  		$('#new_task').css("outline", "none");
    		  	    
    		  	    return false;
    		    }
    		  	
    		  	$('#new_task').css("border", "");
    		  	
    		  	$('#new_task').css("outline", "");

    		    $.ajax({
						    type: "POST",
						    
						    url: "<?php echo site_url().'tasksController/ajax_edit_task'; ?>",
						    
						    data: {'task_id':task_id,'task_name':task_name,'project_id':project_id}, 
						    
						    success: function(data)
						    {

						    	//alert(data); return false;
						        if(data =='1')
						        {    

						           /* swal("Success!", "client Deleted  Deleted Successfully", "success");

						            $('#clients_model_hide_'+$("#hidden_delete").val()).hide();

                                    $(".cancel-btn").click();*/

                                   /* swal("Success!", "Projects Details Deleted Successfully","success").then( () => {
                                    
                                         location.reload(); });*/
						                              
						        }
						        else if(data=='0')
						        {
						        	swal("Warning!", "Task is Already Exits","error")
						        	$(this).css("border", "1px solid #D93737");
    		  	                    $(this).css("outline", "none");

						        }
						        else
						        {

						            swal("Failed!", "Try Again Later.", "error");
						                           
						        }
						    }
			            });


    		});

    		$(document).on("click", ".delete_task", function (event) 
    		{
    			swal({
					    title: "Are you sure?",
					    text: "Comfirm Delete",
					    icon: "warning",
					    buttons: true,
					    dangerMode: true,
					})
					.then((willDelete) => 
					{
						if (willDelete) 
						{
	                        var task_id = $(this).data('task_id');

							$.ajax({
									    type: "POST",
									    
									    url: "<?php echo site_url().'tasksController/ajax_delete_task'; ?>",
									    
									    data: {'task_id':$(this).data('task_id')}, 
							    
							    		success: function(data)
							    		{

							    			$('#common_'+task_id).hide();

							        		if(data =='1')
							        	    {    

							        			swal("Task has been deleted!", {icon: "success",});
							                              
							        		}
							        		else
							        		{

							        		    swal("Task Was Not Deleted!");
							                           
							        		}
							            }
				                    });
	                           
						} 
						else
						{
						    swal("Task has been safe!");
						}
					});

    		});

    		/*$(document).on("click", ".change_task_status", function (event) 
    		{

    			var arr=[];

	           $("span[title='Mark Incomplete']").each(function() 
	           {
	        
	              arr.push($(this).data('task_id'));
	          
	           });

	           if(arr.length<1)
	           {

	           	return false;

	           }

	             $.ajax({
							    type: "POST",
							    
							    url: "<?php echo site_url().'tasksController/ajax_update_task_status'; ?>",
							    
							    data: {'task_id':arr,'task_status':$(this).data('task_status')}, 
							    
							    success: function(data)
							    {

							    	//alert(data); return false;
							        if(data =='1')
							        {    

							            swal("Success!", "Task Status Updated Successfully", "success");
							                              
							        }
							        else
							        {

							            swal("Failed!", "Try Again Later.", "error");
							                           
							        }
							    }
				            });

    			
    		});*/

    		$(document).on("click", ".task-check", function (event) 
    		{  

    			
                swal({
					    title: "Are you sure?",
					    text: "Comfirm To Change Task Status",
					    icon: "warning",
					    buttons: true,
					    dangerMode: true,
					})
						.then((willDelete) => 
						{
						    if (willDelete) 
						    {
	                             
	                           

	                            $.ajax({
									    	type: "POST",
									    
									    	url: "<?php echo site_url().'tasksController/ajax_update_task_status_change'; ?>",
									    
									    	data: {'task_id':$(this).data('task_id')}, 
							    
							    			success: function(data)
							    			{

							    					//alert(data); return false;
							        				if(data =='1')
							        				{    

							        				    //swal("Success!", "Task Status Updated Successfully", "success");
							                              
							        				}
							        				else
							        				{

							        				    swal("Failed!", "Try Again Later.", "error");
							                           
							        				}
							                }
				                        });

								    swal("Task Status Changed!", {
								      icon: "success",
								    });
						    } 
						    else
						    {
								    swal("Task Status Not Changed!");
						    }
						});
	
    		});

    		$(document).on("click", ".task_wish_view", function (event) 
    		{  

    			var project_id = "<?php echo $project->project_id; ?>";

    			

    			$.ajax({
						    type: "POST",
								    
						    url: "<?php echo site_url().'tasksController/ajax_get_task'; ?>",
								    
						    data: {'project_id':project_id,'task_status':$(this).data('task_status')}, 
						    
						    success: function(data)
						    {

						    	//console.log(data);

						    	//return false;

						    	$('#task-list').html(data);

							    
							}
				        
				        });

    			
    		});

    		




    		


		</script>

		<script type="text/javascript">

			$(".js-select2").select2();


    		$(document).on("change", "#assign", function (event) 
    		{  

    			
    			var url="<?php echo base_url().'admin_dashboard/profile/';?>"+$("#assign option:selected").data('user_id');

    			var string ='<a title="'+$("#assign option:selected").data('user_name')+'" data-placement="top" data-toggle="tooltip" href="'+url+'" class="avatar"><img src="'+$("#assign option:selected").data('imgs_show')+'" alt=""></a>';  

    			$('#show_ticket_assignee').html(string); 
	
    		});
    		$(document).on("click", ".asign_task", function (event) 
    		{  

              var ticket_subject_value = $(this).parent().prev().text();

              var ticket_subject_task_id = $(this).parent().prev().data('task_id');

              $('#ticket_subject').val(ticket_subject_value);

              $('#task_id').val(ticket_subject_task_id);

    			var project_id = "<?php echo $project->project_id; ?>";

    			$.ajax({
					            type: "POST",
					            dataType: "json",
					            url: "<?php echo site_url().'admin_dashboard/ticket_no'; ?>",
					            data:{'project_id':project_id},
					            success: function(data)
					            {

					            	//console.log(data);  //return false;

					                $('#ticket_id').val(data.ticket_no);
					                
					                $('#client').val(data.client_id); 
                                    
                                    $('#client').trigger('change');

                                     $('#tproject_id').val(data.project_id); 
                                    
                                    $('#tproject_id').trigger('change');


					              
					            
					            }
		                  }); 
    		});

    		$('#add_ticket_form').validate({
  				
  				rules:
  				{ 
  					ticket_id: 'required',

  					assign: 'required',

                },
                

				 
				messages: 
				{ 
					ticket_id: 'The Ticket Id is required',

					assign: 'The Assign is required',
				},
				submitHandler: function(forms,event)
				{

				   event.preventDefault(); 

				   $('#client').prop('disabled', false);

				   $('#tproject_id').prop('disabled', false);


				    $.ajax({
					            type: "POST",

					            dataType: "json",
					            
					            url: "<?php echo site_url().'ticketsController/ajax_add_tickets'; ?>",

					            data: new FormData($('#add_ticket_form')[0]),
        						cache: false,
        						contentType: false,
        						processData: false,
					            
					            success: function(data)
					            {
					            	$('#client').prop('disabled', true);
					            	$('#tproject_id').prop('disabled', true);

					            	

					                //alert(data.status); console.log(data); return false;
					                if(data.status =='1')
					                {    

					                    swal("Success!", "Tickets Details Added Successfully","success").then( () => {
                                    
                                         location.reload(); }).fadeOut(3000);

					                }
					                else if(data.status =='0')
					                {    

					                    swal("Warning!", "Tickets No Is  Already Exits","error").then( () => {
                                    
                                          });

					                }
					                else
					                {

					                    swal("Failed!", "Try Again Later.", "error");
					                    
					                    $( '#add_ticket_form' ).each(function()
					                    {
					                                

					                    });

					                        	

					                }
					            
					            }
		                  }); 
				}
			});


			$(document).ready(function() 
			{
           $('.summernote1').summernote({ height:50});

});

			
			 //edit task
           $(document).on("click", ".asign_edit_task", function (event) 
    		{  



              var ticket_subject_value = $(this).parent().prev().text();

              var ticket_subject_task_id = $(this).parent().prev().data('task_id');

              /*alert(ticket_subject_task_id); return false;

              $('#ticket_subject').val(ticket_subject_value);

              $('#task_id').val(ticket_subject_task_id);*/

    		  //var project_id = "<?php echo $project->project_id; ?>";

    			$.ajax({
					            type: "POST",
					            dataType: "json",
					            url: "<?php echo site_url().'ticketscontroller/ajax_get_ticket'; ?>",
					            data:{'task_id':ticket_subject_task_id},
					            success: function(data)
					            { 

					            	if(data.status=='1')
					            	{



					            	$('#edit_task_id').val(data.task_id);

					            	$('#edit_id').val(data.task_ticket_id);

					            	$('#edit_tproject_id').val(data.project_id); 
                                    
                                    $('#edit_tproject_id').trigger('change');

                                    $('#edit_ticket_id').val(data.ticket_id);

                                    $('#edit_ticket_subject').val(ticket_subject_value);

                                    $('#edit_client').val(data.client); 
                                    
                                    $('#edit_client').trigger('change');

                                    $('#edit_assign_staff').val(data.task_asign_by); 
                                    
                                    $('#edit_assign_staff').trigger('change');

                                    $('#edit_task_priority').val(data.task_priority); 
                                    
                                    $('#edit_task_priority').trigger('change');

                                    $('#edit_assign').val(data.task_assign); 
                                    
                                    $('#edit_assign').trigger('change');

                                    $('#edit_due_date').val(data.ticket_due_date); 

                                   
                                    var url="<?php echo base_url().'admin_dashboard/profile/';?>"+data.task_assign;

    			                   var string ='<a title="'+data.task_assign_name+'" data-placement="top" data-toggle="tooltip" href="'+url+'" class="avatar"><img src="'+data.task_assign_pic+'" alt=""></a>';  

    			                   $('#edit_show_ticket_assignee').html(string); 

    			                  //console.log(data);

    			                    $('#edit_add_followers').multiSelect('select',data.task_followers);

    			                    $('#edit_show_ticket_followers').html(data.task_followers_pic);

    			                    //$('#edit_tdescription').summernote('code','data.task_description');

    			                    $("#edit_tdescription").summernote("code", data.task_description);

                                    $('#edit_show_upload_files').html(data.task_file_html);

    			                    $('#edit_files').val(data.task_files);


    			                    $('#edit_ticket_subject_btn').prop('disabled',false);


    			                }

					            }
		                  }); 
    		});

           $(document).on("click", ".files_delete", function () 
			{

			    swal({
					    title: "Are you sure?",
					    text: "Comfirm Delete",
					    icon: "warning",
					    buttons: true,
					    dangerMode: true,
					})
						.then((willDelete) => 
						{
						    if (willDelete) 
						    {
	                             
	                            Array.prototype.remove = function() 
	                            {
										    var what, a = arguments, L = a.length, ax;
										    while (L && this.length) {
										        what = a[--L];
										        while ((ax = this.indexOf(what)) !== -1) {
										            this.splice(ax, 1);
										        }
										    }
										    return this;
								};

	                               var all_img = $('#edit_files').val();

	                               var str_arr = all_img.split(',');
						            str_arr.remove($(this).data('img_name'));

						            $('#edit_files').val(str_arr.toString());

						            $(this).parent().fadeOut(300);

								    swal("Poof! Your Tasks Image file has been deleted!", {
								      icon: "success",
								    });
						    } 
						    else
						    {
								    swal("Your image file is safe!");
						    }
						});


			});

           

           $('#edit_ticket_form').validate(
			{ 
  				
  				rules:
  				{ 
  					edit_ticket_id: 'required',

  					edit_assign:'required'
                },
				 
				messages: 
				{ 
					edit_ticket_id: 'The Ticket Id is required',
				},
				submitHandler: function(forms,event)
				{

				   event.preventDefault(); 

				   $('#edit_client').prop('disabled', false);

				   $('#edit_tproject_id').prop('disabled', false);

				   var ticket_read_staus ="<?php echo $ticket_read_staus; ?>"; 

				    $.ajax({
					            type: "POST",

					             dataType: "json",
					            
					            url: "<?php echo site_url().'ticketsController/ajax_edit_tickets'; ?>",

					            data: new FormData($('#edit_ticket_form')[0]),
        						cache: false,
        						contentType: false,
        						processData: false,
					            
					            success: function(data)
					            {  

                                    if(ticket_read_staus=='yes')
                                    {
                                    	$('#edit_client').prop('disabled', true);
					            	    $('#edit_tproject_id').prop('disabled', true);

                                    }
					                

					            	//alert(data); console.log(data); return false;

					                if(data.status =='1')
					                {    

					                    swal("Success!", "Ticket Details Updated Successfully","success").then( () => {
                                    
                                         location.reload(); }).fadeOut(3000);

					                }
					                else
					                {

					                    swal("Failed!", "Try Again Later.", "error");
					                    
					                    $( '#edit_ticket_form' ).each(function()
					                    {
					                                

					                    });

					                        	

					                }
					            
					            }
		                  }); 
				}
			});

		</script>