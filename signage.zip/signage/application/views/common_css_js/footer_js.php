<!-- jQuery -->
        <script src="<?php echo base_url(); ?>assets\js\jquery-3.2.1.min.js"></script>


        <script src="<?php echo base_url(); ?>assets\js\jquery-ui.min.js"></script>
		<script src="<?php echo base_url(); ?>assets\js\jquery.ui.touch-punch.min.js"></script>


		<!-- Bootstrap Core JS -->
        <script src="<?php echo base_url(); ?>assets\js\popper.min.js"></script>

        <script src="<?php echo base_url(); ?>assets\js\bootstrap.min.js"></script>

		<!-- Slimscroll JS -->
		<script src="<?php echo base_url(); ?>assets\js\jquery.slimscroll.min.js"></script>
		
		<!-- Select2 JS -->
		<script src="<?php echo base_url(); ?>assets\js\select2.min.js"></script>
		
		<!-- Datetimepicker JS -->
		<script src="<?php echo base_url(); ?>assets\js\moment.min.js"></script>
		
		<script src="<?php echo base_url(); ?>assets\js\bootstrap-datetimepicker.min.js"></script>

		<!-- Tagsinput JS -->
		<script src="<?php echo base_url(); ?>assets\plugins\bootstrap-tagsinput\bootstrap-tagsinput.min.js"></script>

		<!-- Summernote JS -->
		<script src="<?php echo base_url(); ?>assets\plugins\summernote\dist\summernote-bs4.min.js"></script>
		
		<!-- Task JS -->
		<script src="<?php echo base_url(); ?>assets\js\task.js"></script>

			<!-- Datatable JS -->
		<script src="<?php echo base_url(); ?>assets\js\jquery.dataTables.min.js"></script>

		<script src="<?php echo base_url(); ?>assets\js\dataTables.bootstrap4.min.js"></script>

		<!-- Custom JS -->
		<script src="<?php echo base_url(); ?>assets\js\app.js"></script>

		<script src="<?php echo base_url(); ?>assets/js/jquery.multi-select.min.js"></script>

		<script src="<?php echo base_url(); ?>assets/js/jquery.quicksearch.min.js"></script>

		<script src="<?php echo base_url(); ?>assets\js\sweetalert.min.js"></script>

	    <script src="<?php echo base_url(); ?>assets/js/jquery.validate.min.js"></script>		





	
		
		

		