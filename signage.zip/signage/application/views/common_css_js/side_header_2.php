<?php $active_bar = $this->session->userdata('active_menu'); ?>


  <!-- Sidebar -->
            <div class="sidebar" id="sidebar">
                <div class="sidebar-inner slimscroll">
          <div class="sidebar-menu">
            <ul>
              <li> 
                <a href="<?php echo base_url(); ?>"><i class="la la-home"></i> <span>Back to Home</span></a>
              </li>
              <li class="menu-title">Add Client <a href="#" data-toggle="modal" data-target="#add_client"><i class="fa fa-plus"></i></a></li>

              <?php 

              if(count($employees)>0)
              {
                foreach ($employees as $key => $result_list_values) 
                { 

                  $active =($result_list_values->user_id==$employee_id) ? 'active':'';

                  echo '<li class="'.$active.'"> 
                              <a href="'.base_url().'home/todo_inbox/'.$result_list_values->user_id.'">'.$result_list_values->user_fname.' ' .$result_list_values->user_lname.'</a>
                        </li>';
                  
                }

              }
                ?>
              
            </ul>
          </div>
                </div>
            </div>
      <!-- /Sidebar -->