
				
				<!-- Edit Client Modal -->
				<div id="edit_client" class="modal custom-modal fade" role="dialog">
					<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
						<div class="modal-content">
							<div class="modal-header">
								<h5 class="modal-title">Edit Client</h5>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>
							<div class="modal-body">
								<form method="post" id="edit_client_form" enctype="multipart/form-data">
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<label class="col-form-label">First Name <span class="text-danger">*</span></label>
												<input class="form-control" type="text" name="edit_first_name" id="edit_first_name" required>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label class="col-form-label">Last Name</label>
												<input class="form-control" type="text" name="edit_last_name" id="edit_last_name">
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label class="col-form-label">Username <span class="text-danger">*</span></label>
												<input class="form-control" type="text" name="edit_user_name" id="edit_user_name" required>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label class="col-form-label">Phone </label>
												<input class="form-control" type="text" name="edit_phone" id="edit_phone" >
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label class="col-form-label">Department</label>
												<input class="form-control" type="text" name="edit_department" id="edit_department" >
											</div>
										</div>
										<div class="col-md-6">
											<div class="row">
												<div class="col-md-6"><div class="form-group">
												<label class="col-form-label">Profile Picture</label>
												<input class="form-control" type="file" name="edit_profile_picture" id="edit_profile_picture">
												<input class="form-control" type="hidden" name="edit_profile_picture_file" id="edit_profile_picture_file">
												<input class="form-control" type="hidden" name="edit_client_id" id="edit_client_id">
												
											</div></div>
												<div class="col-md-3"><img height="100px" width="100px" id="edit_profile_pic_show" alt="" src=""></div>
												

											</div>
											
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label class="col-form-label">Email <span class="text-danger">*</span></label>
												<input class="form-control floating" type="email" name="edit_email" id="edit_email" required>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label class="col-form-label">Password</label>
												<input class="form-control" type="password" name="edit_password" id="edit_password" required>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label class="col-form-label">Confirm Password</label>
												<input class="form-control" type="password" name="edit_confirm_password" id="edit_confirm_password" required>
											</div>
										</div>
										<div class="col-md-6">  
											<div class="form-group">
												<label class="col-form-label">Client ID <span class="text-danger">*</span></label>
												<input class="form-control floating" readonly type="text" name="edit_clientid" id="edit_clientid" required>
											</div>
										</div>
										
										<div class="col-md-6">
											<div class="form-group">
												<label class="col-form-label">Company Name</label>
												<input class="form-control" type="text" name="edit_company_name" id="edit_company_name" required>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label class="col-form-label">Client Sources</label>
												<input class="form-control" type="text" name="edit_client_sources" id="edit_client_sources" required>
											</div>
										</div>
										<div class="col-md-12">
											<div class="form-group">
												<label class="col-form-label">Company Address</label>
												<textarea class="form-control rounded-0" id="edit_company_address" name="edit_company_address" rows="3"></textarea>
											</div>
										</div>

									</div>
									
									<div class="submit-section">
										<button class="btn btn-primary submit-btn">Submit</button>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
				<!-- /Edit Client Modal -->
				
				<!-- Delete Client Modal -->
				<div class="modal custom-modal fade" id="delete_client" role="dialog">
					<div class="modal-dialog modal-dialog-centered">
						<div class="modal-content">
							<div class="modal-body">
								<div class="form-header">
									<h3>Delete Client</h3>
									<p>Are you sure want to delete?</p>
								</div>
								<div class="modal-btn delete-action">
									<div class="row">
										<div class="col-6">
											<a id="comform_delete" href="javascript:void(0);" class="btn btn-primary continue-btn">Delete</a>
											<input type="hidden" name="hidden_delete" id="hidden_delete">
										</div>
										<div class="col-6">
											<a href="javascript:void(0);" data-dismiss="modal" class="btn btn-primary cancel-btn">Cancel</a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- /Delete Client Modal -->