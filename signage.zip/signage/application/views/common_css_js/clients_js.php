<script type="text/javascript">


	$(document).on("click", ".edit_client_model", function (event) 
    {

		    	$('#edit_first_name').val($(this).data('first_name'));
				$('#edit_last_name').val($(this).data('last_name'));
				$('#edit_user_name').val($(this).data('user_name'));
				$('#edit_phone').val($(this).data('phone'));
				$('#edit_department').val($(this).data('department'));
				$('#edit_profile_picture_file').val($(this).data('profile_image'));
				$('#edit_client_id').val($(this).data('client_id'));
				$('#edit_email').val($(this).data('email'));
				$('#edit_password').val($(this).data('password'));
				$('#edit_confirm_password').val($(this).data('password'));
				$('#edit_clientid').val('TC'+$(this).data('client_id'));
				$('#edit_company_name').val($(this).data('company_name'));
				$('#edit_company_address').val($(this).data('company_address'));
				$('#edit_company_name').val($(this).data('company_name'));
				$('#edit_client_sources').val($(this).data('cliet_sources'));
				$('#edit_profile_pic_show').attr('src',$(this).data('profile_image_show'));

    });

		   $('#add_client_form').validate({
  				
  				rules:
  				{ 
  					first_name: 'required',

  				    password: "required",
                    
                    confirm_password: 
                    {
                          equalTo: "#password"
                    }
                },
				 
				messages: 
				{ 
					first_name: 'The First Name is required',

				    password: " Enter Password",
                    
                    confirm_password: " Enter Confirm Password Same as Password"
				},
				submitHandler: function(forms,event)
				{

				   event.preventDefault(); 

				    $.ajax({
					            type: "POST",
					            
					            url: "<?php echo site_url().'clientsController/ajax_add_client'; ?>",
					            
					            //data: $("#add_client_form").serialize(), 

					            data: new FormData($('#add_client_form')[0]),
        						cache: false,
        						contentType: false,
        						processData: false,
					            
					            success: function(data)
					            {

					                //alert(data); console.log(data); return false;
					                if(data =='1')
					                {    

					                    swal("Success!", "Client Details Added Successfully","success").then( () => {
                                    
                                         location.reload(); });

					                }
					                else
					                {

					                    swal("Failed!", "Try Again Later.", "error");
					                    
					                    $( '#add_client_form' ).each(function()
					                    {
					                                

					                    });

					                        	

					                }
					            
					            }
		                  }); 
				}
			});
		   
			$('#edit_client_form').validate({
  				
  				rules:
  				{ 
  					first_name: 'required',

  				    password: "required",
                    
                    confirm_password: 
                    {
                          equalTo: "#password"
                    }
                },
				 
				messages: 
				{ 
					first_name: 'The First Name is required',

				    password: " Enter Password",
                    
                    confirm_password: " Enter Confirm Password Same as Password"
				},
				submitHandler: function(forms,event)
				{

				   event.preventDefault(); 

				    $.ajax({
					            type: "POST",
					            
					            url: "<?php echo site_url().'clientsController/ajax_edit_client'; ?>",
					            
					            //data: $("#add_client_form").serialize(), 

					            data: new FormData($('#edit_client_form')[0]),
        						cache: false,
        						contentType: false,
        						processData: false,
					            
					            success: function(data)
					            {

					                //alert(data); console.log(data); return false;
					                if(data =='1')
					                {   

					                swal("Success!", "Client Details Updated Successfully","success").then( () => {
                                    
                                    location.reload(); });
					             
					                }
					                else
					                {

					                    swal("Failed!", "Try Again Later.", "error");    	

					                }
					            
					            }
		                  }); 
				}
			});

			$(document).on("click", ".delete_client_model", function (event) 
    		{

   	 			$("#hidden_delete").val($(this).data('client_id'));
    
    		});

    		$(document).on("click", "#comform_delete", function () 
			{
					
					
			    $.ajax({
						    type: "POST",
						    
						    url: "<?php echo site_url().'clientsController/ajax_delete_client'; ?>",
						    
						    data: {'client_id':$("#hidden_delete").val()}, 
						    
						    success: function(data)
						    {
						        if(data =='1')
						        {    

						           /* swal("Success!", "client Deleted  Deleted Successfully", "success");

						            $('#clients_model_hide_'+$("#hidden_delete").val()).hide();

                                    $(".cancel-btn").click();*/

                                    swal("Success!", "client Details Deleted Successfully","success").then( () => {
                                    
                                         location.reload(); });
						                              
						        }
						        else
						        {

						            swal("Failed!", "Try Again Later.", "error");
						                           
						        }
						    }
			            });


			});
			
			

</script>