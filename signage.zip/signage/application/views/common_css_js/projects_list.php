<div class="row">

						<?php
						if(!empty($projects))
						{
							foreach($projects as $project_values)
							{ 
								$project_leaders = json_decode($project_values->project_leaders,true); 
								$project_members = json_decode($project_values->project_members,true);

								$project_images  = json_decode($project_values->project_images,true);

								$img_1='';
								$img_2='';

								$img_3='';

								if(!empty($project_leaders))
							    {
									foreach ($project_leaders as $project_leaders_li) 
									{  
                                                  
										$get_user = $this->nlp_model->select_order('users',array('user_id'=>$project_leaders_li));


										$pl_img = (($get_user->num_rows()>0) && ($get_user->row()->profile_picture !='')) 

													? $get_user->profile_picture:'avatar.jpg'; 

							                      
 							            $pl_img =base_url().'images/profiles/thumb/'.$pl_img; 

 							            $names = $get_user->row()->user_fname." ".$get_user->row()->user_lname;

									    $url = base_url().'admin_dashboard/profile/';

  			                            $img_1 .='<a href="'.$url.$get_user->row()->user_id.'" data-toggle="tooltip"   class="avatar"><img src="'.$pl_img.'" alt="" title="'.$names.'"></a>';



									}
								} 

								if(!empty($project_members))
							    {
									foreach ($project_members as $project_members_li) 
									{  
                                                  
										$get_user = $this->nlp_model->select_order('users',array('user_id'=>$project_members_li));


										$pl_img = (($get_user->num_rows()>0) && ($get_user->row()->profile_picture !='')) 

													? $get_user->profile_picture:'avatar.jpg'; 

							                      
 							            $pl_img =base_url().'images/profiles/thumb/'.$pl_img; 

 							            $names = $get_user->row()->user_fname." ".$get_user->row()->user_lname;

									    $url = base_url().'admin_dashboard/profile/';

  			                            $img_2 .='<a href="'.$url.$get_user->row()->user_id.'" data-toggle="tooltip"   class="avatar"><img src="'.$pl_img.'" alt="" title="'.$names.'"></a>';



									}
								} 

								if(!empty($project_images))
							    {
									foreach ($project_images as $project_images_li) 
									{  
                                                            
 							            $project_images_url =base_url().'images/projects/thumb/'.$project_images_li; 
                                        if($project_images_li !='')
                                        {
                                        	$img_3 .='<div class="col-sm-3"><img src="'.$project_images_url.'" alt=""><button type="button" data-value="'.$project_images_li.'" class="btn btn-danger button_image" style="height:37px;margin:2%;">Delete</button></div>';

                                        }
  			                            



									}
								} 

							?>
								<div class="col-lg-4 col-sm-6 col-md-4 col-xl-3">
							<div class="card">
								<div class="card-body">
									<div class="dropdown dropdown-action profile-action">
										<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>
										<div class="dropdown-menu dropdown-menu-right">
											<a 


											
												data-project_id="<?= $project_values->project_id?>"

												data-project_name="<?= $project_values->project_name?>"

												data-project_code="<?= $project_values->project_code?>"

												data-project_cliend_company_name="<?= $project_values->project_cliend_company_name?>"

												data-project_start_date="<?= date('d/m/Y', strtotime($project_values->project_start_date))?>"

												data-project_end_date="<?= date('d/m/Y', strtotime($project_values->project_end_date))?>"

												data-project_project_rate="<?= $project_values->project_project_rate?>"

												data-project_cost_based="<?= $project_values->project_cost_based?>"

												data-project_priority="<?= $project_values->project_priority?>"

												data-project_leaders="<?= implode(',',$project_leaders); ?>"

												data-project_members="<?= implode(',',$project_members);?>"

												data-project_image_names="<?= implode(',',$project_images);?>"

											

												data-project_images="<?= $project_values->project_images?>"



											class="dropdown-item edit_client_model" href="#" data-toggle="modal" data-target="#edit_project"><i class="fa fa-pencil m-r-5"></i> Edit</a>
											<div id="hidden_description_<?= $project_values->project_id?>" style="display:none;"><?= $project_values->project_description?></div>

											<div id="hidden_img1_<?= $project_values->project_id?>" style="display:none;"><?=$img_1?></div>
											<div id="hidden_img2_<?= $project_values->project_id?>" style="display:none;"><?=$img_2?></div>

											<div id="hidden_img3_<?= $project_values->project_id?>" style="display:none;"><?=$img_3?></div>

										
											
											<a class="dropdown-item delete_client_model" 

											data-project_id="<?= $project_values->project_id?>"

											href="#" data-toggle="modal" data-target="#delete_project"><i class="fa fa-trash-o m-r-5"></i> Delete</a>
										</div>
									</div>
									<h4 class="project-title"><a href="<?php echo site_url('admin_dashboard/project_view/'.$project_values->project_id); ?>"><?=$project_values->project_name?></a></h4>
									 
									<p class="text-muted"><?=substr($project_values->project_description,0,140).'...'?>
									</p>
									<div class="pro-deadline m-b-15">
										<div class="sub-title">
											Deadline:
										</div>
										<div class="text-muted">
											<?=date('d M Y', strtotime($project_values->project_end_date))?>
										</div>
									</div>
									<div class="project-members m-b-15">
										 
									 
									</div>
									<div class="project-members m-b-15">
										<div>Team :</div>
										<ul class="team-members">

											<?php
											$extra_member ='';
											if(!empty($project_members))
											{   
												$i=0;
												$extra_member ='';
												$count = 0;
												foreach ($project_members as $project_members_li) 
												{  
													$i=$i+1;

													if($i<6)
													{
														$get_user = $this->nlp_model->select_order('users',array('user_id'=>$project_members_li));


													 $pl_img = (($get_user->num_rows()>0) && ($get_user->row()->profile_picture !='')) 

													? $get_user->profile_picture:'avatar.jpg'; 

							                      
 							                        $pl_img =base_url().'images/profiles/thumb/'.$pl_img; 

 							                        $name = $get_user->row()->user_fname." ".$get_user->row()->user_lname;

													echo '<li><a href="'.site_url().'admin_dashboard/profile/'.$project_leaders_li.'" data-toggle="tooltip" title="'.$name.'"><img alt="" src="'.$pl_img.'"></a></li>';

													}
													else
													{   
														$count = $count+1;

														$extra_member.= '<a class="avatar avatar-xs" href="'.site_url().'admin_dashboard/profile/'.$project_leaders_li.'" title="'.$name.'"><img alt="" src="'.$pl_img.'"></a>';

													}
                                                  
													
												}
												if($count>0)
											     {
												?>

												 
											     	

											   

												<li class="dropdown avatar-dropdown">
												<a href="#" class="all-users dropdown-toggle" data-toggle="dropdown" aria-expanded="false">+<?=$count?></a>
												<div class="dropdown-menu dropdown-menu-right">
													<div class="avatar-group">

														<?=$extra_member?>
													
													</div>
													<div class="avatar-pagination">
														<ul class="pagination">
															<li class="page-item">
																<a class="page-link" href="#" aria-label="Previous">
																	<span aria-hidden="true">«</span>
																	<span class="sr-only">Previous</span>
																</a>
															</li>
															<li class="page-item"><a class="page-link" href="#">1</a></li>
															<li class="page-item"><a class="page-link" href="#">2</a></li>
															<li class="page-item">
																<a class="page-link" href="#" aria-label="Next">
																	<span aria-hidden="true">»</span>
																<span class="sr-only">Next</span>
																</a>
															</li>
														</ul>
													</div>
												</div>
											</li>



												<?php
												  }
											} 
											?>




										
											
										</ul>
									</div>
									 
									 
									<div class="row ">
										<div class="col col-md-12 col-lg-12">
									<a href="<?php echo site_url(); ?>admin_dashboard/tasks/<?=$project_values->project_id?>" class="btn btn-white btn-sm m-t-10 col-md-12">Tasks</a>
								</div>
								<!--<div class="col col-md-6 col-lg-12">
											<a href="<?php echo site_url(); ?>admin_dashboard/task_board/<?=$project_values->project_id?>" class="btn btn-white btn-sm m-t-10">Task Board</a></div>--> </div>
								</div>
							</div>
						</div>

                            <?php
							}

						}
						?>


						
					</div>