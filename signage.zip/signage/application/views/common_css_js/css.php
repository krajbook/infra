
		<!-- Favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url(); ?>assets\img\faviconbg.png">
		
		<!-- Bootstrap CSS -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets\css\multi-select.css">
        
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets\css\bootstrap.min.css">
		
		<!-- Fontawesome CSS -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets\css\font-awesome.min.css">
		
		<!-- Lineawesome CSS -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets\css\line-awesome.min.css">
		
		<!-- Select2 CSS -->
		<link rel="stylesheet" href="<?php echo base_url(); ?>assets\css\select2.min.css">
		
		<!-- Datetimepicker CSS -->
		<link rel="stylesheet" href="<?php echo base_url(); ?>assets\css\bootstrap-datetimepicker.min.css">

		<link rel="stylesheet" href="<?php echo base_url(); ?>assets\css\jquery.datetimepicker.css">

			<!-- Tagsinput CSS -->
		<link rel="stylesheet" href="<?php echo base_url(); ?>assets\plugins\bootstrap-tagsinput\bootstrap-tagsinput.css">
		
		<!-- Summernote CSS -->
		<link rel="stylesheet" href="<?php echo base_url(); ?>assets\plugins\summernote\dist\summernote-bs4.css">

			<!-- Datatable CSS -->
		<link rel="stylesheet" href="<?php echo base_url(); ?>assets\css\dataTables.bootstrap4.min.css">
		
		<!-- Main CSS -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets\css\style.css">

		
		<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!--[if lt IE 9]>
			<script src="<?php echo base_url(); ?>assets/js/html5shiv.min.js"></script>
			<script src="<?php echo base_url(); ?>assets/js/respond.min.js"></script>
		<![endif]-->

	<style type="text/css">
		.error {
  color: #F00;
  background-color: #FFF;
}
	</style>
		
	
	