<?php $active_bar = $this->session->userdata('active_menu'); ?>


  <!-- Sidebar -->
            <div class="sidebar" id="sidebar">
                <div class="sidebar-inner slimscroll">
          <div class="sidebar-menu">
            <ul>
              <li> 
                <a href="<?php echo base_url(); ?>"><i class="la la-home"></i> <span>Back to Home</span></a>
              </li>
              <li class="menu-title">Projects <a href="#" data-toggle="modal" data-target="#create_project"><i class="fa fa-plus"></i></a></li>

              <?php 

              if(count($projects_list)>0)
              {
                foreach ($projects_list as $key => $projects_list_values) 
                { 

                  $active =($projects_list_values->project_id==$project->project_id) ? 'active':'';

                  echo '<li class="'.$active.'"> 
                              <a href="'.base_url().'admin_dashboard/tasks/'.$projects_list_values->project_id.'">'.$projects_list_values->project_name.'</a>
                        </li>';
                  
                }

              }
                ?>
              
            </ul>
          </div>
                </div>
            </div>
      <!-- /Sidebar -->