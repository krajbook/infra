<!-- Create Project Modal -->
				<div id="create_project" class="modal custom-modal fade" role="dialog">
					<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
						<div class="modal-content">
							<div class="modal-header">
								<h5 class="modal-title">Create Project</h5>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>
							<div class="modal-body">
								<form method="post" id="add_project_form" enctype="multipart/form-data">

                                 <div class="row">
										<div class="col-sm-12">
											<div class="form-group">
												<label>Project Name</label>
												<input class="form-control" type="text" name="project_name" id="project_name" required>
											</div>
										</div>
										
									</div>



									<div class="row">
										<div class="col-sm-6">
											<div class="form-group">
												<label>Project Code</label>
												<input class="form-control" type="text" name="project_code" id="project_code" required>
											</div>
										</div>

										<div class="col-sm-6">
											<div class="form-group">
												<label>Client</label>
												<select class="select" name="cliend_company_name" id="cliend_company_name" required>
													<?php 
 													 if(!empty($clients))
 													 {
 								    foreach ($clients as $clients_values) 
 									{ 
 													      
 								        echo '<option value="'.$clients_values->client_id.'">'
 													 		.$clients_values->company_name.'</option>';
 													 	}
 													 }
 													 ?>
												</select>
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-sm-6">
											<div class="form-group">
												<label>Start Date</label>
												<div class="cal-icon">
													<input class="form-control datetimepicker" type="text" name="start_date" id="start_date" required>
												</div>
											</div>
										</div>
										<div class="col-sm-6">
											<div class="form-group">
												<label>End Date</label>
												<div class="cal-icon">
													<input class="form-control datetimepicker" type="text" name="end_date" id="end_date" required>
												</div>
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-sm-3">
											<div class="form-group">
												<label>Rate</label>
												<input placeholder="" class="form-control" type="text" name="project_rate" id="project_rate">
											</div>
										</div>
										<div class="col-sm-3">
											<div class="form-group">
												<label>&nbsp;</label>
												<select class="select" name="cost_based" id="cost_based">
													<option value="hourly">Hourly</option>
													<option value="fixed">Fixed</option>
												</select>
											</div>
										</div>
										<div class="col-sm-6">
											<div class="form-group">
												<label>Priority</label>
												<select class="select" name="priority" id="priority" required>
													<option value="high">High</option>
													<option value="medium">Medium</option>
													<option value="low">Low</option>
												</select>
											</div>
										</div>
									</div>
									 
									<div class="row">
										<div class="col-sm-6">
											<div class="form-group">
												<label>Add Team</label>
												<!-- <input class="form-control" type="text"> -->
												<select multiple="" 
 													class="searchable" id="project_members"
 													 name="project_members[]" style="position: absolute; left: -9999px;" required>

 													 <?php 
 													 if(!empty($employees))
 													 {
 													 	foreach ($employees as $employees_values) 
 													 	{ $img =($employees_values->profile_picture !='') 
 													      ? $employees_values->profile_picture:'avatar.jpg'; 
 													      $img =base_url().'images/profiles/'.$img; 
 								echo '<option class="prommem" 

 								data-imgs_show="'.$img.'" 

 								data-check_class="member" 

 								data-user_id="'.$employees_values->user_id.'" 

 								data-user_name="'.$employees_values->user_login_name.'" 


 								value="'.$employees_values->user_id.'">'
 													 		.$employees_values->user_fname.' '.$employees_values->user_lname.'</option>';
 													 	}
 													 }
 													 ?>
											         
											        
         												</select>
											</div>
										</div>
										<div class="col-sm-6">
											<div class="form-group">
												<label>Team Members</label>
												<div class="project-members" id="show_project_member">
													<!-- <a href="#" data-toggle="tooltip" title="John Doe" class="avatar">
														<img src="<?php echo base_url(); ?>assets\img\profiles\avatar-16.jpg" alt="">
													</a> -->
													<!-- <a href="#" data-toggle="tooltip" title="Richard Miles" class="avatar">
														<img src="<?php echo base_url(); ?>assets\img\profiles\avatar-09.jpg" alt="">
													</a>
													<a href="#" data-toggle="tooltip" title="John Smith" class="avatar">
														<img src="<?php echo base_url(); ?>assets\img\profiles\avatar-10.jpg" alt="">
													</a>
													<a href="#" data-toggle="tooltip" title="Mike Litorus" class="avatar">
														<img src="<?php echo base_url(); ?>assets\img\profiles\avatar-05.jpg" alt="">
													</a> -->
													<!-- <span class="all-team">+2</span> -->
												</div>
											</div>
										</div>
									</div>
									<div class="form-group">
										<label>Description</label>
										<textarea rows="4" id="project_description" name="project_description"  class="form-control summernote" placeholder="Enter your message here"></textarea>
									</div>
									<div class="form-group">
										<label>Upload Files</label>
										<input class="form-control" type="file" name="files[]" id="files" multiple>
									</div>
									<div class="submit-section">
										<button class="btn btn-primary submit-btn">Submit</button>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
				<!-- /Create Project Modal -->
				
				<!-- Edit Project Modal -->
				<div id="edit_project" class="modal custom-modal fade" role="dialog">
					<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
						<div class="modal-content">
							<div class="modal-header">
								<h5 class="modal-title">Edit Project</h5>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>
							<div class="modal-body">
								<form method="post" id="edit_project_form" enctype="multipart/form-data">

									<input class="form-control" type="hidden" name="edit_project_id" id="edit_project_id">

									 <div class="row">
										<div class="col-sm-12">
											<div class="form-group">
												<label>Project Name</label>
												<input class="form-control" type="text" name="edit_project_name" id="edit_project_name" required>
											</div>
										</div>
										
									</div>

									
									<div class="row">
										<div class="col-sm-6">
											<div class="form-group">
												<label>Project code</label>
												<input class="form-control" type="text" name="edit_project_code" id="edit_project_code" required>
											</div>
										</div>
										<div class="col-sm-6">
											<div class="form-group">
												<label>Client</label>
												<select class="select" name="edit_cliend_company_name" id="edit_cliend_company_name" required>
													<?php 
 													 if(!empty($clients))
 													 {
 								    foreach ($clients as $clients_values) 
 									{ 
 													      
 								        echo '<option value="'.$clients_values->client_id.'">'
 													 		.$clients_values->company_name.'</option>';
 													 	}
 													 }
 													 ?>
												</select>
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-sm-6">
											<div class="form-group">
												<label>Start Date</label>
												<div class="cal-icon">
													<input class="form-control datetimepicker" type="text" name="edit_start_date" id="edit_start_date" required>
												</div>
											</div>
										</div>
										<div class="col-sm-6">
											<div class="form-group">
												<label>End Date</label>
												<div class="cal-icon">
													<input class="form-control datetimepicker" type="text" name="edit_end_date" id="edit_end_date" required>
												</div>
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-sm-3">
											<div class="form-group">
												<label>Rate</label>
												<input placeholder="" class="form-control" type="text" name="edit_project_rate" id="edit_project_rate">
											</div>
										</div>
										<div class="col-sm-3">
											<div class="form-group">
												<label>&nbsp;</label>
												<select class="select" name="edit_cost_based" id="edit_cost_based">
													<option value="hourly">Hourly</option>
													<option value="fixed">Fixed</option>
												</select>
											</div>
										</div>
										<div class="col-sm-6">
											<div class="form-group">
												<label>Priority</label>
												<select class="select" name="edit_priority" id="edit_priority" required>
													<option value="high">High</option>
													<option value="medium">Medium</option>
													<option value="low">Low</option>
												</select>
											</div>
										</div>
									</div>
									 
									<div class="row">
										<div class="col-sm-6">
											<div class="form-group">
												<label>Add Team</label>
												<!-- <input class="form-control" type="text"> -->
												<select multiple="" 
 													class="searchable" id="edit_project_members"
 													 name="edit_project_members[]" style="position: absolute; left: -9999px;" required>

 													 <?php 
 													 if(!empty($employees))
 													 {
 													 	foreach ($employees as $employees_values) 
 													 	{ $img =($employees_values->profile_picture !='') 
 													      ? $employees_values->profile_picture:'avatar.jpg'; 
 													      $img =base_url().'images/profiles/'.$img; 
 								echo '<option class="edit_prommem" 

 								data-imgs_show="'.$img.'" 

 								data-check_class="edit_member" 

 								data-user_id="'.$employees_values->user_id.'" 

 								data-user_name="'.$employees_values->user_login_name.'" 


 								value="'.$employees_values->user_id.'">'
 													 		.$employees_values->user_fname.' '.$employees_values->user_lname.'</option>';
 													 	}
 													 }
 													 ?>
											         
											        
         												</select>
											</div>
										</div>
										<div class="col-sm-6">
											<div class="form-group">
												<label>Team Members</label>
												<div class="edit_project-members" id="edit_show_project_member">
													<!-- <a href="#" data-toggle="tooltip" title="John Doe" class="avatar">
														<img src="<?php echo base_url(); ?>assets\img\profiles\avatar-16.jpg" alt="">
													</a> -->
													<!-- <a href="#" data-toggle="tooltip" title="Richard Miles" class="avatar">
														<img src="<?php echo base_url(); ?>assets\img\profiles\avatar-09.jpg" alt="">
													</a>
													<a href="#" data-toggle="tooltip" title="John Smith" class="avatar">
														<img src="<?php echo base_url(); ?>assets\img\profiles\avatar-10.jpg" alt="">
													</a>
													<a href="#" data-toggle="tooltip" title="Mike Litorus" class="avatar">
														<img src="<?php echo base_url(); ?>assets\img\profiles\avatar-05.jpg" alt="">
													</a> -->
													<!-- <span class="all-team">+2</span> -->
												</div>
											</div>
										</div>
									</div>
									<div class="form-group">
										<label>Description</label>
										<textarea rows="4" id="edit_project_description" name="edit_project_description"  class="form-control summernote" placeholder="Enter your message here"></textarea>
									</div>
									<div class="form-group">
										<label>Upload Files</label>
										<input class="form-control" type="file" name="files[]" id="files" multiple>
										<input class="form-control" type="hidden" name="edit_files" id="edit_files">

										
									</div>
                                    <div class="form-group">
                                    	<div id="edit_project_image_show" class="row">



                                    	</div>
                                    </div>
									
									<div class="submit-section">
										<button class="btn btn-primary submit-btn">Submit</button>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
				<!-- /Edit Project Modal -->
				
				<!-- Delete Project Modal -->
				<div class="modal custom-modal fade" id="delete_project" role="dialog">
					<div class="modal-dialog modal-dialog-centered">
						<div class="modal-content">
							<div class="modal-body">
								<div class="form-header">
									<h3>Delete Project</h3>
									<p>Are you sure want to delete?</p>
								</div>
								<div class="modal-btn delete-action">
									<div class="row">
										<div class="col-6">
											<a id="comform_delete" href="javascript:void(0);" class="btn btn-primary continue-btn">Delete</a>
											<input type="hidden" name="hidden_delete" id="hidden_delete">
										</div>
										<div class="col-6">
											<a href="javascript:void(0);" data-dismiss="modal" class="btn btn-primary cancel-btn">Cancel</a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- /Delete Project Modal -->