  <script type="text/javascript">

	$(".js-select2").select2();

	$(document).on("change", "#assign", function (event) 
    {  
	
    	var url="<?php echo base_url().'admin_dashboard/profile/';?>"+$("#assign option:selected").data('user_id');

    	var string ='<a title="'+$("#assign option:selected").data('user_name')+'" data-placement="top" data-toggle="tooltip" href="'+url+'" class="avatar"><img src="'+$("#assign option:selected").data('imgs_show')+'" alt=""></a>';  

    	$('#show_ticket_assignee').html(string); 
	
    });
        
    $(document).ready(function() 
    {

        $('.summernote1').summernote({ height:150});


    });

    $('#add_ticket_form').validate(
    {
  				
  				rules:
  				{ 
  					ticket_id: 'required',

  					assign: 'required',

                },
                

				 
				messages: 
				{ 
					ticket_id: 'The Ticket Id is required',

					assign: 'The Assign is required',
				},
				submitHandler: function(forms,event)
				{

				   event.preventDefault(); 

				    var ticket_read_staus = $('#ticket_read_staus').val();

				    if(ticket_read_staus=='yes')
				    {
				    	
				    	$('#client').prop('disabled', false);

				        $('#tproject_id').prop('disabled', false);

				    }

				   
				    $.ajax({
					            type: "POST",

					            dataType: "json",
					            
					            url: "<?php echo site_url().'ticketsController/ajax_add_tickets'; ?>",

					            data: new FormData($('#add_ticket_form')[0]),
        						cache: false,
        						contentType: false,
        						processData: false,
					            
					            success: function(data)
					            {
					            	if(ticket_read_staus=='yes')
				    				{
				    	
				    	            	$('#client').prop('disabled', true);
					            		$('#tproject_id').prop('disabled', true);

				    				}

					            	

					                //alert(data.status); console.log(data); return false;
					                if(data.status =='1')
					                {    

					                    swal("Success!", "Tickets Details Added Successfully","success").then( () => {
                                    
                                         location.reload(); }).fadeOut(3000);

					                }
					                else if(data.status =='0')
					                {    

					                    swal("Warning!", "Tickets No Is  Already Exits","error").then( () => {
                                    
                                          });

					                }
					                else
					                {

					                    swal("Failed!", "Try Again Later.", "error");
					                    
					                    $( '#add_ticket_form' ).each(function()
					                    {
					                                

					                    });

					                        	

					                }
					            
					            }
		                  }); 
				}
	});

    $('#edit_ticket_form').validate(
	{ 
  				
  				rules:
  				{ 
  					edit_ticket_id: 'required',

  					edit_assign:'required'
                },
				 
				messages: 
				{ 
					edit_ticket_id: 'The Ticket Id is required',
				},
				submitHandler: function(forms,event)
				{

				   event.preventDefault(); 


				   var ticket_read_staus = $('#ticket_read_staus').val();

				    if(ticket_read_staus=='yes')
				    {
				    	
				    	$('#client').prop('disabled', false);

				        $('#tproject_id').prop('disabled', false);

				    }




				    $.ajax({
					            type: "POST",

					             dataType: "json",
					            
					            url: "<?php echo site_url().'ticketsController/ajax_edit_tickets'; ?>",

					            data: new FormData($('#edit_ticket_form')[0]),
        						cache: false,
        						contentType: false,
        						processData: false,
					            
					            success: function(data)
					            {  

                                   
                                    if(ticket_read_staus=='yes')
				    				{
				    	
				    	                $('#edit_client').prop('disabled', true);
					            	    
					            	    $('#edit_tproject_id').prop('disabled', true);

				    				}

					                

					            	//alert(data); console.log(data); return false;

					                if(data.status =='1')
					                {    

					                    swal("Success!", "Ticket Details Updated Successfully","success").then( () => {
                                    
                                         location.reload(); }).fadeOut(3000);

					                }
					                else
					                {

					                    swal("Failed!", "Try Again Later.", "error");
					                    
					                    $( '#edit_ticket_form' ).each(function()
					                    {
					                                

					                    });

					                        	

					                }
					            
					            }
		                  }); 
				}
	});


	$(document).ready(function()
	{
   				
   				$('#tickets_datatable').DataTable({
       				"processing": true,
        		    "serverSide": true,
       				"ajax": "<?php echo site_url().'ticketscontroller/json_tickets_list';?>",
       				"columnDefs": [
    			        {
							"aTargets":[7],
							"fnCreatedCell": function(nTd, sData, oData, iRow, iCol)
							{

								$(nTd).addClass('text-center');
							}
				
						},
						{

							"aTargets":[8],
							"fnCreatedCell": function(nTd, sData, oData, iRow, iCol)
							{

								$(nTd).addClass('text-right');
							}
				
						}



  				]

			    });
	});



    $('#assign_ticket').click(function() 
    {  

    		$.ajax({
					            type: "POST",
					            dataType: "json",
					            url: "<?php echo site_url().'admin_dashboard/ticket_no'; ?>",
					            data:{'project_id':''},
					            success: function(data)
					            {

					            	//console.log(data);  return false;  return false;

					                $('#ticket_id').val(data.ticket_no);
					                
					            }
		                  }); 

    	
    });

    $('#tproject_id').change(function() 
    {  

    		$.ajax({
					            type: "POST",
					            dataType: "json",
					            url: "<?php echo site_url().'admin_dashboard/ticket_no'; ?>",
					            data:{'project_id':$('#tproject_id').val()},
					            success: function(data)
					            {

					            	//console.log(data);  return false;  return false;

					                $('#ticket_id').val(data.ticket_no);
					                
					            }
		                  });
    	
    });



    $('.searchable').multiSelect(
    {
            selectableHeader: "<input type='text' class='search-input' autocomplete='off' placeholder='search...'>",
            selectionHeader: "<input type='text' class='search-input' autocomplete='off' placeholder='search...'>",
  			
  			afterInit: function(ms)
  			{
    			var that = this,
		        $selectableSearch = that.$selectableUl.prev(),
		        $selectionSearch = that.$selectionUl.prev(),
		        selectableSearchString = '#'+that.$container.attr('id')+' .ms-elem-selectable:not(.ms-selected)',
		        selectionSearchString = '#'+that.$container.attr('id')+' .ms-elem-selection.ms-selected';

    			that.qs1 = $selectableSearch.quicksearch(selectableSearchString)
			    .on('keydown', function(e)
			    {
			       if (e.which === 40)
			       {
				        that.$selectableUl.focus();
				        return false;
			        }
                });

                that.qs2 = $selectionSearch.quicksearch(selectionSearchString)
                .on('keydown', function(e)
                {
	                if (e.which == 40)
	                {
		                that.$selectionUl.focus();
		                return false;
	                }
                });
            },
  			afterSelect: function()
  			{
			    this.qs1.cache();
			    this.qs2.cache();   
			},
  			afterDeselect: function()
  			{
    			this.qs1.cache();
    			this.qs2.cache();
    			
  			}
	});
	$(document).on("click", ".add_foll", function (event) 
    {
				
		var inputs = $(".ms-selected");
		
		var string  ='';
		
		$('#show_ticket_followers').html('');

		var arr = []; 

	    var check_id=[];
			    
	    for(var i = 1; i < inputs.length; i++)
	    {
			    	
			img = $(inputs[i]).data('imgs_show');

            var arr1=[];
            
            if($(inputs[i]).data('user_id') !='' && $(inputs[i]).data('check_class')=='followers')
            {
                    	
                if(check_id.includes($(inputs[i]).data('user_id')))
                {
                  
                }
                else
                {
                    
                    check_id.push($(inputs[i]).data('user_id'));
                    arr1['user_id']  = $(inputs[i]).data('user_id');
                    arr1['user_image'] = $(inputs[i]).data('imgs_show');
                    arr1['user_name']  = $(inputs[i]).data('user_name');
                    arr.push(arr1);
                }
            }
			    			   
		}

		arr.forEach(function(element) 
		{

			var url = "<?php echo base_url().'admin_dashboard/profile/'?>";

  			string ='<a title="'+element['user_name']+'" data-toggle="tooltip" href="'+url+element['user_id']+'" class="avatar"><img src="'+element['user_image']+'" alt=""></a>'+string;


                
        });
        
        $('#show_ticket_followers').html(string);	

	});


    $(document).on("click", ".change_task_priority", function () 
	{

			    swal({
					    title: "Are you sure?",
					    text: "Change Task Priority",
					    icon: "warning",
					    buttons: true,
					    dangerMode: true,
					})
						.then((willDelete) => 
						{
						    if (willDelete) 
						    {

						    	var task_priority_status = $(this).data('task_priority_status');

						    	var ticket_ins_id        = $(this).data('ticket_ins_id');

						    	$.ajax({
					            type: "POST",
					            //dataType: "json",
					            url: "<?php echo site_url().'ticketsController/change_task_priority'; ?>",
					            data:{'task_priority_status':task_priority_status,'ticket_ins_id':ticket_ins_id},
					            success: function(data)
					            {

					            	//console.log(data);  alert(data);  return false;

					            	if(data=='1')
					            	{
					            		$('#tickets_datatable').DataTable().ajax.reload();

					            		  swal("Ticket Task Priority Changes Done.", {
								      icon: "success",
								    });

					            	}

					               
					                
					            }
		                  }); 
                                
	                             
	                           
                                  

								  
						    } 
						    else
						    {
								    swal("Ticket Task Priority Changes Cancelled");
						    }
						});


	}); 

    $(document).on("click", ".change_task_board_status", function () 
	{

			    swal({
					    title: "Are you sure?",
					    text: "Change Task Board Status",
					    icon: "warning",
					    buttons: true,
					    dangerMode: true,
					})
						.then((willDelete) => 
						{
						    if (willDelete) 
						    {

						    	var ticket_ins_id = $(this).data('ticket_ins_id');

						    	var task_board_status        = $(this).data('task_board_status');

						    	$.ajax({
					            type: "POST",
					            //dataType: "json",
					            url: "<?php echo site_url().'ticketsController/ajax_change_task_board_status'; ?>",
					            data:{'ticket_ins_id':ticket_ins_id,'task_board_status':task_board_status},
					            success: function(data)
					            {

					            	//console.log(data);  alert(data);  return false;

					            	if(data=='1')
					            	{
					            		$('#tickets_datatable').DataTable().ajax.reload();

					            		  swal("Ticket Task Status Changes Done.", {
								      icon: "success",
								    });

					            	}

					               
					                
					            }
		                  }); 
                                
	                             
	                           
                                  

								  
						    } 
						    else
						    {
								    swal("Ticket Task Status Changes Cancelled");
						    }
						});


	}); 

	$(document).on("click", ".edit_ticket_model", function (event) 
    {  

    	var  task_ticket_id=$(this).data('task_ticket_id');


    	$.ajax({
					            type: "POST",
					            dataType: "json",
					            url: "<?php echo site_url().'ticketscontroller/ajax_get_ticket'; ?>",
					            data:{'task_ticket_id':task_ticket_id},
					            success: function(data)
					            { 
					            	//console.log(data);

					            	if(data.status=='1')
					            	{

					            	$('#edit_task_id').val(data.task_id);

					            	$('#edit_id').val(data.task_ticket_id);

					            	$('#edit_tproject_id').val(data.project_id); 
                                    
                                    $('#edit_tproject_id').trigger('change');

                                    $('#edit_ticket_id').val(data.ticket_id);

                                    $('#edit_ticket_subject').val(data.task_subject);

                                    $('#edit_client').val(data.client); 
                                    
                                    $('#edit_client').trigger('change');

                                    $('#edit_assign_staff').val(data.task_asign_by); 
                                    
                                    $('#edit_assign_staff').trigger('change');

                                    $('#edit_task_priority').val(data.task_priority); 
                                    
                                    $('#edit_task_priority').trigger('change');

                                    $('#edit_assign').val(data.task_assign); 
                                    
                                    $('#edit_assign').trigger('change');

                                    $('#edit_due_date').val(data.ticket_due_date); 

                                   
                                    var url="<?php echo base_url().'admin_dashboard/profile/';?>"+data.task_assign;

    			                   var string ='<a title="'+data.task_assign_name+'" data-placement="top" data-toggle="tooltip" href="'+url+'" class="avatar"><img src="'+data.task_assign_pic+'" alt=""></a>';  

    			                   $('#edit_show_ticket_assignee').html(string); 

    			                  //console.log(data);

    			                    $('#edit_add_followers').multiSelect('select',data.task_followers);

    			                    $('#edit_show_ticket_followers').html(data.task_followers_pic);

    			                    //$('#edit_tdescription').summernote('code','data.task_description');

    			                    $("#edit_tdescription").summernote("code", data.task_description);

                                    $('#edit_show_upload_files').html(data.task_file_html);

    			                    $('#edit_files').val(data.task_files);


    			                    $('#edit_ticket_subject_btn').prop('disabled',false);


    			                }

					            }
		          }); 
    });
    $(document).on("click", ".delete_ticket_model", function (event) 
    {  

    		var  task_ticket_id=$(this).data('task_ticket_id');

    		$('#hidden_delete').val(task_ticket_id);

    		
    });

    $(document).on("click", "#comform_delete", function () 
	{
					
					
		$.ajax({
						    type: "POST",
						    
						    url: "<?php echo site_url().'ticketsController/ajax_delete_tickets'; ?>",
						    
						    data: {'task_ticket_id':$("#hidden_delete").val()}, 
						    
						    success: function(data)
						    {
						    	alert(data);
						        if(data =='1')
						        {    

						        	 $( ".close" ).click();


                                    swal("Success!", "Ticket Details Deleted Successfully","success").then( () => {

                                    
                                         location.reload(); });
						                              
						        }
						        else
						        {

						            swal("Failed!", "Try Again Later.", "error");
						                           
						        }
						    }
			            });


	});

    $(document).on("click", ".files_delete", function () 
	{

			    swal({
					    title: "Are you sure?",
					    text: "Comfirm Delete",
					    icon: "warning",
					    buttons: true,
					    dangerMode: true,
					})
						.then((willDelete) => 
						{
						    if (willDelete) 
						    {
	                             
	                            Array.prototype.remove = function() 
	                            {
										    var what, a = arguments, L = a.length, ax;
										    while (L && this.length) {
										        what = a[--L];
										        while ((ax = this.indexOf(what)) !== -1) {
										            this.splice(ax, 1);
										        }
										    }
										    return this;
								};

	                               var all_img = $('#edit_files').val();

	                               var str_arr = all_img.split(',');
						            str_arr.remove($(this).data('img_name'));

						            $('#edit_files').val(str_arr.toString());

						            $(this).parent().fadeOut(300);

								    swal("Poof! Your Tasks Image file has been deleted!", {
								      icon: "success",
								    });
						    } 
						    else
						    {
								    swal("Your image file is safe!");
						    }
						});


	});




</script>