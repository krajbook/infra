<?php $active_bar = $this->session->userdata('active_menu'); ?>
	       
  <!-- /Header -->
  <div class="header">

     <!-- Logo -->

    <div class="header-left">

      <a href="<?php echo base_url(); ?>" class="logo">
        
      <img src="<?php echo base_url(); ?>assets/images/b2.png"   height="35px" alt=""> 
      
      </a>
    
    </div>
    
    <!-- /Logo -->
        
    <a id="toggle_btn" href="javascript:void(0);">
          <span class="bar-icon">
            <span></span>
            <span></span>
            <span></span>
          </span>
    </a>
        
    <!-- Header Title -->
    
    <div class="page-title-box"> <h3>Thynkk</h3> </div>
    
    <!-- /Header Title -->
        
        <a id="mobile_btn" class="mobile_btn" href="#sidebar"><i class="fa fa-bars"></i></a>
        
        <!-- Header Menu -->
        <ul class="nav user-menu">
        
          <!-- Search -->
           
          <!-- /Search -->
        
          <!-- Flag -->
          <!-- <li class="nav-item dropdown has-arrow flag-nav">
            <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button">
              <img src="<?php echo base_url(); ?>assets\img\flags\us.png" alt="" height="20"> <span>English</span>
            </a>
            <div class="dropdown-menu dropdown-menu-right">
              <a href="javascript:void(0);" class="dropdown-item">
                <img src="<?php echo base_url(); ?>assets\img\flags\us.png" alt="" height="16"> English
              </a>
              <a href="javascript:void(0);" class="dropdown-item">
                <img src="<?php echo base_url(); ?>assets\img\flags\fr.png" alt="" height="16"> French
              </a>
              <a href="javascript:void(0);" class="dropdown-item">
                <img src="<?php echo base_url(); ?>assets\img\flags\es.png" alt="" height="16"> Spanish
              </a>
              <a href="javascript:void(0);" class="dropdown-item">
                <img src="<?php echo base_url(); ?>assets\img\flags\de.png" alt="" height="16"> German
              </a>
            </div>
          </li> -->
          <!-- /Flag -->

          
          <!-- Flag -->
          <li class="nav-item dropdown has-arrow flag-nav">
            <a href="<?php echo site_url();?>developer_dashboard/attendance_employee" class="dropdown-item">
               Clock In / Out
              </a>
          </li>
          <!-- /Flag -->
        <?php $todo = $this->nlp_model->select('todo',array('status'=>1,'todo_date >='=>date('Y-m-d')));
		  
			?>
          <!-- Notifications -->
          <li class="nav-item dropdown">
            <a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown">
              <i class="fa fa-bell-o"></i> <span class="badge badge-pill"><?php echo $todo->num_rows(); ?></span>
            </a>
           <div class="dropdown-menu notifications">
              <div class="topnav-dropdown-header">
                <span class="notification-title">Todays Todo</span>
                
              </div>
              <div class="noti-content">
                <ul class="notification-list">
				<?php if($todo->num_rows() > 0 ) { foreach($todo->result() as $td) {  ?>
                  <li class="notification-message">
                    <a href="<?php echo base_url(); ?>home/todo_inbox/today">
                      <div class="media">
                         
                        <div class="media-body">
                          <p class="noti-details"><span class="noti-title"><?php echo $td->todo_name ?></span></p> 
                        </div>
                      </div>
                    </a>
                  </li>
                  <?php } }?>
                </ul>
              </div>
              <div class="topnav-dropdown-footer">
                 
              </div>
            </div>
          </li>
          <!-- /Notifications --> 
          
          <!-- /Message Notifications -->

          <li class="nav-item dropdown has-arrow main-drop">
            <a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown">
              <span class="user-img"><img src="<?php echo base_url(); ?>assets\img\profiles\avatar-21.jpg" alt="">
              <span class="status online"></span></span>
              <span><?= $this->session->userdata('user_name'); ?></span>
            </a>
            <div class="dropdown-menu">
               
              <a class="dropdown-item"href="<?php echo base_url(); ?>login/logout">Logout</a>

            </div>
          </li>
        </ul>
        <!-- /Header Menu -->
        
        <!-- Mobile Menu -->
        <div class="dropdown mobile-user-menu">
          <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
          <div class="dropdown-menu dropdown-menu-right">
            <a class="dropdown-item" href="<?php echo site_url(); ?>admin_dashboard/profile">My Profile</a>
            <a class="dropdown-item" href="<?php echo site_url(); ?>admin_dashboard/settings">Settings</a>
            <a class="dropdown-item"href="<?php echo base_url(); ?>login/logout">Logout</a>
          </div>
        </div>
        <!-- /Mobile Menu -->
        
  </div>
  <!-- /Header -->
      
  <!-- Sidebar -->
  <div class="sidebar" id="sidebar">

                <div class="sidebar-inner slimscroll">
          <div id="sidebar-menu" class="sidebar-menu">
            <ul>
              <li class="menu-title"> 
                <span>Main</span>
              </li>
              <li class="submenu">
                <a href="#"><i class="la la-dashboard"></i> <span> Dashboard</span> <span class="menu-arrow"></span></a>
                <ul style="display: none;">
                  <li><a class="active" href="<?php echo base_url(); ?>">Admin Dashboard</a></li>
                  <!-- <li><a href="<?php echo site_url(); ?>admin_dashboard/employee_dashboard">Employee Dashboard</a></li> -->
                </ul>
              </li>
              <li class="menu-title"> 
                <span>Employees</span>
              </li>
              <li class="submenu">
                <a href="#" class="noti-dot"><i class="la la-user"></i> <span> Employees</span> <span class="menu-arrow"></span></a>
                <ul style="display: none;">
                  <li><a href="<?php echo site_url(); ?>admin_dashboard/employees">All Employees</a></li>
                 <!--  <li><a href="<?php echo site_url(); ?>admin_dashboard/holidays">Holidays</a></li> -->
                  <li><a href="<?php echo site_url(); ?>admin_dashboard/leaves">Leaves (Admin) <span class="badge badge-pill bg-primary float-right">1</span></a></li>
                 <!--  <li><a href="<?php echo site_url(); ?>admin_dashboard/leaves_employee">Leaves (Employee)</a></li> -->
                 <!--  <li><a href="<?php echo site_url(); ?>admin_dashboard/leave_settings">Leave Settings</a></li> -->
                  <li><a href="<?php echo site_url(); ?>admin_dashboard/attendance">Attendance (Admin)</a></li>
                   <li><a href="<?php echo site_url(); ?>admin_dashboard/attendance_in_out_time">Attendance Time(Admin)</a></li>
                <!--   <li><a href="<?php echo site_url(); ?>admin_dashboard/attendance_employee">Attendance (Employee)</a></li> -->
                   <li><a href="<?php echo site_url(); ?>admin_dashboard/departments">Departments</a></li>
                  <li><a href="<?php echo site_url(); ?>admin_dashboard/designations">Designations</a></li>
                 <!-- <li><a href="<?php echo site_url(); ?>admin_dashboard/timesheet">Timesheet</a></li>
                  <li><a href="<?php echo site_url(); ?>admin_dashboard/overtime">Overtime</a></li> -->
                </ul>
              </li>
              <li> 
                <a href="<?php echo site_url(); ?>admin_dashboard/clients"><i class="la la-users"></i> <span>Clients</span></a>
              </li>
              <li class="submenu">
                <a href="#"><i class="la la-rocket"></i> <span> Projects</span> <span class="menu-arrow"></span></a>
                <ul style="display: none;">
                  <li><a href="<?php echo site_url(); ?>admin_dashboard/projects">Projects</a></li>
                  <li><a href="<?php echo site_url(); ?>admin_dashboard/tasks">Tasks</a></li>
                  <li><a href="<?php echo site_url(); ?>admin_dashboard/tasks">Task Board</a></li>
                </ul>
              </li>
              <li> 
                <a href="<?php echo site_url(); ?>admin_dashboard/leads"><i class="la la-user-secret"></i> <span>Leads</span></a>
              </li>
              <li> 
                <a href="<?php echo site_url(); ?>admin_dashboard/tickets"><i class="la la-ticket"></i> <span>Tickets</span></a>
              </li>
       
            </ul>
          </div>
                </div>
  </div>