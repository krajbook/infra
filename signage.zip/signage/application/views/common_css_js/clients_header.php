<div class="page-header">
						<div class="row align-items-center">
							<div class="col">
								<h3 class="page-title">Apps</h3>
								<ul class="breadcrumb">
									<li class="breadcrumb-item"><a href="<?php echo base_url(); ?>">Dashboard</a></li>
									<li class="breadcrumb-item active">Apps</li>
								</ul>
							</div>
							<div class="col-auto float-right ml-auto">
								<a href="#" class="btn add-btn" data-toggle="modal" data-target="#add_client"><i class="fa fa-plus"></i> Custom App</a>
								 
							</div>
						</div>
					</div>