 <script>
     
    $(document).ready(function()
    {
      	$('.searchable').multiSelect(
      	{
            selectableHeader: "<input type='text' class='form-control' autocomplete='off' placeholder='search...'><br>",
            selectionHeader: "<input type='text' class='form-control' autocomplete='off' placeholder='search...'><br>",
  			
  			afterInit: function(ms)
  			{
    			var that = this,
		        $selectableSearch = that.$selectableUl.prev(),
		        $selectionSearch = that.$selectionUl.prev(),
		        selectableSearchString = '#'+that.$container.attr('id')+' .ms-elem-selectable:not(.ms-selected)',
		        selectionSearchString = '#'+that.$container.attr('id')+' .ms-elem-selection.ms-selected';

    			that.qs1 = $selectableSearch.quicksearch(selectableSearchString)
			    .on('keydown', function(e)
			    {
			       if (e.which === 40)
			       {
				        that.$selectableUl.focus();
				        return false;
			        }
                });

                that.qs2 = $selectionSearch.quicksearch(selectionSearchString)
                .on('keydown', function(e)
                {
	                if (e.which == 40)
	                {
		                that.$selectionUl.focus();
		                return false;
	                }
                });
            },
  			afterSelect: function()
  			{
			    this.qs1.cache();
			    this.qs2.cache();   
			},
  			afterDeselect: function()
  			{
    			this.qs1.cache();
    			this.qs2.cache();
    			
  			}
		});

		$('.searchable').multiSelect(
      	{
            selectableHeader: "<input type='text' class='search-input' autocomplete='off' placeholder='search...'>",
            selectionHeader: "<input type='text' class='search-input' autocomplete='off' placeholder='search...'>",
  			
  			afterInit: function(ms)
  			{
    			var that = this,
		        $selectableSearch = that.$selectableUl.prev(),
		        $selectionSearch = that.$selectionUl.prev(),
		        selectableSearchString = '#'+that.$container.attr('id')+' .ms-elem-selectable:not(.ms-selected)',
		        selectionSearchString = '#'+that.$container.attr('id')+' .ms-elem-selection.ms-selected';

    			that.qs1 = $selectableSearch.quicksearch(selectableSearchString)
			    .on('keydown', function(e)
			    {
			       if (e.which === 40)
			       {
				        that.$selectableUl.focus();
				        return false;
			        }
                });

                that.qs2 = $selectionSearch.quicksearch(selectionSearchString)
                .on('keydown', function(e)
                {
	                if (e.which == 40)
	                {
		                that.$selectionUl.focus();
		                return false;
	                }
                });
            },
  			afterSelect: function()
  			{
			    this.qs1.cache();
			    this.qs2.cache();
			},
  			afterDeselect: function()
  			{
    			this.qs1.cache();
    			this.qs2.cache();
    			
  			}
		});
	
	
    });
    $(document).on("click", ".yess", function (event) 
    {
				
		var inputs = $(".ms-selected");
		
		var string  ='';
		
		$('#project_members_img').html('');

		var arr = []; 

	    var check_id=[];
			    
	    for(var i = 1; i < inputs.length; i++)
	    {
			    	
			img = $(inputs[i]).data('imgs_show');

            var arr1=[];
            
            if($(inputs[i]).data('user_id') !='' && $(inputs[i]).data('check_class')=='leader')
            {
                    	
                if(check_id.includes($(inputs[i]).data('user_id')))
                {
                  
                }
                else
                {
                    
                    check_id.push($(inputs[i]).data('user_id'));
                    arr1['user_id']  = $(inputs[i]).data('user_id');
                    arr1['user_image'] = $(inputs[i]).data('imgs_show');
                    arr1['user_name']  = $(inputs[i]).data('user_name');
                    arr.push(arr1);
                }
            }
			    			   
		}

		arr.forEach(function(element) 
		{

			var url = "<?php echo base_url().'admin_dashboard/profile/'?>";

  			string ='<a href="'+url+element['user_id']+'" data-toggle="tooltip" title="'+element['user_name']+'" class="avatar"><img src="'+element['user_image']+'" alt=""></a>'+string;
                
        });
        
        $('#project_members_img').html(string);	

	});
	$(document).on("click", ".add_foll", function (event) 
    {
				
		var inputs = $(".ms-selected");
		
		var string  ='';
		
		$('#show_ticket_followers').html('');

		var arr = []; 

	    var check_id=[];
			    
	    for(var i = 1; i < inputs.length; i++)
	    {
			    	
			img = $(inputs[i]).data('imgs_show');

            var arr1=[];
            
            if($(inputs[i]).data('user_id') !='' && $(inputs[i]).data('check_class')=='followers')
            {
                    	
                if(check_id.includes($(inputs[i]).data('user_id')))
                {
                  
                }
                else
                {
                    
                    check_id.push($(inputs[i]).data('user_id'));
                    arr1['user_id']  = $(inputs[i]).data('user_id');
                    arr1['user_image'] = $(inputs[i]).data('imgs_show');
                    arr1['user_name']  = $(inputs[i]).data('user_name');
                    arr.push(arr1);
                }
            }
			    			   
		}

		arr.forEach(function(element) 
		{

			var url = "<?php echo base_url().'admin_dashboard/profile/'?>";

  			string ='<a title="'+element['user_name']+'" data-toggle="tooltip" href="'+url+element['user_id']+'" class="avatar"><img src="'+element['user_image']+'" alt=""></a>'+string;


                
        });
        
        $('#show_ticket_followers').html(string);	

	});

	 $(document).on("click", ".prommem", function (event) 
    {
				
		var inputs = $(".ms-selected");
		
		var string  ='';
		
		$('#show_project_member').html('');

		var arr = []; 

	    var check_id=[];
			    
	    for(var i = 1; i < inputs.length; i++)
	    {
			    	
			img = $(inputs[i]).data('imgs_show');

            var arr1=[];
            
            if($(inputs[i]).data('user_id') !='' && $(inputs[i]).data('check_class')=='member')
            {
                    	
                if(check_id.includes($(inputs[i]).data('user_id')))
                {
                  
                }
                else
                {
                    
                    check_id.push($(inputs[i]).data('user_id'));
                    arr1['user_id']  = $(inputs[i]).data('user_id');
                    arr1['user_image'] = $(inputs[i]).data('imgs_show');
                    arr1['user_name']  = $(inputs[i]).data('user_name');
                    arr.push(arr1);
                }
            }
			    			   
		}

		arr.forEach(function(element) 
		{

			var url = "<?php echo base_url().'admin_dashboard/profile/'?>";

  			string ='<a href="'+url+element['user_id']+'" data-toggle="tooltip" title="'+element['user_name']+'" class="avatar"><img src="'+element['user_image']+'" alt=""></a>'+string;
                
        });
        
        $('#show_project_member').html(string);	

	});

	 //edit
	  $(document).on("click", ".edit_yess", function (event) 
    {
				
		var inputs = $(".ms-selected");
		
		var string  ='';
		
		$('#edit_project_members_img').html('');

		var arr = []; 

	    var check_id=[];
			    
	    for(var i = 1; i < inputs.length; i++)
	    {
			    	
			img = $(inputs[i]).data('imgs_show');

            var arr1=[];
            
            if($(inputs[i]).data('user_id') !='' && $(inputs[i]).data('check_class')=='edit_leader')
            {
                    	
                if(check_id.includes($(inputs[i]).data('user_id')))
                {
                  
                }
                else
                {
                    
                    check_id.push($(inputs[i]).data('user_id'));
                    arr1['user_id']  = $(inputs[i]).data('user_id');
                    arr1['user_image'] = $(inputs[i]).data('imgs_show');
                    arr1['user_name']  = $(inputs[i]).data('user_name');
                    arr.push(arr1);
                }
            }
			    			   
		}

		arr.forEach(function(element) 
		{

			var url = "<?php echo base_url().'admin_dashboard/profile/'?>";

  			string ='<a href="'+url+element['user_id']+'" data-toggle="tooltip" title="'+element['user_name']+'" class="avatar"><img src="'+element['user_image']+'" alt=""></a>'+string;
                
        });
        
        $('#edit_project_members_img').html(string);	

	});

	 $(document).on("click", ".edit_prommem", function (event) 
    {
				
		var inputs = $(".ms-selected");
		
		var string  ='';
		
		$('#edit_show_project_member').html('');

		var arr = []; 

	    var check_id=[];
			    
	    for(var i = 1; i < inputs.length; i++)
	    {
			    	
			img = $(inputs[i]).data('imgs_show');

            var arr1=[];
            
            if($(inputs[i]).data('user_id') !='' && $(inputs[i]).data('check_class')=='edit_member')
            {
                    	
                if(check_id.includes($(inputs[i]).data('user_id')))
                {
                  
                }
                else
                {
                    
                    check_id.push($(inputs[i]).data('user_id'));
                    arr1['user_id']  = $(inputs[i]).data('user_id');
                    arr1['user_image'] = $(inputs[i]).data('imgs_show');
                    arr1['user_name']  = $(inputs[i]).data('user_name');
                    arr.push(arr1);
                }
            }
			    			   
		}

		arr.forEach(function(element) 
		{

			var url = "<?php echo base_url().'admin_dashboard/profile/'?>";

  			string ='<a href="'+url+element['user_id']+'" data-toggle="tooltip" title="'+element['user_name']+'" class="avatar"><img src="'+element['user_image']+'" alt=""></a>'+string;
                
        });
        
        $('#edit_show_project_member').html(string);	

	});

	 $(document).on("click", ".edit_client_model", function (event) 
     {

		    	$('#edit_project_id').val($(this).data('project_id'));
		    	$('#edit_project_name').val($(this).data('project_name'));
		    	$('#edit_project_code').val($(this).data('project_code'));
				$('#edit_cliend_company_name').val($(this).data('project_cliend_company_name'));
				$('#edit_start_date').val($(this).data('project_start_date'));
				$('#edit_end_date').val($(this).data('project_end_date'));
				$('#edit_project_rate').val($(this).data('project_project_rate'));
				$('#edit_priority').val($(this).data('project_priority'));

				 $('select[name=edit_cost_based]').val($(this).data('project_cost_based'));
                 var cost_based = $("#edit_cost_based option[value="+$(this).data('project_cost_based')+"]").text();
                 $('#select2-edit_cost_based-container').text(cost_based);

                 $('select[name=edit_priority]').val($(this).data('project_priority'));
                 var cost_based = $("#edit_priority option[value="+$(this).data('project_priority')+"]").text();
                 $('#select2-edit_priority-container').text(cost_based);

                 var string1 = $(this).data('project_leaders').toString();
                 var array1 = string1.split(",");
                 
                 $('#edit_project_leaders').multiSelect('select',array1);

                 var string2 = $(this).data('project_members').toString();
                 var array2 = string2.split(",");
                 
                 $('#edit_project_members').multiSelect('select',array2);

                 $('#edit_project_description').summernote('code',$('#hidden_description_'+$(this).data('project_id')).html());

                 $('#edit_project_members_img').html($('#hidden_img1_'+$(this).data('project_id')).html());
                 $('#edit_show_project_member').html($('#hidden_img2_'+$(this).data('project_id')).html());
                 $('#edit_project_image_show').html($('#hidden_img3_'+$(this).data('project_id')).html());


                 $('#edit_files').val($(this).data('project_image_names'));

                

                 






                 //hidden_description_
                 //hidden_project_leader_ hidden_img1_


				//$('#edit_project_leaders').val($(this).data('project_leaders'));
				//$('#edit_project_members_img').val($(this).data('project_leaders'));
				//$('#edit_project_members').val($(this).data('project_members'));
				//$('#edit_show_project_member').val($(this).data('project_members'));
				//$('#edit_project_description').val($(this).data('project_description'));
				
				/*$('#files').val($(this).data('company_address'));
				$('#edit_profile_pic_show').attr('src',$(this).data('profile_image_show'));*/


    });



		

            $('#add_project_form').validate({
  				
  				rules:
  				{ 
  					project_name: 'required',
                },
				 
				messages: 
				{ 
					project_name: 'The Project Name is required',
				},
				submitHandler: function(forms,event)
				{

				   event.preventDefault(); 

				    $.ajax({
					            type: "POST",
					            
					            url: "<?php echo site_url().'projectsController/ajax_add_projects'; ?>",

					            data: new FormData($('#add_project_form')[0]),
        						cache: false,
        						contentType: false,
        						processData: false,
					            
					            success: function(data)
					            {

					                //alert(data); console.log(data); return false;
					                if(data =='1')
					                {    

					                    swal("Success!", "Projects Details Added Successfully","success").then( () => {
                                    
                                         location.reload(); }).fadeOut(3000);

					                }
					                else
					                {

					                    swal("Failed!", "Try Again Later.", "error");
					                    
					                    $( '#add_project_form' ).each(function()
					                    {
					                                

					                    });

					                        	

					                }
					            
					            }
		                  }); 
				}
			});

			$('#edit_project_form').validate(
			{
  				
  				rules:
  				{ 
  					edit_project_name: 'required',
                },
				 
				messages: 
				{ 
					edit_project_name: 'The Project Name is required',
				},
				submitHandler: function(forms,event)
				{

				   event.preventDefault(); 

				    $.ajax({
					            type: "POST",
					            
					            url: "<?php echo site_url().'projectsController/ajax_edit_projects'; ?>",

					            data: new FormData($('#edit_project_form')[0]),
        						cache: false,
        						contentType: false,
        						processData: false,
					            
					            success: function(data)
					            {

					                //alert(data); console.log(data); return false;
					                if(data =='1')
					                {    

					                    swal("Success!", "Projects Details Updated Successfully","success").then( () => {
                                    
                                         location.reload(); }).fadeOut(3000);

					                }
					                else
					                {

					                    swal("Failed!", "Try Again Later.", "error");
					                    
					                    $( '#edit_project_form' ).each(function()
					                    {
					                                

					                    });

					                        	

					                }
					            
					            }
		                  }); 
				}
			});

			$(document).on("click", ".delete_client_model", function (event) 
    		{

   	 			$("#hidden_delete").val($(this).data('project_id'));
    
    		});

    		$(document).on("click", "#comform_delete", function () 
			{
					
					
			    $.ajax({
						    type: "POST",
						    
						    url: "<?php echo site_url().'projectsController/ajax_delete_projects'; ?>",
						    
						    data: {'projects_id':$("#hidden_delete").val()}, 
						    
						    success: function(data)
						    {
						        if(data =='1')
						        {    

						           /* swal("Success!", "client Deleted  Deleted Successfully", "success");

						            $('#clients_model_hide_'+$("#hidden_delete").val()).hide();

                                    $(".cancel-btn").click();*/

                                    swal("Success!", "Projects Details Deleted Successfully","success").then( () => {
                                    
                                         location.reload(); });
						                              
						        }
						        else
						        {

						            swal("Failed!", "Try Again Later.", "error");
						                           
						        }
						    }
			            });


			});

			$(document).on("click", ".button_image", function () 
			{

			    swal({
					    title: "Are you sure?",
					    text: "Comfirm Delete",
					    icon: "warning",
					    buttons: true,
					    dangerMode: true,
					})
						.then((willDelete) => 
						{
						    if (willDelete) 
						    {
	                             
	                            Array.prototype.remove = function() 
	                            {
										    var what, a = arguments, L = a.length, ax;
										    while (L && this.length) {
										        what = a[--L];
										        while ((ax = this.indexOf(what)) !== -1) {
										            this.splice(ax, 1);
										        }
										    }
										    return this;
								};

	                               var all_img = $('#edit_files').val();

	                               var str_arr = all_img.split(',');
						            str_arr.remove($(this).data('value'));

						            $('#edit_files').val(str_arr.toString());

						            $(this).parent().fadeOut(300);

								    swal("Poof! Your Project Image file has been deleted!", {
								      icon: "success",
								    });
						    } 
						    else
						    {
								    swal("Your image file is safe!");
						    }
						});


			});

			
			

			

	</script>