<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
        <meta name="description" content="Smarthr - Bootstrap Admin Template">
		<meta name="keywords" content="">
        <meta name="author" content="">
        <meta name="robots" content="noindex, nofollow">
        <title>Dashboard</title>
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets\css\bootstrap.min.css">
		
		<!-- Fontawesome CSS -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets\css\font-awesome.min.css">
		
		<!-- Lineawesome CSS -->
		<link rel="stylesheet" href="<?php echo base_url(); ?>assets\css\line-awesome.min.css">
		
		<!-- Datatable CSS -->
		<link rel="stylesheet" href="<?php echo base_url(); ?>assets\css\dataTables.bootstrap4.min.css">
		
		<!-- Select2 CSS -->
		<link rel="stylesheet" href="<?php echo base_url(); ?>assets\css\select2.min.css">
		
		<!-- Datetimepicker CSS -->
		<link rel="stylesheet" href="<?php echo base_url(); ?>assets\css\bootstrap-datetimepicker.min.css">
		
		<!-- Main CSS -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets\css\style.css">
		
		<?php $this->load->view('common/css'); ?>
    </head>
	
    <body>
		
		<!-- Main Wrapper -->
        <div class="main-wrapper">
        	<?php $this->load->view('common/set_header'); ?>
			<!-- Header -->
        <?php $this->load->view('common_css_js/side_header'); ?>
			<!-- /Sidebar -->
				<!-- Page Wrapper -->
            <div class="page-wrapper" >
			
				<!-- Page Content -->
                <div class="content container-fluid">
				
					<!-- Page Header -->
					<div class="page-header">
						<div class="row align-items-center">
							<div class="col">
								<h3 class="page-title">Display</h3>
								<ul class="breadcrumb">
									<li class="breadcrumb-item"><a href="<?php echo base_url(); ?>">Dashboard</a></li>
									<li class="breadcrumb-item active">Add Display</li>
								</ul>
							</div>
							<div class="col-auto float-right ml-auto">
								<a href="#" class="btn add-btn" data-toggle="modal" data-target="#add_asset"><i class="fa fa-plus"></i> Add Display</a>
								
							</div>
							<ul class="navbar-nav">
            
             <li class="dropdown">
                <a  data-toggle="dropdown">
                <img src="<?php echo base_url(); ?>assets\img\icon-dot.webp" style="height: 30px;width: 30px">
                </a>
                <div class="dropdown-menu dropdown-menu-right" >
                <!-- <form id="Form1" method="post" runat="server">  onclick="JavaScript: hideContent();"-->
                  <a class="dropdown-item" href="#"><input type="radio">&nbsp;Deactive screens</a>
                  <a class="dropdown-item" href="#"><input type="radio">&nbsp;Current schedule</a>
                  <a class="dropdown-item" href="#"><input type="radio">&nbsp;Last seen online</a>
                  <a class="dropdown-item" href="#"><input type="radio">&nbsp;Network status</a>
                  <a class="dropdown-item" href="#"><input type="radio">&nbsp;Groups</a>
                <!-- </form> -->
                </div>
              </li>
            </ul>
						</div>
						
					</div>
					<!-- /Page Header -->
				
                </div>
               
                <!-- Search Filter -->
             
					<div class="row filter-row"  id="mainContent">
					   <div class="col-sm-6 col-md-3 col-lg-3 col-xl-1 col-12">  
							<div class="form-group form-focus">
							</div>
					   </div>
					   <div class="col-sm-6 col-md-3 col-lg-3 col-xl-2 col-12">  
							<div class="form-group form-focus select-focus">
							</div>
					   </div>
					   <div class="col-sm-6 col-md-3 col-lg-3 col-xl-6 col-12"> 
							<div class="form-group form-focus select-focus">
								<img src="<?php echo base_url(); ?>assets\img\screen.svg" >

								<p style="text-align: center">Connect your display to Signage device and install Digital Signage player to add display</p>
								<p style="text-align: center">signage players</p>
							</div>
					   </div>
					   <div class="col-sm-6 col-md-3 col-lg-3 col-xl-2 col-12">  
							<div class="form-group form-focus">
							</div>
						</div>
					   <div class="col-sm-6 col-md-3 col-lg-3 col-xl-1 col-12">  
							<div class="form-group form-focus">
							</div>
						</div>     
                    </div>
					<!-- /Search Filter -->
                        

				<!-- /Page Content -->
			
				<!-- Add Asset Modal -->
				<div id="add_asset" class="modal custom-modal fade" role="dialog">
					<div class="modal-dialog modal-md" role="document">
						<div class="modal-content">
							<div class="modal-header">
								<h5 class="modal-title">Add Display</h5>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>
							<div class="modal-body">
								<form>
									<div class="row">
										<div class="col-md-12">
											<div class="form-group" align="center">
												<img src="<?php echo base_url(); ?>assets\img\add-display.png">
											</div>
										</div>
								
												
										<div class="col-md-12">
											<div class="form-group">
												<p style="text-align: center">Enter registration code as shown on the display </p>
												<label>Code</label>
												<input class="form-control" type="text">
											</div>
										</div>
									</div>
									
									<div class="modal-btn delete-action">
									<div class="row">
										<div class="col-6">
											<a href="javascript:void(0);" data-dismiss="modal" class="btn btn-primary cancel-btn">Close</a>
										</div>
										<div class="col-6">
											<a href="javascript:void(0);" data-dismiss="modal" class="btn btn-primary cancel-btn">Add</a>
										</div>
									</div>
								</div>
								</form>
							</div>
							</div>
						</div>
					</div>
				</div>
				<!-- /Add Asset Modal -->
				
				<!-- Leave Statistics -->
					<div class="row" align="center">
						<div class="col-md-1"></div>
						<div class="col-md-1"></div>
						<div class="col-md-1">
						</div>
						<div class="col-md-1">
							
						</div>
						<div class="col-md-1">
						   
						</div>
						<div class="col-md-1">
							<div class="stats-info">
								<img src="<?php echo base_url(); ?>assets\img\amazon.png"><br/><a href="#">Amazon</a>
						    </div>
						</div>
						<div class="col-md-1">
							 <div class="stats-info">
								<img src="<?php echo base_url(); ?>assets\img\chrome.png"><br/><a href="#">Chrome</a>
							</div>
						</div>
						<div class="col-md-1">
                            <div class="stats-info"><img src="<?php echo base_url(); ?>assets\img\android.png"><br/><a href="#">Android</a></div>
						</div>
						<div class="col-md-1">
                          <div class="stats-info">
							<img src="<?php echo base_url(); ?>assets\img\lg.png"><br/><a href="#">WebOS</a></div>
						</div>
						<div class="col-md-1"></div>
						<div class="col-md-1"></div>
					</div>
					<!-- /Leave Statistics -->
				
				
				
            </div>
			<!-- /Page Wrapper -->
			
        </div>
		<!-- /Main Wrapper -->
		
		<?php $this->load->view('common/footer_js'); ?>
		
    </body>
    <script type="text/javascript">
	  <!--
	  function hideContent() {
	    document.getElementById('mainContent').style.display = 'none';
	  }

	  function showContent() {
	    document.getElementById('mainContent').style.display = 'block';
	  }
	  // -->
	</script>
</html>