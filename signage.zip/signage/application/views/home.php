<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
        <meta name="description" content="Smarthr - Bootstrap Admin Template">
		<meta name="keywords" content="admin, estimates, bootstrap, business, corporate, creative, management, minimal, modern, accounts, invoice, html5, responsive, CRM, Projects">
        <meta name="author" content="Dreamguys - Bootstrap Admin Template">
        <meta name="robots" content="noindex, nofollow">
        <title>Dashboard - Admin</title>
		
		<?php $this->load->view('common/css'); ?>
    </head>
	
    <body>
		<!-- Main Wrapper -->
        <div class="main-wrapper">
		<?php $this->load->view('common/set_header'); ?>
			<!-- Header -->
            <?php $this->load->view('common_css_js/side_header'); ?>
			<!-- /Sidebar -->
			
			<!-- Page Wrapper -->
            <div class="page-wrapper">
			
				<!-- Page Content -->
                <div class="content container-fluid">
				
					<!-- Page Header -->
					<div class="page-header">
						<div class="row">
							<div class="col-sm-12">
								<h3 class="page-title">Welcome Back!</h3>
								<ul class="breadcrumb">
									<li class="breadcrumb-item active">Dashboard</li>
								</ul>
							</div>
						</div>
					</div>
					<!-- /Page Header -->  
					
					 
					
					<div class="row">
						<div class="col-md-12 d-flex">
							<div class="card card-table flex-fill">
								<div class="card-header">
									<h3 class="card-title mb-0">Todo List</h3>
								</div>
								<div class="card-body">
									<div class="table-responsive">
										<table class="table custom-table mb-0">
											<thead>
												<tr>
													<th>Todo</th>
													<th>Due Date</th>
													<th>Assigned to</th>
													<th>Status</th>
													 
												</tr>
											</thead>
											<tbody>
											<?php if($todo->num_rows() > 0 ) { 
											foreach($todo->result() as $td) { ?>
												<tr>
													<td><?php echo $td->todo_name ?> </td>
													<td><?php echo date('d M Y, h:i A',strtotime($td->todo_date)); ?>  </td>
													<td> <?php echo $td->user_fname.' '.$td->user_lname; ?></td>
													<td>
														 <a class="btn btn-white btn-sm" href="#" data-toggle="dropdown" aria-expanded="false">
															<?php if($td->task_status == 'completed') { ?>
																<i class="fa fa-dot-circle-o text-success"></i> Completed
																<?php } else { ?>
																<i class="fa fa-dot-circle-o text-danger"></i> Pending
																<?php } ?>
															</a>
													</td>
													 
												</tr>
												 <?php } } ?>
											 
											</tbody>
										</table>
									</div>
								</div>
								<div class="card-footer">
									<a href="<?php echo base_url(); ?>home/todo_inbox">View all Todo</a>
								</div>
							</div>
						</div>
						<div class="col-md-12 d-flex">
							<div class="card card-table flex-fill">
								<div class="card-header">
									<h3 class="card-title mb-0">Project Progress</h3>
								</div>
								<div class="card-body">
									<div class="table-responsive">
										<table class="table custom-table mb-0">
											<thead>
												<tr>
													<th>Project Name </th>
													<th>Progress</th>
													 
												</tr>
											</thead>
											<tbody>
<?php if($progress->num_rows() > 0 ) { 
											foreach($progress->result() as $pg) {
						$project[$pg->project_id]	= $pg->project_name;
						$task[$pg->project_id][] = $pg->task_status; 		
		}

foreach($project as $k=>$prj)		
{
$acv = array_count_values($task[$k]);											?>											
<tr>
<td>
<h2><a href="javascript::"> <?php echo $prj; ?></a></h2>
<small class="block text-ellipsis">
<span><?php if(isset($acv['pending'])) {  echo $p = $acv['pending']; } else { echo $p = 0; }?></span> <span class="text-muted">Pending tasks, </span>
<span><?php if(isset($acv['completed'])) {  echo $c = $acv['completed']; } else { echo $c = 0; }?></span> <span class="text-muted">tasks completed</span>
</small>
</td>
<td>
<div class="progress progress-xs progress-striped">
<?php $percnt = ($c*100)/$p; ?>
<div class="progress-bar" role="progressbar" data-toggle="tooltip" title="<?php echo $percnt ?>%" style="width: <?php echo $percnt ?>%"></div>
</div>
</td> 
</tr>
<?php } }    ?>												 
											</tbody>
										</table>
									</div>
								</div>
								<div class="card-footer">
									 
								</div>
							</div>
						</div>
					</div>
				
				</div>
				<!-- /Page Content -->

            </div>
			<!-- /Page Wrapper -->
			
        </div>
		<!-- /Main Wrapper -->
		
		<?php $this->load->view('common/footer_js'); ?>
		
    </body>
</html>