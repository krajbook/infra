<!doctype html>
<html lang="en" class="fullscreen-bg">

<head>
	<title>Forget Password</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  
	<!-- VENDOR CSS -->
    <link href="<?php echo base_url(); ?>assets/css/semantic.min.css" rel="stylesheet" type="text/css">
	<link href="<?php echo base_url(); ?>assets/css/auth.css" rel="stylesheet">

</head>

<body>
	<!-- WRAPPER -->
	<div id="wrapper">
		
		<div class="vertical-align-wrap">
			<div class="vertical-align-middle">
			   
				<div class="auth-box" style="background: #000;">
					<div class="content">
						 <div class="logo align-center">
					    	<img src="<?php echo base_url(); ?>assets/img/logo.png" alt="Digital Kart" width="200">
					    </div><br/>
						<div class="header">
							<p class="lead">Recover Account</p>
						</div>
													<!-- Account Form -->
							<form class="form-auth-small ui form" action="<?php echo site_url(); ?>login/forget_password" method="POST">
								<div class="row">
								<input type="hidden" name="_token" value="BZ49a6p5cZ2qWkfZ3TBVTyei7oDEuwCJuiC5Kn7Y">
							    
								<div class="form-group col-md-12">
									<label>Enter Register Email</label>
									<input class="form-control" type="email" name="email" required>
								</div>
								<div class="form-group text-center">
									<button class="ui green button large fluid cs-btn" style="background-color: #484848;" type="submit">Submit</button>
								</div>
								<div class="account-footer">
									<p>Remember password ? <a href="<?php echo base_url(); ?>login">Login</a></p>
								</div>
							</form>

						<?php if($msg = $this->session->flashdata('flash_message')) { echo $msg; } ?>
					</div>
				</div>
			</div>
		</div>
		
	</div>
	<!-- END WRAPPER -->

	<!--   Core JS Files   -->
    <script src="https://sirisigns.xyz/signage/assets/vendor/jquery/jquery-3.3.1.min.js"></script>
    <script src="https://sirisigns.xyz/signage/assets/vendor/semantic-ui/semantic.min.js"></script>
	<script>
		$('.ui.checkbox').checkbox('uncheck', 'toggle');
	</script>
</body>

<script>'undefined'=== typeof _trfq || (window._trfq = []);'undefined'=== typeof _trfd && (window._trfd=[]),_trfd.push({'tccl.baseHost':'secureserver.net'}),_trfd.push({'ap':'cpsh'},{'server':'sg3plcpnl0080'}) // Monitoring performance to make your website faster. If you want to opt-out, please contact web hosting support.</script>
<script src='https://img1.wsimg.com/tcc/tcc_l.combined.1.0.6.min.js'></script>
</html>