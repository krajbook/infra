﻿<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
        
        <title>Webscreen</title>
		
		<!-- Favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url(); ?>assets\img\faviconbg.png">
		
		<!-- Bootstrap CSS -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets\css\bootstrap.min.css">
		
		<!-- Fontawesome CSS -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets\css\font-awesome.min.css">
		
		<!-- Lineawesome CSS -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets\css\line-awesome.min.css">
		
		<!-- Select2 CSS -->
		<link rel="stylesheet" href="<?php echo base_url(); ?>assets\css\select2.min.css">
		
		<!-- Datetimepicker CSS -->
		<link rel="stylesheet" href="<?php echo base_url(); ?>assets\css\bootstrap-datetimepicker.min.css">
		
		<!-- Datatable CSS -->
		<link rel="stylesheet" href="<?php echo base_url(); ?>assets\css\dataTables.bootstrap4.min.css">
		
		<!-- Main CSS -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets\css\style.css">
		
		<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!--[if lt IE 9]>
			<script src="<?php echo base_url(); ?>assets/js/html5shiv.min.js"></script>
			<script src="<?php echo base_url(); ?>assets/js/respond.min.js"></script>
		<![endif]-->
    </head>
    <body>

		<?php print_r($json); if($json[0]->template == 'temp_4') {?>
		<div class="row">
			
		 <div class="col-md-12" style="position: absolute; top: 0px; left: 3px; width: 100%; height: 50%; overall width 248px including 2*3px padding and 2*1px border:5">
            <?php if($json[0]->data[0]->type != 'Image'){ ?>
		 	<iframe type="text/html" style="width: 100%; height: 100%;" src="http://www.youtube.com/embed/M7lc1UVf-VE?autoplay=1&origin=<?php echo $json[0]->data[0]->src; ?>"></iframe>
		 <?php }else{?>
           <img height="320" width="700" src="<?php echo $json[0]->data[0]->src; ?>">
		 <?php } ?>
        </div>
        
		<div class="col-md-12" style="position: absolute; top: 0px; right: 3px; width: 100%; height: 50%; overall width 248px including 2*3px padding: 0px; border:5; display: block;justify-content: center;">
		<?php if($$json[0]->data[1]->type != 'Image') {?>	
			<iframe type="text/html" style="width: 100%; height: 100%;" src="http://www.youtube.com/embed/M7lc1UVf-VE?autoplay=1&origin=<?php echo $json[0]->data[1]->src; ?>"></iframe>
		 <?php }else{?>
           <img height="320" width="700" src="<?php echo $json[0]->data[1]->src; ?>">
		 <?php } ?>
        </div>
		</div>
		<?php } ?>
		<!-- jQuery -->
        <script src="<?php echo base_url(); ?>assets\js\jquery-3.2.1.min.js"></script>
		
		<!-- Bootstrap Core JS -->
        <script src="<?php echo base_url(); ?>assets\js\popper.min.js"></script>
        <script src="<?php echo base_url(); ?>assets\js\bootstrap.min.js"></script>
		
		<!-- Slimscroll JS -->
		<script src="<?php echo base_url(); ?>assets\js\jquery.slimscroll.min.js"></script>
				
		<!-- Select2 JS -->
		<script src="<?php echo base_url(); ?>assets\js\select2.min.js"></script>
		
		<!-- Datetimepicker JS -->
		<script src="<?php echo base_url(); ?>assets\js\moment.min.js"></script>
		<script src="<?php echo base_url(); ?>assets\js\bootstrap-datetimepicker.min.js"></script>
		
		<!-- Datatable JS -->
		<script src="<?php echo base_url(); ?>assets\js\jquery.dataTables.min.js"></script>
		<script src="<?php echo base_url(); ?>assets\js\dataTables.bootstrap4.min.js"></script>
		
		<!-- Custom JS -->
		<script src="<?php echo base_url(); ?>assets\js\app.js"></script>

    </body>
</html>