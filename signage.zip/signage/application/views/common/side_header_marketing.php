<?php $active_bar = $this->session->userdata('active_menu'); ?>

	       

   <!-- Sidebar -->

<div class="sidebar" id="sidebar">

  <div class="sidebar-inner slimscroll">

    <div id="sidebar-menu" class="sidebar-menu">

      <ul>

        <li class="menu-title"> <span>Main</span></li>

        <li class="submenu">

          <a href="#"><i class="la la-dashboard"></i> <span> Dashboard</span> <span class="menu-arrow"></span></a>

          <ul style="display: none;">

            <li><a class="active" href="<?php echo base_url(); ?>">Marketing Dashboard</a></li>

           
          </ul>

        </li>

        <li class="menu-title"> <span>Employees</span></li>

        <li class="submenu">

          <a href="#" class="noti-dot"><i class="la la-user"></i> <span> Employees</span> <span class="menu-arrow"></span></a>

          <ul style="display: none;">

            <li><a href="<?php echo base_url(); ?>marketing_dashboard/leaves_employee">Leaves (Employee)</a></li>

            <li><a href="<?php echo base_url(); ?>marketing_dashboard/attendance_employee">Attendance (Employee)</a></li>

          </ul>

        </li>

      </ul>

    </div>

  </div>

</div>