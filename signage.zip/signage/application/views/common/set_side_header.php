<?php 

    if($this->session->userdata('user_role')<=2)

    {

        $this->load->view('common/side_header_developer');



    } 

    else if($this->session->userdata('user_role')==3)

    {



        $this->load->view('common/side_header_marketing');

    }



            





?>