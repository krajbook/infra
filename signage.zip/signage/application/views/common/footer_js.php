<!-- jQuery -->
        <script src="<?php echo base_url(); ?>assets\js\jquery-3.2.1.min.js"></script>
		
		<!-- Bootstrap Core JS -->
        <script src="<?php echo base_url(); ?>assets\js\popper.min.js"></script>
        <script src="<?php echo base_url(); ?>assets\js\bootstrap.min.js"></script>
		
		<!-- Slimscroll JS -->
		<script src="<?php echo base_url(); ?>assets\js\jquery.slimscroll.min.js"></script>
		
		<!-- Chart JS -->
		<script src="<?php echo base_url(); ?>assets\plugins\morris\morris.min.js"></script>
		<script src="<?php echo base_url(); ?>assets\plugins\raphael\raphael.min.js"></script>
		<script src="<?php echo base_url(); ?>assets\js\chart.js"></script>
		
		<!-- Custom JS -->
		<script src="<?php echo base_url(); ?>assets\js\app.js"></script>