<?php $active_bar = $this->session->userdata('active_menu'); ?>

	       

<!-- Sidebar -->

<div class="sidebar" id="sidebar">

  <div class="sidebar-inner slimscroll">

    <div id="sidebar-menu" class="sidebar-menu">

      <ul>

        <li class="menu-title"> 

          <span>Main</span>

        </li>
        
        <li><a href="<?php echo base_url(); ?>"><i class="la la-dashboard"></i> <span> Dashboard</span></a></li> 


      </ul>

    </div>

  </div>

</div>