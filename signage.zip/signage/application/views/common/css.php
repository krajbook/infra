<!-- Favicon -->

        <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url(); ?>assets\img\faviconbg.png">

		

		<!-- Bootstrap CSS -->

        <link rel="stylesheet" href="<?php echo base_url(); ?>assets\css\bootstrap.min.css">

		

		<!-- Fontawesome CSS -->

        <link rel="stylesheet" href="<?php echo base_url(); ?>assets\css\font-awesome.min.css">

		

		<!-- Lineawesome CSS -->

        <link rel="stylesheet" href="<?php echo base_url(); ?>assets\css\line-awesome.min.css">

		

		<!-- Chart CSS -->

		<link rel="stylesheet" href="<?php echo base_url(); ?>assets\plugins\morris\morris.css">

		

		<!-- Main CSS -->

        <link rel="stylesheet" href="<?php echo base_url(); ?>assets\css\style.css">



        	<script src="<?php echo base_url(); ?>assets\js\sweetalert.min.js"></script>

		

		<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->

		<!--[if lt IE 9]>

			<script src="<?php echo base_url(); ?>assets/js/html5shiv.min.js"></script>

			<script src="<?php echo base_url(); ?>assets/js/respond.min.js"></script>

		<![endif]-->