<?php $active_bar = $this->session->userdata('active_menu'); ?>

	       

  <div class="header">

      

        <!-- Logo -->

                <div class="header-left">

                    <a href="<?php echo base_url(); ?>" class="logo">

            <img src="<?php echo base_url(); ?>assets\img\logo.png" width="40" height="40" alt="">

          </a>

                </div>

        <!-- /Logo -->

        

        <a id="toggle_btn" href="javascript:void(0);">

          <span class="bar-icon">

            <span></span>

            <span></span>

            <span></span>

          </span>

        </a>

        

        <!-- Header Title -->

                <div class="page-title-box">

          <h3>Dreamguy's Technologies</h3>

                </div>

        <!-- /Header Title -->

        

        <a id="mobile_btn" class="mobile_btn" href="#sidebar"><i class="fa fa-bars"></i></a>

        

        <!-- Header Menu -->

        <ul class="nav user-menu">

        

          <!-- Search -->

          <li class="nav-item">

            <div class="top-nav-search">

              <a href="javascript:void(0);" class="responsive-search">

                <i class="fa fa-search"></i>

               </a>

              <form action="<?php echo site_url(); ?>home/search">

                <input class="form-control" type="text" placeholder="Search here">

                <button class="btn" type="submit"><i class="fa fa-search"></i></button>

              </form>

            </div>

          </li>

          <!-- /Search -->

        

          <!-- Flag -->


          <!-- /Flag -->

        



          <li class="nav-item dropdown has-arrow main-drop">

            <a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown">

              <span class="user-img"><img src="<?php echo base_url(); ?>assets\img\profiles\avatar-21.jpg" alt="">

              <span class="status online"></span></span>

              <span>Admin</span>

            </a>

            <div class="dropdown-menu">

              <a class="dropdown-item" href="<?php echo base_url(); ?>home/profile">My Profile</a>

              <a class="dropdown-item" href="<?php echo base_url(); ?>home/settings">Settings</a>

              <a class="dropdown-item"href="<?php echo base_url(); ?>login/logout">Logout</a>

            </div>

          </li>

        </ul>

        <!-- /Header Menu -->

        

        <!-- Mobile Menu -->

        <div class="dropdown mobile-user-menu">

          <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>

          <div class="dropdown-menu dropdown-menu-right">

            <a class="dropdown-item" href="<?php echo base_url(); ?>home/profile">My Profile</a>

            <a class="dropdown-item" href="<?php echo base_url(); ?>home/settings">Settings</a>

            <a class="dropdown-item"href="<?php echo base_url(); ?>login/logout">Logout</a>

          </div>

        </div>

        <!-- /Mobile Menu -->

        

            </div>

      <!-- /Header -->

      

      <!-- Sidebar -->

            <div class="sidebar" id="sidebar">

                <div class="sidebar-inner slimscroll">

          <div id="sidebar-menu" class="sidebar-menu">

            <ul>

              <li class="menu-title"> 

                <span>Main</span>

              </li>

              <li class="submenu">

                <a href="#"><i class="la la-dashboard"></i> <span> Dashboard</span> <span class="menu-arrow"></span></a>

                <ul style="display: none;">

                  <li><a class="active" href="<?php echo base_url(); ?>">Admin Dashboard</a></li>

                  <li><a href="<?php echo base_url(); ?>home/employee_dashboard">Employee Dashboard</a></li>

                </ul>

              </li>




              <li> 

                <a href="<?php echo base_url(); ?>home/clients"><i class="la la-users"></i> <span>Clients</span></a>

              </li>

              <li> 

                <a href="<?php echo base_url(); ?>home/leads"><i class="la la-user-secret"></i> <span>Leads</span></a>

              </li>

              <li> 

                <a href="<?php echo base_url(); ?>home/tickets"><i class="la la-ticket"></i> <span>Tickets</span></a>

              </li>


          </div>

                </div>

            </div>