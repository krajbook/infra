<div class="header">
      
        <!-- Logo -->
                <div class="header-left auth-box" style="background: #000;">
                    <a href="<?php echo base_url(); ?>" class="logo">
            <img src="<?php echo base_url() ?>assets/img/logo.png" height="45px" alt="Digital Kart">
          </a>
                </div>
        <!-- /Logo -->
      <!--   
        <a id="toggle_btn" href="javascript:void(0);">
          <span class="bar-icon">
            <span></span>
            <span></span>
            <span></span>
          </span>
        </a> -->
        
        <!-- Header Title -->
                <div class="page-title-box">
           
                </div>
        <!-- /Header Title -->
        
        <a id="mobile_btn" class="mobile_btn" href="#sidebar"><i class="fa fa-bars"></i><img src="<?php echo base_url() ?>assets/img/logo.png" height="45px" alt="Digital Kart"></a>
        
        <!-- Header Menu -->
        <ul class="nav user-menu">
        
          <!-- Search -->
          <li class="nav-item">
            <div class="top-nav-search">
              <a href="javascript:void(0);" class="responsive-search">
                <i class="fa fa-search"></i>
               </a>
              <form action="<?php echo site_url(); ?>marketing_dashboard/search">
                <input class="form-control" type="text" placeholder="Search here">
                <button class="btn" type="submit"><i class="fa fa-search"></i></button>
              </form>
            </div>
          </li>
          <!-- /Search -->
        
          <li class="nav-item dropdown has-arrow main-drop">
            <a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown">
              <span class="user-img"><img src="<?php echo base_url(); ?>assets\img\profiles\avatar-21.jpg" alt="">
              <span class="status online"></span></span>
              <span><?= $this->session->userdata('user_name'); ?></span>
            </a>
            <div class="dropdown-menu">
              <a class="dropdown-item" href="<?php echo base_url(); ?>marketing_dashboard/profile">My Profile</a>
              <a class="dropdown-item" href="<?php echo base_url(); ?>marketing_dashboard/settings">Settings</a>
              <a class="dropdown-item"href="<?php echo base_url(); ?>login/logout">Logout</a>
            </div>
          </li>
        </ul>
        <!-- /Header Menu -->
        
        <!-- Mobile Menu -->
        <div class="dropdown mobile-user-menu">
          <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
          <div class="dropdown-menu dropdown-menu-right">
            <a class="dropdown-item" href="<?php echo base_url(); ?>marketing_dashboard/profile">My Profile</a>
            <a class="dropdown-item" href="<?php echo base_url(); ?>marketing_dashboard/settings">Settings</a>
            <a class="dropdown-item"href="<?php echo base_url(); ?>login/logout">Logout</a>
          </div>
        </div>
        <!-- /Mobile Menu -->
        
  </div>
      <!-- /Header -->