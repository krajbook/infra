<?php $active_bar = $this->session->userdata('active_menu'); ?>
	       
  <div class="header">
      
        <!-- Logo -->
                <div class="header-left">
                    <a href="<?php echo base_url(); ?>" class="logo">
            <img src="<?php echo base_url(); ?>assets\img\logo.png" width="40" height="40" alt="">
          </a>
                </div>
        <!-- /Logo -->
        
        <a id="toggle_btn" href="javascript:void(0);">
          <span class="bar-icon">
            <span></span>
            <span></span>
            <span></span>
          </span>
        </a>
        
        <!-- Header Title -->
                <div class="page-title-box">
          <h3>Thynkk</h3>
                </div>
        <!-- /Header Title -->
        
        <a id="mobile_btn" class="mobile_btn" href="#sidebar"><i class="fa fa-bars"></i></a>
        
        <!-- Header Menu -->
        <ul class="nav user-menu">
        
          <!-- Search -->
          <li class="nav-item">
            <div class="top-nav-search">
              <a href="javascript:void(0);" class="responsive-search">
                <i class="fa fa-search"></i>
               </a>
              <form action="<?php echo site_url(); ?>developer_dashboard/search">
                <input class="form-control" type="text" placeholder="Search here">
                <button class="btn" type="submit"><i class="fa fa-search"></i></button>
              </form>
            </div>
          </li>
          <!-- /Search -->
        
          <!-- Flag -->
          <li class="nav-item dropdown has-arrow flag-nav">
            <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button">
              <img src="<?php echo base_url(); ?>assets\img\flags\us.png" alt="" height="20"> <span>English</span>
            </a>
            <div class="dropdown-menu dropdown-menu-right">
              <a href="javascript:void(0);" class="dropdown-item">
                <img src="<?php echo base_url(); ?>assets\img\flags\us.png" alt="" height="16"> English
              </a>
              <a href="javascript:void(0);" class="dropdown-item">
                <img src="<?php echo base_url(); ?>assets\img\flags\fr.png" alt="" height="16"> French
              </a>
              <a href="javascript:void(0);" class="dropdown-item">
                <img src="<?php echo base_url(); ?>assets\img\flags\es.png" alt="" height="16"> Spanish
              </a>
              <a href="javascript:void(0);" class="dropdown-item">
                <img src="<?php echo base_url(); ?>assets\img\flags\de.png" alt="" height="16"> German
              </a>
            </div>
          </li>
          <!-- /Flag -->

           <li class="nav-item dropdown has-arrow flag-nav">
            <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button">
              <img src="<?php echo base_url(); ?>assets\img\flags\us.png" alt="" height="20"> <span>Quick Access</span>
            </a>
            <div class="dropdown-menu dropdown-menu-right">
              <a href="<?php echo site_url();?>home/clock_in_out" class="dropdown-item">
                <img src="<?php echo base_url(); ?>assets\img\flags\us.png" alt="" height="16">ClockIn/Out
              </a>
              <!-- <a href="javascript:void(0);" class="dropdown-item">
                <img src="<?php echo base_url(); ?>assets\img\flags\fr.png" alt="" height="16"> French
              </a>
              <a href="javascript:void(0);" class="dropdown-item">
                <img src="<?php echo base_url(); ?>assets\img\flags\es.png" alt="" height="16"> Spanish
              </a>
              <a href="javascript:void(0);" class="dropdown-item">
                <img src="<?php echo base_url(); ?>assets\img\flags\de.png" alt="" height="16"> German
              </a> -->
            </div>
          </li>

          
        
          <!-- Notifications -->
          <li class="nav-item dropdown">
            <a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown">
              <i class="fa fa-bell-o"></i> <span class="badge badge-pill">3</span>
            </a>
            <div class="dropdown-menu notifications">
              <div class="topnav-dropdown-header">
                <span class="notification-title">Notifications</span>
                <a href="javascript:void(0)" class="clear-noti"> Clear All </a>
              </div>
              <div class="noti-content">
                <ul class="notification-list">
                  <li class="notification-message">
                    <a href="<?php echo base_url(); ?>developer_dashboard/activities">
                      <div class="media">
                        <span class="avatar">
                          <img alt="" src="<?php echo base_url(); ?>assets\img\profiles\avatar-02.jpg">
                        </span>
                        <div class="media-body">
                          <p class="noti-details"><span class="noti-title">John Doe</span> added new task <span class="noti-title">Patient appointment booking</span></p>
                          <p class="noti-time"><span class="notification-time">4 mins ago</span></p>
                        </div>
                      </div>
                    </a>
                  </li>
                  <li class="notification-message">
                    <a href="<?php echo base_url(); ?>developer_dashboard/activities">
                      <div class="media">
                        <span class="avatar">
                          <img alt="" src="<?php echo base_url(); ?>assets\img\profiles\avatar-03.jpg">
                        </span>
                        <div class="media-body">
                          <p class="noti-details"><span class="noti-title">Tarah Shropshire</span> changed the task name <span class="noti-title">Appointment booking with payment gateway</span></p>
                          <p class="noti-time"><span class="notification-time">6 mins ago</span></p>
                        </div>
                      </div>
                    </a>
                  </li>
                  <li class="notification-message">
                    <a href="<?php echo base_url(); ?>developer_dashboard/activities">
                      <div class="media">
                        <span class="avatar">
                          <img alt="" src="<?php echo base_url(); ?>assets\img\profiles\avatar-06.jpg">
                        </span>
                        <div class="media-body">
                          <p class="noti-details"><span class="noti-title">Misty Tison</span> added <span class="noti-title">Domenic Houston</span> and <span class="noti-title">Claire Mapes</span> to project <span class="noti-title">Doctor available module</span></p>
                          <p class="noti-time"><span class="notification-time">8 mins ago</span></p>
                        </div>
                      </div>
                    </a>
                  </li>
                  <li class="notification-message">
                    <a href="<?php echo base_url(); ?>developer_dashboard/activities">
                      <div class="media">
                        <span class="avatar">
                          <img alt="" src="<?php echo base_url(); ?>assets\img\profiles\avatar-17.jpg">
                        </span>
                        <div class="media-body">
                          <p class="noti-details"><span class="noti-title">Rolland Webber</span> completed task <span class="noti-title">Patient and Doctor video conferencing</span></p>
                          <p class="noti-time"><span class="notification-time">12 mins ago</span></p>
                        </div>
                      </div>
                    </a>
                  </li>
                  <li class="notification-message">
                    <a href="<?php echo base_url(); ?>developer_dashboard/activities">
                      <div class="media">
                        <span class="avatar">
                          <img alt="" src="<?php echo base_url(); ?>assets\img\profiles\avatar-13.jpg">
                        </span>
                        <div class="media-body">
                          <p class="noti-details"><span class="noti-title">Bernardo Galaviz</span> added new task <span class="noti-title">Private chat module</span></p>
                          <p class="noti-time"><span class="notification-time">2 days ago</span></p>
                        </div>
                      </div>
                    </a>
                  </li>
                </ul>
              </div>
              <div class="topnav-dropdown-footer">
                <a href="<?php echo base_url(); ?>developer_dashboard/activities">View all Notifications</a>
              </div>
            </div>
          </li>
          <!-- /Notifications -->
          
          <!-- Message Notifications -->
          <li class="nav-item dropdown">
            <a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown">
              <i class="fa fa-comment-o"></i> <span class="badge badge-pill">8</span>
            </a>
            <div class="dropdown-menu notifications">
              <div class="topnav-dropdown-header">
                <span class="notification-title">Messages</span>
                <a href="javascript:void(0)" class="clear-noti"> Clear All </a>
              </div>
              <div class="noti-content">
                <ul class="notification-list">
                  <li class="notification-message">
                    <a href="<?php echo base_url(); ?>developer_dashboard/chat">
                      <div class="list-item">
                        <div class="list-left">
                          <span class="avatar">
                            <img alt="" src="<?php echo base_url(); ?>assets\img\profiles\avatar-09.jpg">
                          </span>
                        </div>
                        <div class="list-body">
                          <span class="message-author">Richard Miles </span>
                          <span class="message-time">12:28 AM</span>
                          <div class="clearfix"></div>
                          <span class="message-content">Lorem ipsum dolor sit amet, consectetur adipiscing</span>
                        </div>
                      </div>
                    </a>
                  </li>
                  <li class="notification-message">
                    <a href="<?php echo base_url(); ?>developer_dashboard/chat">
                      <div class="list-item">
                        <div class="list-left">
                          <span class="avatar">
                            <img alt="" src="<?php echo base_url(); ?>assets\img\profiles\avatar-02.jpg">
                          </span>
                        </div>
                        <div class="list-body">
                          <span class="message-author">John Doe</span>
                          <span class="message-time">6 Mar</span>
                          <div class="clearfix"></div>
                          <span class="message-content">Lorem ipsum dolor sit amet, consectetur adipiscing</span>
                        </div>
                      </div>
                    </a>
                  </li>
                  <li class="notification-message">
                    <a href="<?php echo base_url(); ?>developer_dashboard/chat">
                      <div class="list-item">
                        <div class="list-left">
                          <span class="avatar">
                            <img alt="" src="<?php echo base_url(); ?>assets\img\profiles\avatar-03.jpg">
                          </span>
                        </div>
                        <div class="list-body">
                          <span class="message-author"> Tarah Shropshire </span>
                          <span class="message-time">5 Mar</span>
                          <div class="clearfix"></div>
                          <span class="message-content">Lorem ipsum dolor sit amet, consectetur adipiscing</span>
                        </div>
                      </div>
                    </a>
                  </li>
                  <li class="notification-message">
                    <a href="<?php echo base_url(); ?>developer_dashboard/chat">
                      <div class="list-item">
                        <div class="list-left">
                          <span class="avatar">
                            <img alt="" src="<?php echo base_url(); ?>assets\img\profiles\avatar-05.jpg">
                          </span>
                        </div>
                        <div class="list-body">
                          <span class="message-author">Mike Litorus</span>
                          <span class="message-time">3 Mar</span>
                          <div class="clearfix"></div>
                          <span class="message-content">Lorem ipsum dolor sit amet, consectetur adipiscing</span>
                        </div>
                      </div>
                    </a>
                  </li>
                  <li class="notification-message">
                    <a href="<?php echo base_url(); ?>developer_dashboard/chat">
                      <div class="list-item">
                        <div class="list-left">
                          <span class="avatar">
                            <img alt="" src="<?php echo base_url(); ?>assets\img\profiles\avatar-08.jpg">
                          </span>
                        </div>
                        <div class="list-body">
                          <span class="message-author"> Catherine Manseau </span>
                          <span class="message-time">27 Feb</span>
                          <div class="clearfix"></div>
                          <span class="message-content">Lorem ipsum dolor sit amet, consectetur adipiscing</span>
                        </div>
                      </div>
                    </a>
                  </li>
                </ul>
              </div>
              <div class="topnav-dropdown-footer">
                <a href="<?php echo base_url(); ?>developer_dashboard/chat">View all Messages</a>
              </div>
            </div>
          </li>
          <!-- /Message Notifications -->

          <li class="nav-item dropdown has-arrow main-drop">
            <a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown">
              <span class="user-img"><img src="<?php echo base_url(); ?>assets\img\profiles\avatar-21.jpg" alt="">
              <span class="status online"></span></span>
              <span>Admin</span>
            </a>
            <div class="dropdown-menu">
              <a class="dropdown-item" href="<?php echo base_url(); ?>developer_dashboard/profile">My Profile</a>
              <a class="dropdown-item" href="<?php echo base_url(); ?>developer_dashboard/settings">Settings</a>
              <a class="dropdown-item"href="<?php echo base_url(); ?>login/logout">Logout</a>
            </div>
          </li>
        </ul>
        <!-- /Header Menu -->
        
        <!-- Mobile Menu -->
        <div class="dropdown mobile-user-menu">
          <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
          <div class="dropdown-menu dropdown-menu-right">
            <a class="dropdown-item" href="<?php echo base_url(); ?>developer_dashboard/profile">My Profile</a>
            <a class="dropdown-item" href="<?php echo base_url(); ?>developer_dashboard/settings">Settings</a>
            <a class="dropdown-item"href="<?php echo base_url(); ?>login/logout">Logout</a>
          </div>
        </div>
        <!-- /Mobile Menu -->
        
            </div>
      <!-- /Header -->
      
      <!-- Sidebar -->
            <div class="sidebar" id="sidebar">
                <div class="sidebar-inner slimscroll">
          <div id="sidebar-menu" class="sidebar-menu">
            <ul>
              <li class="menu-title"> 
                <span>Main</span>
              </li>
              <li class="submenu">
                <a href="#"><i class="la la-dashboard"></i> <span> Dashboard</span> <span class="menu-arrow"></span></a>
                <ul style="display: none;">
                  <li><a class="active" href="<?php echo base_url(); ?>">Admin Dashboard</a></li>
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/employee_dashboard">Employee Dashboard</a></li>
                </ul>
              </li>
             <!--  <li class="submenu">
                <a href="#"><i class="la la-cube"></i> <span> Apps</span> <span class="menu-arrow"></span></a>
                <ul style="display: none;">
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/chat">Chat</a></li>
                  <li class="submenu">
                    <a href="#"><span> Calls</span> <span class="menu-arrow"></span></a>
                    <ul style="display: none;">
                      <li><a href="<?php echo base_url(); ?>developer_dashboard/voice_call">Voice Call</a></li>
                      <li><a href="<?php echo base_url(); ?>developer_dashboard/video_call">Video Call</a></li>
                      <li><a href="<?php echo base_url(); ?>developer_dashboard/outgoing_call">Outgoing Call</a></li>
                      <li><a href="<?php echo base_url(); ?>developer_dashboard/incoming_call">Incoming Call</a></li>
                    </ul>
                  </li>
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/events">Calendar</a></li>
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/contacts">Contacts</a></li>
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/inbox">Email</a></li>
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/file_manager">File Manager</a></li>
                </ul>
              </li> -->
              <li class="menu-title"> 
                <span>Employees</span>
              </li>
              <li class="submenu">
                <a href="#" class="noti-dot"><i class="la la-user"></i> <span> Employees</span> <span class="menu-arrow"></span></a>
                <ul style="display: none;">
                 <!--  <li><a href="<?php echo base_url(); ?>developer_dashboard/employees">All Employees</a></li> -->
                  <!-- <li><a href="<?php echo base_url(); ?>developer_dashboard/holidays">Holidays</a></li> -->
                 <!--  <li><a href="<?php echo base_url(); ?>developer_dashboard/leaves">Leaves (Admin) <span class="badge badge-pill bg-primary float-right">1</span></a></li> -->
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/leaves_employee">Leaves (Employee)</a></li>
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/leave_settings">Leave Settings</a></li>
                 <!--  <li><a href="<?php echo base_url(); ?>developer_dashboard/attendance">Attendance (Admin)</a></li> -->
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/attendance_employee">Attendance (Employee)</a></li>
                 <!--  <li><a href="<?php echo base_url(); ?>developer_dashboard/departments">Departments</a></li>
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/designations">Designations</a></li> -->
                 <!--  <li><a href="<?php echo base_url(); ?>developer_dashboard/timesheet">Timesheet</a></li> -->
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/overtime">Overtime</a></li>
                </ul>
              </li>
             <!--  <li> 
                <a href="<?php echo base_url(); ?>developer_dashboard/clients"><i class="la la-users"></i> <span>Clients</span></a>
              </li> -->
              <!-- <li class="submenu">
                <a href="#"><i class="la la-rocket"></i> <span> Projects</span> <span class="menu-arrow"></span></a>
                <ul style="display: none;">
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/projects">Projects</a></li>
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/tasks">Tasks</a></li>
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/tasks">Task Board</a></li>
                </ul>
              </li> -->
              <!-- <li> 
                <a href="<?php echo base_url(); ?>developer_dashboard/leads"><i class="la la-user-secret"></i> <span>Leads</span></a>
              </li> -->
             <!--  <li> 
                <a href="<?php echo base_url(); ?>developer_dashboard/tickets"><i class="la la-ticket"></i> <span>Tickets</span></a>
              </li> -->
             <!--  <li class="menu-title"> 
                <span>HR</span>
              </li> -->
             <!--  <li class="submenu">
                <a href="#"><i class="la la-files-o"></i> <span> Accounts </span> <span class="menu-arrow"></span></a>
                <ul style="display: none;">
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/estimates">Estimates</a></li>
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/invoices">Invoices</a></li>
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/payments">Payments</a></li>
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/expenses">Expenses</a></li>
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/provident_fund">Provident Fund</a></li>
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/taxes">Taxes</a></li>
                </ul>
              </li> -->
              <!-- <li class="submenu">
                <a href="#"><i class="la la-money"></i> <span> Payroll </span> <span class="menu-arrow"></span></a>
                <ul style="display: none;">
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/salary"> Employee Salary </a></li>
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/salary_view"> Payslip </a></li>
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/payroll_items"> Payroll Items </a></li>
                </ul>
              </li> -->
             <!--  <li> 
                <a href="<?php echo base_url(); ?>developer_dashboard/policies"><i class="la la-file-pdf-o"></i> <span>Policies</span></a>
              </li> -->
             <!--  <li class="submenu">
                <a href="#"><i class="la la-pie-chart"></i> <span> Reports </span> <span class="menu-arrow"></span></a>
                <ul style="display: none;">
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/expense_reports"> Expense Report </a></li>
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/invoice_reports"> Invoice Report </a></li>
                </ul>
              </li> -->
             <!--  <li class="menu-title"> 
                <span>Performance</span>
              </li> -->
              <!-- <li class="submenu">
                <a href="#"><i class="la la-graduation-cap"></i> <span> Performance </span> <span class="menu-arrow"></span></a>
                <ul style="display: none;">
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/performance_indicator"> Performance Indicator </a></li>
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/performance"> Performance Review </a></li>
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/performance_appraisal"> Performance Appraisal </a></li>
                </ul>
              </li> -->
             <!--  <li class="submenu">
                <a href="#"><i class="la la-crosshairs"></i> <span> Goals </span> <span class="menu-arrow"></span></a>
                <ul style="display: none;">
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/goal_tracking"> Goal List </a></li>
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/goal_type"> Goal Type </a></li>
                </ul>
              </li> -->
              <!-- <li class="submenu">
                <a href="#"><i class="la la-edit"></i> <span> Training </span> <span class="menu-arrow"></span></a>
                <ul style="display: none;">
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/training"> Training List </a></li>
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/trainers"> Trainers</a></li>
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/training_type"> Training Type </a></li>
                </ul>
              </li> -->
              <!-- <li><a href="<?php echo base_url(); ?>developer_dashboard/promotion"><i class="la la-bullhorn"></i> <span>Promotion</span></a></li> -->
             <!--  <li><a href="<?php echo base_url(); ?>developer_dashboard/resignation"><i class="la la-external-link-square"></i> <span>Resignation</span></a></li> -->
             <!--  <li><a href="<?php echo base_url(); ?>developer_dashboard/termination"><i class="la la-times-circle"></i> <span>Termination</span></a></li> -->
              <!-- <li class="menu-title"> 
                <span>Administration</span>
              </li> -->
              <!-- <li> 
                <a href="<?php echo base_url(); ?>developer_dashboard/assets"><i class="la la-object-ungroup"></i> <span>Assets</span></a>
              </li> -->
             <!--  <li class="submenu">
                <a href="#"><i class="la la-briefcase"></i> <span> Jobs </span> <span class="menu-arrow"></span></a>
                <ul style="display: none;">
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/jobs"> Manage Jobs </a></li>
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/job_applicants"> Applied Candidates </a></li>
                </ul>
              </li> -->
             <!--  <li> 
                <a href="<?php echo base_url(); ?>developer_dashboard/knowledgebase"><i class="la la-question"></i> <span>Knowledgebase</span></a>
              </li> -->
             <!--  <li> 
                <a href="<?php echo base_url(); ?>developer_dashboard/activities"><i class="la la-bell"></i> <span>Activities</span></a>
              </li> -->
             <!--  <li> 
                <a href="<?php echo base_url(); ?>developer_dashboard/users"><i class="la la-user-plus"></i> <span>Users</span></a>
              </li> -->
              <!-- <li> 
                <a href="<?php echo base_url(); ?>developer_dashboard/settings"><i class="la la-cog"></i> <span>Settings</span></a>
              </li> -->
             <!--  <li class="menu-title"> 
                <span>Pages</span>
              </li> -->
            <!--   <li class="submenu">
                <a href="#"><i class="la la-user"></i> <span> Profile </span> <span class="menu-arrow"></span></a>
                <ul style="display: none;">
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/profile"> Employee Profile </a></li>
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/client_profile"> Client Profile </a></li>
                </ul>
              </li> -->
              <!-- <li class="submenu">
                <a href="#"><i class="la la-key"></i> <span> Authentication </span> <span class="menu-arrow"></span></a>
                <ul style="display: none;">
                  <li><ahref="<?php echo base_url(); ?>developer_dashboard/login"> Login </a></li>
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/register"> Register </a></li>
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/forgot_password"> Forgot Password </a></li>
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/otp"> OTP </a></li>
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/lock_screen"> Lock Screen </a></li>
                </ul>
              </li> -->
              <!-- <li class="submenu">
                <a href="#"><i class="la la-exclamation-triangle"></i> <span> Error Pages </span> <span class="menu-arrow"></span></a>
                <ul style="display: none;">
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/error_404">404 Error </a></li>
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/error_500">500 Error </a></li>
                </ul>
              </li> -->
             <!--  <li class="submenu">
                <a href="#"><i class="la la-hand-o-up"></i> <span> Subscriptions </span> <span class="menu-arrow"></span></a>
                <ul style="display: none;">
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/subscriptions"> Subscriptions (Admin) </a></li>
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/subscriptions_company"> Subscriptions (Company) </a></li>
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/subscribed_companies"> Subscribed Companies</a></li>
                </ul>
              </li> -->
             <!--  <li class="submenu">
                <a href="#"><i class="la la-columns"></i> <span> Pages </span> <span class="menu-arrow"></span></a>
                <ul style="display: none;">
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/search"> Search </a></li>
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/faq"> FAQ </a></li>
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/terms"> Terms </a></li>
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/privacy_policy"> Privacy Policy </a></li>
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/blank-page"> Blank Page </a></li>
                </ul>
              </li> -->
             <!--  <li class="menu-title"> 
                <span>UI Interface</span>
              </li> -->
             <!--  <li> 
                <a href="<?php echo base_url(); ?>developer_dashboard/components"><i class="la la-puzzle-piece"></i> <span>Components</span></a>
              </li> -->
              <!-- <li class="submenu">
                <a href="#"><i class="la la-object-group"></i> <span> Forms </span> <span class="menu-arrow"></span></a>
                <ul style="display: none;">
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/form_basic_inputs">Basic Inputs </a></li>
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/form_input_groups">Input Groups </a></li>
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/form_horizontal">Horizontal Form </a></li>
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/form_vertical"> Vertical Form </a></li>
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/form_mask"> Form Mask </a></li>
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/form_validation"> Form Validation </a></li>
                </ul>
              </li> -->
             <!--  <li class="submenu">
                <a href="#"><i class="la la-table"></i> <span> Tables </span> <span class="menu-arrow"></span></a>
                <ul style="display: none;">
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/tables_basic">Basic Tables </a></li>
                  <li><a href="<?php echo base_url(); ?>developer_dashboard/data_tables">Data Table </a></li>
                </ul>
              </li> -->
             <!--  <li class="menu-title"> 
                <span>Extras</span>
              </li> -->
              <!-- <li> 
                <a href="#"><i class="la la-file-text"></i> <span>Documentation</span></a>
              </li> -->
              <!-- <li> 
                <a href="javascript:void(0);"><i class="la la-info"></i> <span>Change Log</span> <span class="badge badge-primary ml-auto">v3.4</span></a>
              </li> -->
             <!--  <li class="submenu">
                <a href="javascript:void(0);"><i class="la la-share-alt"></i> <span>Multi Level</span> <span class="menu-arrow"></span></a>
                <ul style="display: none;">
                  <li class="submenu">
                    <a href="javascript:void(0);"> <span>Level 1</span> <span class="menu-arrow"></span></a>
                    <ul style="display: none;">
                      <li><a href="javascript:void(0);"><span>Level 2</span></a></li>
                      <li class="submenu">
                        <a href="javascript:void(0);"> <span> Level 2</span> <span class="menu-arrow"></span></a>
                        <ul style="display: none;">
                          <li><a href="javascript:void(0);">Level 3</a></li>
                          <li><a href="javascript:void(0);">Level 3</a></li>
                        </ul>
                      </li>
                      <li><a href="javascript:void(0);"> <span>Level 2</span></a></li>
                    </ul>
                  </li>
                  <li>
                    <a href="javascript:void(0);"> <span>Level 1</span></a>
                  </li>
                </ul>
              </li> -->
            </ul>
          </div>
                </div>
            </div>