
	       
  <div class="header">
      
        <!-- Logo -->
                <div class="header-left auth-box" style="background: #000;width: 180px;">
                    <a href="<?php echo base_url(); ?>" class="logo">
                      <img src="<?php echo base_url() ?>assets/img/logo.png" height="45px" alt="Digital Kart">
                    </a>
                </div>
        <!-- /Logo -->
        
       <!--  <a id="toggle_btn" href="javascript:void(0);">
          <span class="bar-icon">
            <span></span>
            <span></span>
            <span></span>
          </span>
        </a> -->
        
        <!-- Header Title -->
                <div class="page-title-box">
                  
                </div>
        <!-- /Header Title -->
        
        <a id="mobile_btn" class="mobile_btn" href="#sidebar"><i class="fa fa-bars"></i></a>
        
        <!-- Header Menu -->
        <ul class="nav user-menu">
        
        
          
           <!-- Search -->
          <li class="nav-item">
            <div class="top-nav-search">
              <a href="javascript:void(0);" class="responsive-search">
                <i class="fa fa-search"></i>
               </a>
              <form action="<?php echo site_url(); ?>marketing_dashboard/search">
                <input class="form-control" type="text" placeholder="Search here">
                <button class="btn" type="submit"><i class="fa fa-search"></i></button>
              </form>
            </div>
          </li>
          <!-- /Search -->

          <!-- Notifications -->
           <li class="nav-item dropdown has-arrow flag-nav" style="padding: 18px 10px;">
      
                <i class="fa fa-comment fa-2x" data-toggle="modal" data-target="#gen_contact"></i>
              
          </li>
          <li class="nav-item dropdown has-arrow flag-nav" style="padding: 18px 10px;">
          <i class="fa fa-info-circle fa-2x" aria-hidden="true"></i>
          </li>

          <!-- /Notifications -->
          <div class="row" style="padding-top:20px;" >
          <div class="col-md-12">
              <span class="status online"></span>
              <span style="padding-right:30px;"><?= $this->session->userdata('user_name'); ?></span>
          </div>
          </div>
        </ul>
        <!-- /Header Menu -->
        
        <!-- Mobile Menu -->
        <div class="dropdown mobile-user-menu">
          <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
          <div class="dropdown-menu dropdown-menu-right">
            <a class="dropdown-item" href="<?php echo base_url(); ?>developer_dashboard/profile">My Profile</a>
            <a class="dropdown-item" href="<?php echo base_url(); ?>developer_dashboard/settings">Settings</a>
            <a class="dropdown-item"href="<?php echo base_url(); ?>login/logout">Logout</a>
          </div>
        </div>
        <!-- /Mobile Menu -->
        
  </div>
      <!-- /Header -->
   <!-- Add social Modal -->
        <div id="gen_contact" class="modal custom-modal fade" role="dialog">
          <div class="modal-dialog modal-md" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title">Digital Kart Ticket Form</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                <form method="post" id="add_client_form" enctype="multipart/form-data">
                  <div class="row">
                    <div class="col-md-12">
                      <div class="form-group">
                        <label class="col-form-label">Email<span class="text-danger">*</span></label>
                        <input class="form-control" type="text" readonly value="<?= $this->session->userdata('user_email'); ?>">
                      </div>
                    </div>
                    <div class="col-md-12">
                      <div class="form-group">
                        <label class="col-form-label">Phone</label>
                        <input class="form-control" type="text">
                      </div>
                    </div>
                    <div class="col-md-12">
                      <div class="form-group">
                        <label class="col-form-label">Subject</label>
                        <input class="form-control" type="text">
                      </div>
                    </div>

                    <div class="col-md-12">
                      <div class="form-group">
                        <label class="col-form-label">Description</label>
                        <textarea class="form-control" placeholder="share your description........"></textarea>
                      </div>
                    </div>
                    
                  </div>
                  
                  <div class="row">
                    <div class="col-4">
                    </div>
                    <div class="col-4">
                      <a href="javascript:void(0);" data-dismiss="modal" class="btn btn-primary cancel-btn">Submit</a>
                    </div>
                    <div class="col-4">
                      
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
        <!-- /Add social Modal -->
   
     